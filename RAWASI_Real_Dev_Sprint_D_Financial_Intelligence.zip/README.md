# RAWASI Platform - Real Development Sprint D

Sprint D يبني **Company Workspace** كملف شركة ذكي داخل منصة الرواسي.

## التشغيل

```bash
npm install
npm run dev
```

## الفحص

```bash
npm run check
npm run build
```

## الجديد
- Company Workspace متعدد المراكز.
- مراكز الملف:
  - بيانات الشركة والملكية ومجلس الإدارة.
  - المركز المالي.
  - المركز الفني.
  - مركز المستندات.
  - مركز التصنيف.
  - Activity Timeline.
- Workspace Engine لحساب جاهزية كل مركز.
- ترقية بيانات Sprint B تلقائيًا لدعم الملاك، أعضاء المجلس، الفروع، والمشاريع.
- استمرار منع تكرار السجل التجاري والحفظ المحلي والنسخ الاحتياطي.

## ملاحظة
هذه نسخة Source Only ولا تحتوي على `node_modules` أو `dist`.


## Sprint D - Financial Intelligence

أضاف هذا الإصدار محرك التحليل المالي، التقييم الائتماني المالي، شاشة الذكاء المالي، وفحص جودة القوائم.
