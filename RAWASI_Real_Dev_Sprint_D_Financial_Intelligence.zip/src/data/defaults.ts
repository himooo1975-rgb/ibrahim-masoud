import type { BoardMember, Company, CompanyBranch, CompanyOwner, CompanyProject, DocumentStatus, FinancialStatement, TechnicalProfile } from '../lib/types';

export const defaultFinancialStatement: FinancialStatement = {
  year: new Date().getFullYear() - 1,
  assets: 0,
  liabilities: 0,
  equity: 0,
  revenue: 0,
  netProfit: 0,
  operatingCashFlow: 0,
};

export const defaultTechnicalProfile: TechnicalProfile = {
  employees: 0,
  engineers: 0,
  technicians: 0,
  saudiEmployees: 0,
  avgEngineerExperience: 0,
  avgTechnicianExperience: 0,
  equipmentCount: 0,
  completedProjects: 0,
};

export const defaultDocuments: DocumentStatus[] = [
  { key: 'commercial_registration', title: 'السجل التجاري', status: 'ناقص' },
  { key: 'municipal_license', title: 'الرخصة البلدية / مقر المنشأة', status: 'ناقص' },
  { key: 'financial_statement', title: 'القوائم المالية', status: 'ناقص' },
  { key: 'zakat_certificate', title: 'شهادة الزكاة', status: 'ناقص' },
  { key: 'gosi_certificate', title: 'شهادة التأمينات', status: 'ناقص' },
  { key: 'authorization_letter', title: 'خطاب التفويض', status: 'ناقص' },
  { key: 'board_resolution', title: 'قرار مجلس الإدارة', status: 'ناقص' },
];

export const defaultOwners: CompanyOwner[] = [{ id: crypto.randomUUID(), name: '', sharePercent: 100 }];
export const defaultBoardMembers: BoardMember[] = [{ id: crypto.randomUUID(), name: '', role: 'رئيس مجلس الإدارة' }];
export const defaultBranches: CompanyBranch[] = [{ id: crypto.randomUUID(), city: 'الرياض', address: '' }];
export const defaultProjects: CompanyProject[] = [{ id: crypto.randomUUID(), name: '', sector: 'التشييد والبناء', value: 0, status: 'قائم' }];

export function createCompanyDraft(): Company {
  const now = new Date().toISOString();
  return {
    id: crypto.randomUUID(),
    name: '',
    commercialRegistration: '',
    establishmentNumber: '',
    city: 'الرياض',
    activity: 'التشييد والبناء',
    targetGrade: 'الثانية',
    owners: defaultOwners.map((item) => ({ ...item, id: crypto.randomUUID() })),
    boardMembers: defaultBoardMembers.map((item) => ({ ...item, id: crypto.randomUUID() })),
    branches: defaultBranches.map((item) => ({ ...item, id: crypto.randomUUID() })),
    projects: defaultProjects.map((item) => ({ ...item, id: crypto.randomUUID() })),
    financial: { ...defaultFinancialStatement },
    technical: { ...defaultTechnicalProfile },
    documents: defaultDocuments.map((doc) => ({ ...doc })),
    createdAt: now,
    updatedAt: now,
  };
}

export const seedCompany: Company = {
  ...createCompanyDraft(),
  id: 'seed-rawasi-001',
  name: 'شركة تلال الرواسي للمقاولات',
  commercialRegistration: '1010000000',
  establishmentNumber: '7000000000',
  city: 'الرياض',
  activity: 'التشييد والبناء',
  targetGrade: 'الأولى',
  owners: [
    { id: 'owner-1', name: 'إبراهيم مسعود', sharePercent: 75 },
    { id: 'owner-2', name: 'شريك استثماري', sharePercent: 25 },
  ],
  boardMembers: [
    { id: 'board-1', name: 'إبراهيم مسعود', role: 'رئيس مجلس الإدارة' },
    { id: 'board-2', name: 'عضو تنفيذي', role: 'عضو' },
  ],
  branches: [
    { id: 'branch-1', city: 'الرياض', address: 'الفرع الرئيسي' },
    { id: 'branch-2', city: 'جدة', address: 'فرع المنطقة الغربية' },
  ],
  projects: [
    { id: 'project-1', name: 'مشروع بنية تحتية', sector: 'التشييد والبناء', value: 9200000, status: 'منفذ' },
    { id: 'project-2', name: 'مشروع مبانٍ إدارية', sector: 'التشييد والبناء', value: 14300000, status: 'قائم' },
  ],
  financial: {
    year: 2025,
    assets: 24000000,
    liabilities: 9800000,
    equity: 14200000,
    revenue: 36000000,
    netProfit: 4100000,
    operatingCashFlow: 3600000,
  },
  technical: {
    employees: 82,
    engineers: 9,
    technicians: 18,
    saudiEmployees: 23,
    avgEngineerExperience: 8,
    avgTechnicianExperience: 7,
    equipmentCount: 24,
    completedProjects: 16,
  },
  documents: defaultDocuments.map((doc, index) => ({ ...doc, status: index < 4 ? 'مكتمل' : 'ناقص' })),
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
};
