import { Activity, BadgeCheck, Banknote, BriefcaseBusiness, Building2, FileText, Goal, HardHat, MapPin, UsersRound } from 'lucide-react';
import { Card } from '../../components/Card';
import { buildWorkspaceSections, overallWorkspaceReadiness } from '../../engines/workspace/workspaceEngine';
import type { BoardMember, Company, CompanyBranch, CompanyOwner, CompanyProject, DocumentStatus, EngineResult } from '../../lib/types';

interface CompanyWorkspaceProps {
  company: Company;
  result: EngineResult;
  onChange: (company: Company) => void;
}

function numberFormat(value: number) {
  return value.toLocaleString('ar-SA');
}

function toNumber(value: string) {
  return Number.isFinite(Number(value)) ? Number(value) : 0;
}

function statusClass(status: string) {
  if (status === 'مكتمل') return 'bg-emerald-50 text-emerald-700 border-emerald-200';
  if (status === 'يحتاج عمل' || status === 'يحتاج تحديث') return 'bg-amber-50 text-amber-700 border-amber-200';
  return 'bg-red-50 text-red-700 border-red-200';
}

export function CompanyWorkspace({ company, result, onChange }: CompanyWorkspaceProps) {
  const sections = buildWorkspaceSections(company, result);
  const overall = overallWorkspaceReadiness(sections);
  const completedDocuments = company.documents.filter((doc) => doc.status === 'مكتمل').length;
  const totalProjectsValue = company.projects.reduce((sum, project) => sum + project.value, 0);

  function patchOwner(index: number, field: keyof CompanyOwner, value: string) {
    const owners = company.owners.map((owner, ownerIndex) => (ownerIndex === index ? { ...owner, [field]: field === 'sharePercent' ? toNumber(value) : value } : owner));
    onChange({ ...company, owners });
  }

  function addOwner() {
    onChange({ ...company, owners: [...company.owners, { id: crypto.randomUUID(), name: '', sharePercent: 0 }] });
  }

  function patchBoard(index: number, field: keyof BoardMember, value: string) {
    const boardMembers = company.boardMembers.map((member, memberIndex) => (memberIndex === index ? { ...member, [field]: value } : member));
    onChange({ ...company, boardMembers });
  }

  function addBoardMember() {
    onChange({ ...company, boardMembers: [...company.boardMembers, { id: crypto.randomUUID(), name: '', role: 'عضو' }] });
  }

  function patchBranch(index: number, field: keyof CompanyBranch, value: string) {
    const branches = company.branches.map((branch, branchIndex) => (branchIndex === index ? { ...branch, [field]: value } : branch));
    onChange({ ...company, branches });
  }

  function addBranch() {
    onChange({ ...company, branches: [...company.branches, { id: crypto.randomUUID(), city: '', address: '' }] });
  }

  function patchProject(index: number, field: keyof CompanyProject, value: string) {
    const projects = company.projects.map((project, projectIndex) => (
      projectIndex === index ? { ...project, [field]: field === 'value' ? toNumber(value) : value } : project
    ));
    onChange({ ...company, projects });
  }

  function addProject() {
    onChange({ ...company, projects: [...company.projects, { id: crypto.randomUUID(), name: '', sector: company.activity, value: 0, status: 'قائم' }] });
  }

  function patchDocument(index: number, field: keyof DocumentStatus, value: string) {
    const documents = company.documents.map((doc, docIndex) => (docIndex === index ? { ...doc, [field]: value } : doc));
    onChange({ ...company, documents });
  }

  return (
    <section className="grid gap-5">
      <Card title="Company Workspace · ملف الشركة الذكي">
        <div className="grid gap-5 lg:grid-cols-[1.2fr_.8fr]">
          <div>
            <div className="flex items-start gap-4">
              <div className="grid h-14 w-14 place-items-center rounded-2xl bg-rawasi-navy text-white"><Building2 /></div>
              <div>
                <p className="text-sm font-bold text-slate-500">{company.activity} · {company.city}</p>
                <h2 className="mt-1 text-3xl font-black text-rawasi-navy">{company.name || 'شركة بدون اسم'}</h2>
                <p className="mt-2 text-sm text-slate-500">السجل التجاري: {company.commercialRegistration || 'غير مدخل'} · رقم المنشأة: {company.establishmentNumber || 'غير مدخل'}</p>
              </div>
            </div>
            <div className="mt-5 grid gap-3 md:grid-cols-3">
              <div className="rounded-2xl bg-slate-50 p-4"><span className="text-sm text-slate-500">الدرجة الحالية</span><b className="mt-1 block text-2xl text-rawasi-navy">{result.grade}</b></div>
              <div className="rounded-2xl bg-slate-50 p-4"><span className="text-sm text-slate-500">الدرجة المستهدفة</span><b className="mt-1 block text-2xl text-rawasi-green">{company.targetGrade}</b></div>
              <div className="rounded-2xl bg-slate-50 p-4"><span className="text-sm text-slate-500">جاهزية الملف</span><b className="mt-1 block text-2xl text-rawasi-blue">{overall}%</b></div>
            </div>
          </div>
          <div className="rounded-3xl bg-gradient-to-l from-rawasi-navy to-rawasi-blue p-5 text-white">
            <p className="text-sm text-white/70">ملخص المستشار</p>
            <p className="mt-3 text-lg font-bold leading-8">الملف يحتوي على {completedDocuments}/{company.documents.length} مستند مكتمل، وقيمة مشاريع مسجلة {numberFormat(totalProjectsValue)} ريال، ونسبة ثقة التصنيف {result.confidence}%.</p>
          </div>
        </div>
      </Card>

      <div className="grid gap-4 md:grid-cols-5">
        {sections.map((section) => (
          <div key={section.key} className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="flex items-center justify-between gap-2">
              <b className="text-sm text-slate-700">{section.title}</b>
              <span className={`rounded-full border px-2 py-1 text-xs font-bold ${statusClass(section.status)}`}>{section.status}</span>
            </div>
            <div className="mt-3 h-2 overflow-hidden rounded-full bg-slate-100"><div className="h-full rounded-full bg-rawasi-green" style={{ width: `${section.readiness}%` }} /></div>
            <p className="mt-2 text-2xl font-black text-rawasi-navy">{section.readiness}%</p>
          </div>
        ))}
      </div>

      <div className="grid gap-5 xl:grid-cols-2">
        <Card title="بيانات الملكية ومجلس الإدارة">
          <div className="grid gap-4 lg:grid-cols-2">
            <div className="grid gap-3">
              <div className="flex items-center justify-between"><b className="flex items-center gap-2"><UsersRound size={18} /> الملاك</b><button className="rounded-lg bg-rawasi-green px-3 py-2 text-sm font-bold text-white" type="button" onClick={addOwner}>إضافة مالك</button></div>
              {company.owners.map((owner, index) => (
                <div key={owner.id} className="grid grid-cols-[1fr_90px] gap-2 rounded-xl bg-slate-50 p-3">
                  <input className="rounded-lg border border-slate-200 p-2" placeholder="اسم المالك" value={owner.name} onChange={(event) => patchOwner(index, 'name', event.target.value)} />
                  <input className="rounded-lg border border-slate-200 p-2" type="number" value={owner.sharePercent} onChange={(event) => patchOwner(index, 'sharePercent', event.target.value)} />
                </div>
              ))}
            </div>
            <div className="grid gap-3">
              <div className="flex items-center justify-between"><b className="flex items-center gap-2"><BadgeCheck size={18} /> مجلس الإدارة</b><button className="rounded-lg bg-rawasi-green px-3 py-2 text-sm font-bold text-white" type="button" onClick={addBoardMember}>إضافة عضو</button></div>
              {company.boardMembers.map((member, index) => (
                <div key={member.id} className="grid grid-cols-[1fr_150px] gap-2 rounded-xl bg-slate-50 p-3">
                  <input className="rounded-lg border border-slate-200 p-2" placeholder="اسم العضو" value={member.name} onChange={(event) => patchBoard(index, 'name', event.target.value)} />
                  <select className="rounded-lg border border-slate-200 p-2" value={member.role} onChange={(event) => patchBoard(index, 'role', event.target.value)}>
                    <option>رئيس مجلس الإدارة</option><option>نائب الرئيس</option><option>عضو</option><option>مدير عام</option><option>مفوّض</option>
                  </select>
                </div>
              ))}
            </div>
          </div>
        </Card>

        <Card title="الفروع والمشاريع">
          <div className="grid gap-4 lg:grid-cols-2">
            <div className="grid gap-3">
              <div className="flex items-center justify-between"><b className="flex items-center gap-2"><MapPin size={18} /> الفروع</b><button className="rounded-lg bg-rawasi-green px-3 py-2 text-sm font-bold text-white" type="button" onClick={addBranch}>إضافة فرع</button></div>
              {company.branches.map((branch, index) => (
                <div key={branch.id} className="grid gap-2 rounded-xl bg-slate-50 p-3">
                  <input className="rounded-lg border border-slate-200 p-2" placeholder="المدينة" value={branch.city} onChange={(event) => patchBranch(index, 'city', event.target.value)} />
                  <input className="rounded-lg border border-slate-200 p-2" placeholder="العنوان" value={branch.address ?? ''} onChange={(event) => patchBranch(index, 'address', event.target.value)} />
                </div>
              ))}
            </div>
            <div className="grid gap-3">
              <div className="flex items-center justify-between"><b className="flex items-center gap-2"><BriefcaseBusiness size={18} /> المشاريع</b><button className="rounded-lg bg-rawasi-green px-3 py-2 text-sm font-bold text-white" type="button" onClick={addProject}>إضافة مشروع</button></div>
              {company.projects.map((project, index) => (
                <div key={project.id} className="grid gap-2 rounded-xl bg-slate-50 p-3">
                  <input className="rounded-lg border border-slate-200 p-2" placeholder="اسم المشروع" value={project.name} onChange={(event) => patchProject(index, 'name', event.target.value)} />
                  <div className="grid grid-cols-[1fr_130px] gap-2">
                    <input className="rounded-lg border border-slate-200 p-2" type="number" value={project.value} onChange={(event) => patchProject(index, 'value', event.target.value)} />
                    <select className="rounded-lg border border-slate-200 p-2" value={project.status} onChange={(event) => patchProject(index, 'status', event.target.value)}>
                      <option>منفذ</option><option>قائم</option><option>متوقف</option><option>مخطط</option>
                    </select>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Card>
      </div>

      <div className="grid gap-5 xl:grid-cols-3">
        <Card title="المركز المالي">
          <div className="grid gap-3 text-sm">
            <p className="flex justify-between"><span className="flex items-center gap-2"><Banknote size={16} /> السنة المالية</span><b>{company.financial.year}</b></p>
            <p className="flex justify-between"><span>الأصول</span><b>{numberFormat(company.financial.assets)}</b></p>
            <p className="flex justify-between"><span>الخصوم</span><b>{numberFormat(company.financial.liabilities)}</b></p>
            <p className="flex justify-between"><span>حقوق الملكية</span><b>{numberFormat(company.financial.equity)}</b></p>
            <p className="flex justify-between"><span>صافي الربح</span><b>{numberFormat(company.financial.netProfit)}</b></p>
          </div>
        </Card>
        <Card title="المركز الفني">
          <div className="grid gap-3 text-sm">
            <p className="flex justify-between"><span className="flex items-center gap-2"><HardHat size={16} /> العاملون</span><b>{company.technical.employees}</b></p>
            <p className="flex justify-between"><span>المهندسون</span><b>{company.technical.engineers}</b></p>
            <p className="flex justify-between"><span>الفنيون</span><b>{company.technical.technicians}</b></p>
            <p className="flex justify-between"><span>المعدات</span><b>{company.technical.equipmentCount ?? 0}</b></p>
            <p className="flex justify-between"><span>المشاريع المكتملة</span><b>{company.technical.completedProjects ?? 0}</b></p>
          </div>
        </Card>
        <Card title="مركز التصنيف">
          <div className="grid gap-3 text-sm">
            <p className="flex justify-between"><span className="flex items-center gap-2"><Goal size={16} /> النقاط</span><b>{result.score}/100</b></p>
            <p className="flex justify-between"><span>الدرجة</span><b>{result.grade}</b></p>
            <p className="flex justify-between"><span>الثقة</span><b>{result.confidence}%</b></p>
            <p className="flex justify-between"><span>جاهزية Workspace</span><b>{overall}%</b></p>
          </div>
        </Card>
      </div>

      <Card title="مركز المستندات">
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          {company.documents.map((doc, index) => (
            <div key={doc.key} className="rounded-2xl border border-slate-200 bg-white p-4">
              <div className="flex items-start justify-between gap-2"><b className="flex items-center gap-2 text-sm"><FileText size={16} /> {doc.title}</b><span className={`rounded-full border px-2 py-1 text-xs font-bold ${statusClass(doc.status)}`}>{doc.status}</span></div>
              <select className="mt-3 w-full rounded-lg border border-slate-200 p-2 text-sm" value={doc.status} onChange={(event) => patchDocument(index, 'status', event.target.value)}>
                <option>مكتمل</option><option>ناقص</option><option>يحتاج تحديث</option>
              </select>
              <input className="mt-2 w-full rounded-lg border border-slate-200 p-2 text-sm" type="date" value={doc.expiryDate ?? ''} onChange={(event) => patchDocument(index, 'expiryDate', event.target.value)} />
            </div>
          ))}
        </div>
      </Card>

      <Card title="Activity Timeline · سجل حركة ملف الشركة">
        <div className="grid gap-3">
          <div className="flex gap-3 rounded-xl bg-slate-50 p-3"><Activity className="text-rawasi-green" size={18} /><span className="text-sm text-slate-700">تم فتح Workspace الشركة وتحديث مؤشر الجاهزية إلى {overall}%.</span></div>
          <div className="flex gap-3 rounded-xl bg-slate-50 p-3"><Activity className="text-rawasi-green" size={18} /><span className="text-sm text-slate-700">آخر تحديث للملف: {new Date(company.updatedAt).toLocaleString('ar-SA')}.</span></div>
        </div>
      </Card>
    </section>
  );
}
