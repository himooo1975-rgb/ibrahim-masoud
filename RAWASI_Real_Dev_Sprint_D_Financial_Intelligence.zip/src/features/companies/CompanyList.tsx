import type { Company } from '../../lib/types';

export function CompanyList({ companies, selectedId, onSelect }: { companies: Company[]; selectedId: string; onSelect: (company: Company) => void }) {
  return (
    <aside className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
      <h2 className="mb-3 text-lg font-black text-rawasi-navy">ملفات الشركات</h2>
      <div className="grid gap-2">
        {companies.map((company) => (
          <button
            className={`rounded-xl border p-3 text-right transition ${company.id === selectedId ? 'border-rawasi-green bg-emerald-50' : 'border-slate-200 hover:bg-slate-50'}`}
            key={company.id}
            type="button"
            onClick={() => onSelect(company)}
          >
            <span className="block font-bold text-slate-800">{company.name || 'شركة بدون اسم'}</span>
            <span className="mt-1 block text-xs text-slate-500">سجل {company.commercialRegistration || 'غير محدد'} · {company.city}</span>
          </button>
        ))}
      </div>
    </aside>
  );
}
