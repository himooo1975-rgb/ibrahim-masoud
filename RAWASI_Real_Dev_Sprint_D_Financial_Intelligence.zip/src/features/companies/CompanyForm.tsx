import type { ChangeEvent } from 'react';
import type { ClassificationGrade, Company, DocumentStatus } from '../../lib/types';
import { Card } from '../../components/Card';

const grades: ClassificationGrade[] = ['الأولى', 'الثانية', 'الثالثة', 'الرابعة', 'الخامسة'];
const documentStatuses: DocumentStatus['status'][] = ['مكتمل', 'ناقص', 'يحتاج تحديث'];

interface CompanyFormProps {
  company: Company;
  onChange: (company: Company) => void;
  onSave: () => void;
  onNew: () => void;
  onDelete: () => void;
}

function toNumber(value: string) {
  return Number.isFinite(Number(value)) ? Number(value) : 0;
}

export function CompanyForm({ company, onChange, onSave, onNew, onDelete }: CompanyFormProps) {
  function patchCompany(field: keyof Company, value: string) {
    onChange({ ...company, [field]: value });
  }

  function patchFinancial(field: keyof Company['financial'], event: ChangeEvent<HTMLInputElement>) {
    onChange({ ...company, financial: { ...company.financial, [field]: toNumber(event.target.value) } });
  }

  function patchTechnical(field: keyof Company['technical'], event: ChangeEvent<HTMLInputElement>) {
    onChange({ ...company, technical: { ...company.technical, [field]: toNumber(event.target.value) } });
  }

  function patchDocument(index: number, status: DocumentStatus['status']) {
    const documents = company.documents.map((doc, docIndex) => (docIndex === index ? { ...doc, status } : doc));
    onChange({ ...company, documents });
  }

  return (
    <div className="grid gap-5 xl:grid-cols-3">
      <Card title="بيانات الشركة">
        <div className="grid gap-3">
          <label className="grid gap-1 text-sm font-bold text-slate-700">
            اسم الشركة
            <input className="rounded-xl border border-slate-200 p-3" value={company.name} onChange={(event) => patchCompany('name', event.target.value)} />
          </label>
          <label className="grid gap-1 text-sm font-bold text-slate-700">
            السجل التجاري
            <input className="rounded-xl border border-slate-200 p-3" value={company.commercialRegistration} onChange={(event) => patchCompany('commercialRegistration', event.target.value)} />
          </label>
          <label className="grid gap-1 text-sm font-bold text-slate-700">
            رقم المنشأة
            <input className="rounded-xl border border-slate-200 p-3" value={company.establishmentNumber ?? ''} onChange={(event) => patchCompany('establishmentNumber', event.target.value)} />
          </label>
          <label className="grid gap-1 text-sm font-bold text-slate-700">
            المدينة
            <input className="rounded-xl border border-slate-200 p-3" value={company.city} onChange={(event) => patchCompany('city', event.target.value)} />
          </label>
          <label className="grid gap-1 text-sm font-bold text-slate-700">
            النشاط
            <select className="rounded-xl border border-slate-200 p-3" value={company.activity} onChange={(event) => patchCompany('activity', event.target.value)}>
              <option>التشييد والبناء</option>
              <option>التشغيل والصيانة والخدمات</option>
              <option>الاتصالات وتقنية المعلومات</option>
            </select>
          </label>
          <label className="grid gap-1 text-sm font-bold text-slate-700">
            الدرجة المستهدفة
            <select className="rounded-xl border border-slate-200 p-3" value={company.targetGrade} onChange={(event) => patchCompany('targetGrade', event.target.value as ClassificationGrade)}>
              {grades.map((grade) => <option key={grade}>{grade}</option>)}
            </select>
          </label>
          <div className="mt-3 flex flex-wrap gap-2">
            <button className="rounded-xl bg-rawasi-green px-4 py-3 font-bold text-white" type="button" onClick={onSave}>حفظ الشركة</button>
            <button className="rounded-xl border border-slate-200 px-4 py-3 font-bold" type="button" onClick={onNew}>شركة جديدة</button>
            <button className="rounded-xl border border-red-200 px-4 py-3 font-bold text-red-700" type="button" onClick={onDelete}>حذف</button>
          </div>
        </div>
      </Card>

      <Card title="القوائم المالية">
        <div className="grid grid-cols-2 gap-3">
          {([
            ['year', 'السنة'],
            ['assets', 'الأصول'],
            ['liabilities', 'الخصوم'],
            ['equity', 'حقوق الملكية'],
            ['revenue', 'الإيرادات'],
            ['netProfit', 'صافي الربح'],
            ['operatingCashFlow', 'التدفق التشغيلي'],
          ] as const).map(([field, label]) => (
            <label key={field} className="grid gap-1 text-sm font-bold text-slate-700">
              {label}
              <input className="rounded-xl border border-slate-200 p-3" type="number" value={company.financial[field]} onChange={(event) => patchFinancial(field, event)} />
            </label>
          ))}
        </div>
      </Card>

      <Card title="الفني والمستندات">
        <div className="grid grid-cols-2 gap-3">
          {([
            ['employees', 'العاملون'],
            ['engineers', 'المهندسون'],
            ['technicians', 'الفنيون'],
            ['saudiEmployees', 'السعوديون'],
            ['avgEngineerExperience', 'خبرة المهندسين'],
            ['avgTechnicianExperience', 'خبرة الفنيين'],
          ] as const).map(([field, label]) => (
            <label key={field} className="grid gap-1 text-sm font-bold text-slate-700">
              {label}
              <input className="rounded-xl border border-slate-200 p-3" type="number" value={company.technical[field]} onChange={(event) => patchTechnical(field, event)} />
            </label>
          ))}
        </div>
        <div className="mt-5 grid gap-2">
          {company.documents.map((doc, index) => (
            <label key={doc.key} className="flex items-center justify-between gap-3 rounded-xl bg-slate-50 p-3 text-sm font-bold text-slate-700">
              {doc.title}
              <select className="rounded-lg border border-slate-200 p-2" value={doc.status} onChange={(event) => patchDocument(index, event.target.value as DocumentStatus['status'])}>
                {documentStatuses.map((status) => <option key={status}>{status}</option>)}
              </select>
            </label>
          ))}
        </div>
      </Card>
    </div>
  );
}
