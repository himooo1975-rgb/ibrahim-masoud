import type { AuditLogEntry } from '../../lib/types';
import { Card } from '../../components/Card';

export function AuditTimeline({ entries }: { entries: AuditLogEntry[] }) {
  return (
    <Card title="سجل العمليات">
      <div className="grid gap-2">
        {entries.slice(0, 8).map((entry) => (
          <div className="rounded-xl bg-slate-50 p-3 text-sm" key={entry.id}>
            <p className="font-bold text-slate-700">{entry.description}</p>
            <p className="mt-1 text-xs text-slate-500">{new Date(entry.createdAt).toLocaleString('ar-SA')}</p>
          </div>
        ))}
      </div>
    </Card>
  );
}
