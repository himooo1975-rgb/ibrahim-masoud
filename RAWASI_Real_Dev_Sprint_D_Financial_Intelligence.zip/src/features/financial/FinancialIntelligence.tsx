import { useMemo } from 'react';
import { AlertTriangle, BadgeCheck, LineChart, ShieldCheck } from 'lucide-react';
import { Card } from '../../components/Card';
import { analyzeFinancialStatement, type FinancialMetric } from '../../engines/financial/financialEngine';
import type { Company, FinancialStatement } from '../../lib/types';

interface FinancialIntelligenceProps {
  company: Company;
  onChange: (company: Company) => void;
}

const fields: Array<[keyof FinancialStatement, string]> = [
  ['year', 'السنة المالية'],
  ['assets', 'إجمالي الأصول'],
  ['liabilities', 'إجمالي الخصوم'],
  ['equity', 'حقوق الملكية'],
  ['revenue', 'الإيرادات'],
  ['netProfit', 'صافي الربح'],
  ['operatingCashFlow', 'التدفق النقدي التشغيلي'],
];

function toNumber(value: string) {
  return Number.isFinite(Number(value)) ? Number(value) : 0;
}

function formatMetricValue(metric: FinancialMetric) {
  if (metric.unit === 'percent') return `${(metric.value * 100).toFixed(1)}%`;
  if (metric.unit === 'currency') return `${Math.round(metric.value).toLocaleString('ar-SA')} ريال`;
  if (metric.unit === 'days') return `${Math.round(metric.value).toLocaleString('ar-SA')} يوم`;
  return metric.value.toFixed(2);
}

function statusClass(status: FinancialMetric['status']) {
  if (status === 'قوي') return 'bg-emerald-50 text-emerald-700 border-emerald-200';
  if (status === 'متوسط') return 'bg-amber-50 text-amber-700 border-amber-200';
  if (status === 'ضعيف') return 'bg-red-50 text-red-700 border-red-200';
  return 'bg-slate-50 text-slate-600 border-slate-200';
}

export function FinancialIntelligence({ company, onChange }: FinancialIntelligenceProps) {
  const analysis = useMemo(() => analyzeFinancialStatement(company.financial), [company.financial]);
  const grouped = analysis.metrics.reduce<Record<string, FinancialMetric[]>>((acc, metric) => {
    acc[metric.category] = [...(acc[metric.category] ?? []), metric];
    return acc;
  }, {});

  function patchFinancial(field: keyof FinancialStatement, value: string) {
    onChange({ ...company, financial: { ...company.financial, [field]: toNumber(value) } });
  }

  return (
    <section className="grid gap-5">
      <Card title="RAWASI Financial Intelligence · مركز الذكاء المالي">
        <div className="grid gap-5 lg:grid-cols-[.9fr_1.1fr]">
          <div className="grid gap-3">
            {fields.map(([field, label]) => (
              <label key={field} className="grid gap-1 text-sm font-bold text-slate-700">
                {label}
                <input
                  className="rounded-xl border border-slate-200 p-3"
                  type="number"
                  value={company.financial[field]}
                  onChange={(event) => patchFinancial(field, event.target.value)}
                />
              </label>
            ))}
          </div>
          <div className="grid content-start gap-4">
            <div className="rounded-3xl bg-gradient-to-l from-rawasi-navy to-rawasi-blue p-6 text-white">
              <p className="text-sm text-white/70">درجة التقييم الائتماني المالي</p>
              <div className="mt-3 flex items-end justify-between gap-3">
                <strong className="text-6xl font-black">{analysis.creditGrade}</strong>
                <span className="text-3xl font-black">{analysis.creditScore}/100</span>
              </div>
              <p className="mt-4 text-white/80">مستوى المخاطر: {analysis.riskLevel}</p>
            </div>
            <div className="grid gap-3 md:grid-cols-3">
              <div className="rounded-2xl bg-white p-4 shadow-sm"><ShieldCheck className="text-rawasi-green" /><b className="mt-2 block text-2xl text-rawasi-navy">{analysis.categoryScores['السيولة']}%</b><span className="text-sm text-slate-500">السيولة</span></div>
              <div className="rounded-2xl bg-white p-4 shadow-sm"><LineChart className="text-rawasi-green" /><b className="mt-2 block text-2xl text-rawasi-navy">{analysis.categoryScores['الربحية']}%</b><span className="text-sm text-slate-500">الربحية</span></div>
              <div className="rounded-2xl bg-white p-4 shadow-sm"><BadgeCheck className="text-rawasi-green" /><b className="mt-2 block text-2xl text-rawasi-navy">{analysis.categoryScores['المديونية']}%</b><span className="text-sm text-slate-500">المديونية</span></div>
            </div>
            {analysis.validation.length > 0 && (
              <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4">
                <b className="flex items-center gap-2 text-amber-800"><AlertTriangle size={18} /> ملاحظات جودة القوائم</b>
                <ul className="mt-3 grid gap-2 text-sm text-amber-900">
                  {analysis.validation.map((issue) => <li key={issue.message}>• {issue.message}</li>)}
                </ul>
              </div>
            )}
          </div>
        </div>
      </Card>

      <div className="grid gap-5 xl:grid-cols-2">
        {Object.entries(grouped).map(([category, metrics]) => (
          <Card key={category} title={`مؤشرات ${category}`}>
            <div className="grid gap-3">
              {metrics.map((metric) => (
                <div key={metric.key} className="rounded-2xl border border-slate-200 p-4">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div>
                      <b className="text-rawasi-navy">{metric.title}</b>
                      <p className="mt-1 text-sm leading-6 text-slate-500">{metric.interpretation}</p>
                    </div>
                    <span className={`rounded-full border px-3 py-1 text-xs font-bold ${statusClass(metric.status)}`}>{metric.status}</span>
                  </div>
                  <p className="mt-3 text-2xl font-black text-rawasi-blue">{formatMetricValue(metric)}</p>
                </div>
              ))}
            </div>
          </Card>
        ))}
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card title="نقاط القوة المالية">
          <ul className="grid gap-3 text-sm leading-7 text-slate-700">
            {(analysis.strengths.length ? analysis.strengths : ['لا توجد نقاط قوة مالية واضحة بعد إدخال البيانات الحالية.']).map((item) => <li key={item} className="rounded-xl bg-emerald-50 p-3 text-emerald-900">{item}</li>)}
          </ul>
        </Card>
        <Card title="توصيات التحسين المالي">
          <ul className="grid gap-3 text-sm leading-7 text-slate-700">
            {(analysis.recommendations.length ? analysis.recommendations : ['المركز المالي الحالي لا يحتاج توصيات حرجة بناءً على البيانات المدخلة.']).map((item) => <li key={item} className="rounded-xl bg-slate-50 p-3">{item}</li>)}
          </ul>
        </Card>
      </div>
    </section>
  );
}
