import { seedCompany } from '../../data/defaults';

export const sampleCompany = seedCompany;
