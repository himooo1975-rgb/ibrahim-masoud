import type { EngineResult } from '../../lib/types';

export function prioritizeRecommendations(result: EngineResult): string[] {
  return result.recommendations.length
    ? result.recommendations
    : ['الملف في وضع جيد؛ يوصى بالمراجعة النهائية قبل التقديم.'];
}
