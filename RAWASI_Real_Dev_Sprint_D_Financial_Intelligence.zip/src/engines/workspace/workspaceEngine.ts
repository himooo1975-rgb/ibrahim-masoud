import type { Company, EngineResult, WorkspaceSectionStatus } from '../../lib/types';

function clamp(value: number) {
  return Math.max(0, Math.min(100, Math.round(value)));
}

function sectionStatus(readiness: number): WorkspaceSectionStatus['status'] {
  if (readiness >= 80) return 'مكتمل';
  if (readiness >= 45) return 'يحتاج عمل';
  return 'حرج';
}

export function buildWorkspaceSections(company: Company, result: EngineResult): WorkspaceSectionStatus[] {
  const profileChecks = [
    Boolean(company.name.trim()),
    Boolean(company.commercialRegistration.trim()),
    Boolean(company.establishmentNumber?.trim()),
    company.owners.some((owner) => owner.name.trim()),
    company.boardMembers.some((member) => member.name.trim()),
    company.branches.some((branch) => branch.city.trim()),
  ];
  const profileReadiness = clamp((profileChecks.filter(Boolean).length / profileChecks.length) * 100);

  const financialChecks = [
    company.financial.assets > 0,
    company.financial.liabilities >= 0,
    company.financial.equity > 0,
    company.financial.revenue > 0,
    company.financial.netProfit !== 0,
    company.financial.operatingCashFlow !== 0,
  ];
  const financialReadiness = clamp((financialChecks.filter(Boolean).length / financialChecks.length) * 100);

  const technicalChecks = [
    company.technical.employees > 0,
    company.technical.engineers > 0,
    company.technical.technicians > 0,
    company.technical.saudiEmployees > 0,
    (company.technical.equipmentCount ?? 0) > 0,
    company.projects.some((project) => project.name.trim()),
  ];
  const technicalReadiness = clamp((technicalChecks.filter(Boolean).length / technicalChecks.length) * 100);

  const documentReadiness = company.documents.length ? clamp((company.documents.filter((doc) => doc.status === 'مكتمل').length / company.documents.length) * 100) : 0;
  const classificationReadiness = clamp((result.confidence * 0.45) + (result.score * 0.35) + (documentReadiness * 0.2));

  return [
    {
      key: 'profile',
      title: 'بيانات الشركة',
      readiness: profileReadiness,
      status: sectionStatus(profileReadiness),
      notes: [
        profileReadiness < 100 ? 'استكمال الملاك، مجلس الإدارة، الفروع، ورقم المنشأة يرفع جاهزية الملف.' : 'بيانات الشركة الأساسية مكتملة.',
      ],
    },
    {
      key: 'financial',
      title: 'المركز المالي',
      readiness: financialReadiness,
      status: sectionStatus(financialReadiness),
      notes: [financialReadiness < 100 ? 'تحتاج القوائم إلى أرقام كاملة للأصول والخصوم والإيرادات والتدفقات.' : 'القوائم المالية قابلة للتحليل.'],
    },
    {
      key: 'technical',
      title: 'المركز الفني',
      readiness: technicalReadiness,
      status: sectionStatus(technicalReadiness),
      notes: [technicalReadiness < 100 ? 'استكمال الكوادر والمعدات والمشاريع يعزز التقييم الفني.' : 'البيانات الفنية الأساسية مكتملة.'],
    },
    {
      key: 'documents',
      title: 'مركز المستندات',
      readiness: documentReadiness,
      status: sectionStatus(documentReadiness),
      notes: [documentReadiness < 100 ? 'يوجد مستندات ناقصة أو تحتاج تحديثًا.' : 'ملف المستندات مكتمل.'],
    },
    {
      key: 'classification',
      title: 'مركز التصنيف',
      readiness: classificationReadiness,
      status: sectionStatus(classificationReadiness),
      notes: [
        `التصنيف المتوقع ${result.grade} بدرجة ثقة ${result.confidence}%.`,
        classificationReadiness < 80 ? 'الملف يحتاج معالجة قبل التقديم.' : 'الملف قريب من الجاهزية للتقديم.',
      ],
    },
  ];
}

export function overallWorkspaceReadiness(sections: WorkspaceSectionStatus[]) {
  if (!sections.length) return 0;
  return clamp(sections.reduce((sum, section) => sum + section.readiness, 0) / sections.length);
}
