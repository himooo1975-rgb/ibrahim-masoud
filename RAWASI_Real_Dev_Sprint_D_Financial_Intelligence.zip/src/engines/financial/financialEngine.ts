import type { FinancialStatement } from '../../lib/types';

export interface FinancialMetric {
  key: string;
  title: string;
  category: 'السيولة' | 'الربحية' | 'المديونية' | 'النشاط' | 'التدفقات النقدية' | 'النمو' | 'الجودة';
  value: number;
  unit: 'ratio' | 'percent' | 'currency' | 'days' | 'score';
  status: 'قوي' | 'متوسط' | 'ضعيف' | 'غير متاح';
  interpretation: string;
}

export interface FinancialValidationIssue {
  severity: 'info' | 'warning' | 'critical';
  message: string;
}

export interface FinancialAnalysisResult {
  year: number;
  metrics: FinancialMetric[];
  validation: FinancialValidationIssue[];
  categoryScores: Record<FinancialMetric['category'], number>;
  creditScore: number;
  creditGrade: 'A' | 'B' | 'C' | 'D' | 'E';
  riskLevel: 'منخفض' | 'متوسط' | 'مرتفع';
  strengths: string[];
  weaknesses: string[];
  recommendations: string[];
}

export interface FinancialRatios {
  currentStrength: number;
  leverageRisk: number;
  profitability: number;
  cashFlowStrength: number;
  score: number;
}

function safeDivide(numerator: number, denominator: number) {
  if (!Number.isFinite(numerator) || !Number.isFinite(denominator) || denominator === 0) return 0;
  return numerator / denominator;
}

function clamp(value: number, min = 0, max = 100) {
  return Math.min(max, Math.max(min, value));
}

function statusFromScore(score: number): FinancialMetric['status'] {
  if (!Number.isFinite(score)) return 'غير متاح';
  if (score >= 70) return 'قوي';
  if (score >= 45) return 'متوسط';
  return 'ضعيف';
}

function metric(
  key: string,
  title: string,
  category: FinancialMetric['category'],
  value: number,
  unit: FinancialMetric['unit'],
  score: number,
  interpretation: string,
): FinancialMetric {
  return { key, title, category, value: Number.isFinite(value) ? value : 0, unit, status: statusFromScore(score), interpretation };
}

function getInventoryProxy(statement: FinancialStatement) {
  return Math.max(0, statement.assets * 0.08);
}

function getReceivablesProxy(statement: FinancialStatement) {
  return Math.max(0, statement.revenue * 0.16);
}

function getCurrentAssetsProxy(statement: FinancialStatement) {
  return Math.max(0, statement.assets * 0.48);
}

function getCurrentLiabilitiesProxy(statement: FinancialStatement) {
  return Math.max(0, statement.liabilities * 0.55);
}

export function validateFinancialStatement(statement: FinancialStatement): FinancialValidationIssue[] {
  const issues: FinancialValidationIssue[] = [];
  if (!statement.year || statement.year < 2000) issues.push({ severity: 'critical', message: 'السنة المالية غير صحيحة.' });
  if (statement.assets <= 0) issues.push({ severity: 'critical', message: 'الأصول يجب أن تكون أكبر من صفر.' });
  if (statement.revenue <= 0) issues.push({ severity: 'warning', message: 'الإيرادات غير مدخلة أو تساوي صفر.' });
  const balanceGap = Math.abs(statement.assets - (statement.liabilities + statement.equity));
  if (statement.assets > 0 && balanceGap / statement.assets > 0.03) {
    issues.push({ severity: 'warning', message: 'المعادلة المحاسبية غير متزنة: الأصول لا تساوي الخصوم + حقوق الملكية.' });
  }
  if (statement.equity < 0) issues.push({ severity: 'critical', message: 'حقوق الملكية سالبة؛ هذا مؤشر خطر ائتماني مرتفع.' });
  if (statement.operatingCashFlow < 0) issues.push({ severity: 'warning', message: 'التدفقات النقدية التشغيلية سالبة.' });
  return issues;
}

export function calculateFinancialRatios(statement: FinancialStatement): FinancialRatios {
  const analysis = analyzeFinancialStatement(statement);
  const categoryScores = analysis.categoryScores;
  return {
    currentStrength: categoryScores['السيولة'],
    leverageRisk: categoryScores['المديونية'],
    profitability: categoryScores['الربحية'],
    cashFlowStrength: categoryScores['التدفقات النقدية'],
    score: analysis.creditScore,
  };
}

export function analyzeFinancialStatement(statement: FinancialStatement): FinancialAnalysisResult {
  const currentAssets = getCurrentAssetsProxy(statement);
  const currentLiabilities = getCurrentLiabilitiesProxy(statement);
  const inventory = getInventoryProxy(statement);
  const receivables = getReceivablesProxy(statement);
  const assets = Math.max(0, statement.assets);
  const liabilities = Math.max(0, statement.liabilities);
  const equity = statement.equity;
  const revenue = Math.max(0, statement.revenue);
  const netProfit = statement.netProfit;
  const operatingCashFlow = statement.operatingCashFlow;

  const currentRatio = safeDivide(currentAssets, currentLiabilities);
  const quickRatio = safeDivide(currentAssets - inventory, currentLiabilities);
  const cashRatio = safeDivide(operatingCashFlow > 0 ? operatingCashFlow : 0, currentLiabilities);
  const workingCapitalRatio = safeDivide(currentAssets - currentLiabilities, assets);
  const equityRatio = safeDivide(equity, assets);
  const debtRatio = safeDivide(liabilities, assets);
  const debtToEquity = safeDivide(liabilities, equity || 1);
  const financialLeverage = safeDivide(assets, equity || 1);
  const netMargin = safeDivide(netProfit, revenue);
  const roa = safeDivide(netProfit, assets);
  const roe = safeDivide(netProfit, equity || 1);
  const assetTurnover = safeDivide(revenue, assets);
  const receivableTurnover = safeDivide(revenue, receivables || 1);
  const collectionDays = safeDivide(365, receivableTurnover || 1);
  const inventoryTurnover = safeDivide(revenue * 0.72, inventory || 1);
  const ocfMargin = safeDivide(operatingCashFlow, revenue);
  const ocfToLiabilities = safeDivide(operatingCashFlow, liabilities || 1);
  const ocfToNetProfit = safeDivide(operatingCashFlow, netProfit || 1);
  const retainedEarningsProxy = Math.max(0, equity + netProfit);
  const retainedEarningsToAssets = safeDivide(retainedEarningsProxy, assets);
  const interestCoverageProxy = safeDivide(netProfit + Math.max(0, liabilities * 0.04), Math.max(1, liabilities * 0.04));

  const metricSpecs: Array<[string, string, FinancialMetric['category'], number, FinancialMetric['unit'], number, string]> = [
    ['current_ratio', 'نسبة التداول', 'السيولة', currentRatio, 'ratio', clamp(currentRatio * 45), 'تقيس قدرة الشركة على تغطية الالتزامات القصيرة من الأصول المتداولة.'],
    ['quick_ratio', 'نسبة السيولة السريعة', 'السيولة', quickRatio, 'ratio', clamp(quickRatio * 55), 'تقيس السيولة بعد استبعاد المخزون التقديري.'],
    ['cash_ratio', 'نسبة النقد إلى الالتزامات القصيرة', 'السيولة', cashRatio, 'ratio', clamp(cashRatio * 110), 'مؤشر تحفظي يربط النقد التشغيلي بالالتزامات القصيرة.'],
    ['working_capital_ratio', 'رأس المال العامل إلى الأصول', 'السيولة', workingCapitalRatio, 'percent', clamp((workingCapitalRatio + 0.05) * 180), 'يوضح هامش الأمان التشغيلي في رأس المال العامل.'],

    ['net_margin', 'هامش صافي الربح', 'الربحية', netMargin, 'percent', clamp(netMargin * 520), 'يقيس قدرة الشركة على تحويل الإيرادات إلى أرباح صافية.'],
    ['roa', 'العائد على الأصول', 'الربحية', roa, 'percent', clamp(roa * 850), 'يقيس كفاءة استخدام الأصول في توليد الربح.'],
    ['roe', 'العائد على حقوق الملكية', 'الربحية', roe, 'percent', clamp(roe * 420), 'يقيس العائد المحقق للملاك من حقوق الملكية.'],
    ['gross_profit_proxy', 'هامش ربح تقديري', 'الربحية', safeDivide(revenue * 0.28, revenue), 'percent', 58, 'مؤشر تقديري لحين إدخال تكلفة الإيرادات تفصيليًا.'],

    ['debt_ratio', 'نسبة المديونية', 'المديونية', debtRatio, 'percent', clamp((1 - debtRatio) * 140), 'كلما انخفضت المديونية تحسنت القدرة الائتمانية.'],
    ['equity_ratio', 'حقوق الملكية إلى الأصول', 'المديونية', equityRatio, 'percent', clamp(equityRatio * 160), 'يوضح نسبة تمويل الأصول من حقوق الملاك.'],
    ['debt_to_equity', 'الخصوم إلى حقوق الملكية', 'المديونية', debtToEquity, 'ratio', clamp(100 - debtToEquity * 28), 'يقيس ضغط الالتزامات مقارنة بحقوق الملكية.'],
    ['financial_leverage', 'الرافعة المالية', 'المديونية', financialLeverage, 'ratio', clamp(105 - financialLeverage * 18), 'ارتفاع الرافعة قد يعكس اعتمادًا كبيرًا على التمويل بالديون.'],
    ['interest_coverage_proxy', 'تغطية الفوائد التقديرية', 'المديونية', interestCoverageProxy, 'ratio', clamp(interestCoverageProxy * 18), 'مؤشر تقريبي لقدرة الأرباح على تغطية تكلفة التمويل.'],

    ['asset_turnover', 'دوران الأصول', 'النشاط', assetTurnover, 'ratio', clamp(assetTurnover * 65), 'يقيس كفاءة الأصول في توليد الإيرادات.'],
    ['receivable_turnover', 'دوران الذمم التقديري', 'النشاط', receivableTurnover, 'ratio', clamp(receivableTurnover * 10), 'يقيس سرعة التحصيل بناءً على ذمم تقديرية.'],
    ['collection_days', 'أيام التحصيل التقديرية', 'النشاط', collectionDays, 'days', clamp(120 - collectionDays), 'كلما قلت أيام التحصيل تحسنت جودة التدفقات النقدية.'],
    ['inventory_turnover', 'دوران المخزون التقديري', 'النشاط', inventoryTurnover, 'ratio', clamp(inventoryTurnover * 8), 'مؤشر تقديري لحين إدخال المخزون وتكلفة الإيرادات.'],

    ['ocf_margin', 'هامش التدفق النقدي التشغيلي', 'التدفقات النقدية', ocfMargin, 'percent', clamp(ocfMargin * 520), 'يقيس قدرة الإيرادات على توليد نقد تشغيلي.'],
    ['ocf_to_liabilities', 'التدفق التشغيلي إلى الخصوم', 'التدفقات النقدية', ocfToLiabilities, 'percent', clamp(ocfToLiabilities * 260), 'يقيس قدرة النقد التشغيلي على خدمة الالتزامات.'],
    ['ocf_to_net_profit', 'جودة الأرباح النقدية', 'التدفقات النقدية', ocfToNetProfit, 'ratio', clamp(ocfToNetProfit * 80), 'يقارن النقد التشغيلي بصافي الربح للتحقق من جودة الأرباح.'],
    ['free_cash_flow_proxy', 'التدفق الحر التقديري', 'التدفقات النقدية', operatingCashFlow - Math.max(0, assets * 0.03), 'currency', clamp(safeDivide(operatingCashFlow - assets * 0.03, revenue) * 520), 'تقدير أولي للتدفق الحر بعد مصروفات رأسمالية تقديرية.'],

    ['retained_to_assets', 'الأرباح المحتجزة التقديرية إلى الأصول', 'الجودة', retainedEarningsToAssets, 'percent', clamp(retainedEarningsToAssets * 120), 'يقيس تراكم القيمة داخل الشركة.'],
    ['balance_quality', 'جودة اتزان القوائم', 'الجودة', Math.abs(assets - (liabilities + equity)), 'currency', clamp(100 - safeDivide(Math.abs(assets - (liabilities + equity)), assets) * 600), 'يقيس مدى اتزان الأصول مع الخصوم وحقوق الملكية.'],
    ['profit_cash_alignment', 'توافق الربح والنقد', 'الجودة', Math.abs(netProfit - operatingCashFlow), 'currency', clamp(100 - safeDivide(Math.abs(netProfit - operatingCashFlow), Math.max(1, Math.abs(netProfit))) * 55), 'يقيس الفرق بين الربح المحاسبي والنقد التشغيلي.'],
  ];

  const metrics = metricSpecs.map(([key, title, category, value, unit, score, interpretation]) => metric(key, title, category, value, unit, score, interpretation));
  const categories: FinancialMetric['category'][] = ['السيولة', 'الربحية', 'المديونية', 'النشاط', 'التدفقات النقدية', 'النمو', 'الجودة'];
  const categoryScores = Object.fromEntries(categories.map((category) => {
    const items = metrics.filter((item) => item.category === category);
    if (!items.length) return [category, 50];
    const score = Math.round(items.reduce((sum, item) => sum + (item.status === 'قوي' ? 85 : item.status === 'متوسط' ? 58 : item.status === 'ضعيف' ? 25 : 0), 0) / items.length);
    return [category, score];
  })) as Record<FinancialMetric['category'], number>;

  const creditScore = Math.round(
    categoryScores['السيولة'] * 0.18 +
      categoryScores['الربحية'] * 0.20 +
      categoryScores['المديونية'] * 0.22 +
      categoryScores['النشاط'] * 0.12 +
      categoryScores['التدفقات النقدية'] * 0.18 +
      categoryScores['الجودة'] * 0.10,
  );

  const creditGrade: FinancialAnalysisResult['creditGrade'] = creditScore >= 85 ? 'A' : creditScore >= 70 ? 'B' : creditScore >= 55 ? 'C' : creditScore >= 40 ? 'D' : 'E';
  const riskLevel: FinancialAnalysisResult['riskLevel'] = creditScore >= 75 ? 'منخفض' : creditScore >= 55 ? 'متوسط' : 'مرتفع';
  const strengths = metrics.filter((item) => item.status === 'قوي').slice(0, 5).map((item) => `${item.title}: ${item.interpretation}`);
  const weaknesses = metrics.filter((item) => item.status === 'ضعيف').slice(0, 5).map((item) => `${item.title}: ${item.interpretation}`);
  const recommendations = [
    ...(categoryScores['السيولة'] < 60 ? ['تحسين رأس المال العامل وتسريع التحصيل لرفع مؤشر السيولة.'] : []),
    ...(categoryScores['المديونية'] < 60 ? ['خفض الالتزامات أو زيادة حقوق الملكية لتحسين القدرة الائتمانية.'] : []),
    ...(categoryScores['التدفقات النقدية'] < 60 ? ['تركيز خطة التحسين على تحويل الأرباح إلى تدفقات تشغيلية فعلية.'] : []),
    ...(categoryScores['الربحية'] < 60 ? ['مراجعة هوامش المشاريع وتكاليف التشغيل لتحسين الربحية.'] : []),
  ];

  return {
    year: statement.year,
    metrics,
    validation: validateFinancialStatement(statement),
    categoryScores,
    creditScore,
    creditGrade,
    riskLevel,
    strengths,
    weaknesses,
    recommendations,
  };
}
