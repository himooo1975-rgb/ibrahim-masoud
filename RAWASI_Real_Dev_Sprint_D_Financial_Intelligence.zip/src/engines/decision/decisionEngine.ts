import type { Company, EngineResult } from '../../lib/types';

export function buildDecision(company: Company, result: EngineResult): string {
  return `التوصية الحالية لشركة ${company.name}: التصنيف المتوقع ${result.grade} بدرجة ${result.score}/100 وثقة ${result.confidence}%.`;
}
