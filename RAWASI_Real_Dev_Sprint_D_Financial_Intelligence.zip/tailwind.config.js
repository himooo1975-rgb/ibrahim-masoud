/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        rawasi: {
          navy: '#0B2D3A',
          blue: '#176B87',
          green: '#0B7A70',
          lime: '#78B82A',
          sand: '#F3F7F6',
        },
      },
      fontFamily: {
        sans: ['Tajawal', 'Segoe UI', 'Tahoma', 'Arial', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
