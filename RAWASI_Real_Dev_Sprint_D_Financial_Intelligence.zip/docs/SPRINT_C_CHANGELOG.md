# Sprint C Changelog

## Added
- `CompanyWorkspace` component.
- `workspaceEngine`.
- Expanded Company domain model: owners, boardMembers, branches, projects.
- Workspace readiness sections.
- Document expiry dates.

## Changed
- App navigation now supports Workspace / Edit / Decision / Audit views.
- Repository now migrates Sprint B data to the expanded Sprint C schema.
- Seed data now includes owners, board members, branches, and projects.

## Verified
- `npm run check`
- `npm run build`
