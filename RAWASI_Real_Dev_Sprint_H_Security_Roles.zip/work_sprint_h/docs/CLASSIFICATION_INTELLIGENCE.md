# RAWASI Sprint E — Classification Intelligence

هذا الإصدار يضيف أول نسخة عملية من ذكاء التصنيف داخل منصة الرواسي.

## الوحدات الجديدة

- `ClassificationIntelligenceEngine`
- `Gap Analysis`
- `Next Best Actions`
- `Scenario Simulator`
- `Classification Confidence`

## الهدف

تحويل نتيجة التصنيف من رقم ودرجة إلى قرار قابل للتفسير، بحيث يعرف المستشار:

1. الدرجة الحالية.
2. الدرجة المستهدفة.
3. الفجوة بالنقاط.
4. البنود المؤثرة.
5. أسرع طريق للتحسين.
6. أثر السيناريوهات قبل تنفيذها.

## مسار القرار

```text
Company Data
  -> Financial Engine
  -> Technical Score
  -> Document Score
  -> Classification Intelligence
  -> Gap Analysis
  -> Simulator
  -> Decision / Recommendations
```

## ملاحظات هندسية

- لم يتم وضع قواعد التصنيف النهائية داخل الواجهة.
- تم بناء المحرك كطبقة مستقلة قابلة للاستبدال بقواعد وزارة التصنيف التفصيلية لاحقًا.
- المحاكي لا يحفظ السيناريوهات على بيانات الشركة الأصلية، بل يحسب نسخة افتراضية فقط.
