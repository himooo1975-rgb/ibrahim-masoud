# Sprint G Changelog

## Added
- Smart Documents navigation tab.
- Financial Import Engine.
- Arabic/English field matching for financial statements.
- Confidence score for imported financial values.
- Warnings for missing fields and accounting imbalance.
- Direct approval flow that updates the company financial statement and marks financial documents as complete.

## Verified
- `npm run check`
- `npm run build`
