# Sprint H Changelog

## Added
- Security Center page.
- Local user and role management.
- Permission Engine with explicit permission keys.
- Security advisory widget.
- Permission matrix.
- Snapshot migration to include users and current session.

## Changed
- App header now shows the active user and role.
- Save company, delete company, backup export/import now check permissions.
- Audit log limit increased to 500 records.

## Verified
- `npm run check`
- `npm run build`
