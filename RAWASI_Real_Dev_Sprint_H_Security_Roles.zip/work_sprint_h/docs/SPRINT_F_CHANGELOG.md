# Sprint F Changelog — Executive Reports & Client Deliverables

## Added

- إضافة `ExecutiveReportEngine`.
- إضافة صفحة `التقرير التنفيذي` داخل التنقل الرئيسي.
- توليد مؤشرات تنفيذية من محركات التصنيف والماليات والفجوات.
- تصدير تقرير HTML قابل للطباعة والحفظ PDF من المتصفح.
- تصدير مؤشرات KPI بصيغة CSV قابلة للفتح في Excel.
- إضافة وثيقة `EXECUTIVE_REPORTING.md`.

## Updated

- تحديث الرسالة الرئيسية إلى Sprint F.
- ربط التقرير بنتيجة `Classification Engine` و`Classification Intelligence`.

## Verification

- `npm run check`
- `npm run build`
