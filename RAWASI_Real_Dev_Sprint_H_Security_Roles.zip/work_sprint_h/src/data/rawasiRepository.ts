import { defaultBoardMembers, defaultBranches, defaultDocuments, defaultOwners, defaultProjects, defaultTechnicalProfile, seedCompany } from './defaults';
import type { AuditLogEntry, Company, RawasiSnapshot, RawasiUser } from '../lib/types';

const STORAGE_KEY = 'rawasi.enterprise.snapshot.v2';
const LEGACY_STORAGE_KEY = 'rawasi.enterprise.snapshot.v1';

function now() {
  return new Date().toISOString();
}

function createAudit(entityId: string, action: AuditLogEntry['action'], description: string, entityType: AuditLogEntry['entityType'] = 'company'): AuditLogEntry {
  return {
    id: crypto.randomUUID(),
    entityType,
    entityId,
    action,
    description,
    createdAt: now(),
  };
}

function normalizeCompany(company: Company): Company {
  return {
    ...company,
    owners: Array.isArray(company.owners) && company.owners.length ? company.owners : defaultOwners.map((item) => ({ ...item, id: crypto.randomUUID() })),
    boardMembers: Array.isArray(company.boardMembers) && company.boardMembers.length ? company.boardMembers : defaultBoardMembers.map((item) => ({ ...item, id: crypto.randomUUID() })),
    branches: Array.isArray(company.branches) && company.branches.length ? company.branches : defaultBranches.map((item) => ({ ...item, id: crypto.randomUUID() })),
    projects: Array.isArray(company.projects) && company.projects.length ? company.projects : defaultProjects.map((item) => ({ ...item, id: crypto.randomUUID() })),
    technical: { ...defaultTechnicalProfile, ...company.technical },
    documents: Array.isArray(company.documents) && company.documents.length ? company.documents : defaultDocuments.map((doc) => ({ ...doc })),
    updatedAt: company.updatedAt ?? now(),
    createdAt: company.createdAt ?? now(),
  };
}


function defaultUsers(): RawasiUser[] {
  return [
    {
      id: 'rawasi-admin',
      name: 'مدير منصة الرواسي',
      email: 'admin@rawasi.local',
      role: 'admin',
      status: 'active',
      createdAt: now(),
      lastLoginAt: now(),
    },
    {
      id: 'rawasi-consultant',
      name: 'مستشار التصنيف',
      email: 'consultant@rawasi.local',
      role: 'classification_consultant',
      status: 'active',
      createdAt: now(),
      lastLoginAt: now(),
    },
  ];
}

function normalizeUsers(users: RawasiSnapshot['users'] | undefined): RawasiUser[] {
  if (!Array.isArray(users) || users.length === 0) return defaultUsers();
  return users.map((user) => ({
    id: user.id || crypto.randomUUID(),
    name: user.name || 'مستخدم الرواسي',
    email: user.email || 'user@rawasi.local',
    role: user.role || 'readonly',
    status: user.status || 'active',
    createdAt: user.createdAt || now(),
    lastLoginAt: user.lastLoginAt,
  }));
}

function initialSnapshot(): RawasiSnapshot {
  return {
    version: 2,
    companies: [normalizeCompany(seedCompany)],
    auditLog: [createAudit(seedCompany.id, 'create', 'إنشاء بيانات عينة البداية لمنصة الرواسي.')],
    users: defaultUsers(),
    currentUserId: 'rawasi-admin',
    updatedAt: now(),
  };
}

export class RawasiRepository {
  load(): RawasiSnapshot {
    const raw = localStorage.getItem(STORAGE_KEY) ?? localStorage.getItem(LEGACY_STORAGE_KEY);
    if (!raw) {
      const snapshot = initialSnapshot();
      this.saveSnapshot(snapshot);
      return snapshot;
    }

    try {
      const parsed = JSON.parse(raw) as RawasiSnapshot;
      if (!Array.isArray(parsed.companies)) throw new Error('Invalid companies store');
      const normalized: RawasiSnapshot = {
        version: 2,
        companies: parsed.companies.map(normalizeCompany),
        auditLog: Array.isArray(parsed.auditLog) ? parsed.auditLog : [],
        users: normalizeUsers(parsed.users),
        currentUserId: parsed.currentUserId ?? normalizeUsers(parsed.users)[0]?.id,
        updatedAt: parsed.updatedAt ?? now(),
      };
      this.saveSnapshot(normalized);
      return normalized;
    } catch {
      const snapshot = initialSnapshot();
      this.saveSnapshot(snapshot);
      return snapshot;
    }
  }

  saveCompany(company: Company): RawasiSnapshot {
    const snapshot = this.load();
    const commercialRegistration = company.commercialRegistration.trim();
    if (!company.name.trim()) throw new Error('اسم الشركة مطلوب.');
    if (!commercialRegistration) throw new Error('رقم السجل التجاري مطلوب.');

    const duplicate = snapshot.companies.find(
      (item) => item.commercialRegistration === commercialRegistration && item.id !== company.id,
    );
    if (duplicate) throw new Error('يوجد ملف شركة بنفس رقم السجل التجاري.');

    const companyToSave: Company = normalizeCompany({
      ...company,
      commercialRegistration,
      updatedAt: now(),
      documents: company.documents.map((doc) => ({ ...doc, updatedAt: doc.updatedAt ?? now() })),
    });

    const exists = snapshot.companies.some((item) => item.id === company.id);
    const companies = exists
      ? snapshot.companies.map((item) => (item.id === company.id ? companyToSave : item))
      : [companyToSave, ...snapshot.companies];

    const next: RawasiSnapshot = {
      ...snapshot,
      companies,
      auditLog: [
        createAudit(company.id, exists ? 'update' : 'create', exists ? 'تحديث ملف الشركة Workspace.' : 'إنشاء ملف شركة جديد.'),
        ...snapshot.auditLog,
      ].slice(0, 500),
      updatedAt: now(),
    };
    this.saveSnapshot(next);
    return next;
  }

  deleteCompany(companyId: string): RawasiSnapshot {
    const snapshot = this.load();
    const next: RawasiSnapshot = {
      ...snapshot,
      companies: snapshot.companies.filter((company) => company.id !== companyId),
      auditLog: [createAudit(companyId, 'delete', 'حذف ملف شركة.'), ...snapshot.auditLog].slice(0, 500),
      updatedAt: now(),
    };
    this.saveSnapshot(next);
    return next;
  }

  addAudit(entityId: string, description: string, entityType: AuditLogEntry['entityType'] = 'company'): RawasiSnapshot {
    const snapshot = this.load();
    const next = {
      ...snapshot,
      auditLog: [createAudit(entityId, 'update', description, entityType), ...snapshot.auditLog].slice(0, 500),
      updatedAt: now(),
    };
    this.saveSnapshot(next);
    return next;
  }

  exportBackup(): string {
    return JSON.stringify(this.load(), null, 2);
  }

  importBackup(json: string): RawasiSnapshot {
    const parsed = JSON.parse(json) as RawasiSnapshot;
    if (!Array.isArray(parsed.companies)) throw new Error('ملف النسخة الاحتياطية غير صالح.');
    const next: RawasiSnapshot = {
      version: 2,
      companies: parsed.companies.map(normalizeCompany),
      auditLog: [createAudit('system', 'restore', 'استعادة نسخة احتياطية.'), ...(parsed.auditLog ?? [])].slice(0, 500),
      users: normalizeUsers(parsed.users),
      currentUserId: parsed.currentUserId ?? normalizeUsers(parsed.users)[0]?.id,
      updatedAt: now(),
    };
    this.saveSnapshot(next);
    return next;
  }


  saveUsers(users: RawasiUser[], currentUserId?: string): RawasiSnapshot {
    const snapshot = this.load();
    const normalizedUsers = normalizeUsers(users);
    const nextCurrentUserId = currentUserId && normalizedUsers.some((user) => user.id === currentUserId)
      ? currentUserId
      : normalizedUsers[0]?.id;
    const next: RawasiSnapshot = {
      ...snapshot,
      users: normalizedUsers,
      currentUserId: nextCurrentUserId,
      auditLog: [createAudit('security', 'update', 'تحديث إعدادات المستخدمين والصلاحيات.', 'company'), ...snapshot.auditLog].slice(0, 500),
      updatedAt: now(),
    };
    this.saveSnapshot(next);
    return next;
  }

  setCurrentUser(userId: string): RawasiSnapshot {
    const snapshot = this.load();
    const exists = snapshot.users.some((user) => user.id === userId && user.status === 'active');
    if (!exists) return snapshot;
    const next: RawasiSnapshot = {
      ...snapshot,
      currentUserId: userId,
      users: snapshot.users.map((user) => user.id === userId ? { ...user, lastLoginAt: now() } : user),
      auditLog: [createAudit('security', 'update', 'تغيير الجلسة الحالية للمستخدم.', 'company'), ...snapshot.auditLog].slice(0, 500),
      updatedAt: now(),
    };
    this.saveSnapshot(next);
    return next;
  }

  private saveSnapshot(snapshot: RawasiSnapshot) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(snapshot));
  }
}
