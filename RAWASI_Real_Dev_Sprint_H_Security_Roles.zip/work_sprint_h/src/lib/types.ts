export type ClassificationGrade = 'الأولى' | 'الثانية' | 'الثالثة' | 'الرابعة' | 'الخامسة' | 'غير مصنف';

export interface CompanyOwner {
  id: string;
  name: string;
  sharePercent: number;
}

export interface BoardMember {
  id: string;
  name: string;
  role: 'رئيس مجلس الإدارة' | 'نائب الرئيس' | 'عضو' | 'مدير عام' | 'مفوّض';
  nationalId?: string;
}

export interface CompanyBranch {
  id: string;
  city: string;
  address?: string;
}

export interface CompanyProject {
  id: string;
  name: string;
  sector: string;
  value: number;
  status: 'منفذ' | 'قائم' | 'متوقف' | 'مخطط';
}

export interface Company {
  id: string;
  name: string;
  commercialRegistration: string;
  establishmentNumber?: string;
  city: string;
  activity: string;
  targetGrade: ClassificationGrade;
  owners: CompanyOwner[];
  boardMembers: BoardMember[];
  branches: CompanyBranch[];
  projects: CompanyProject[];
  financial: FinancialStatement;
  technical: TechnicalProfile;
  documents: DocumentStatus[];
  createdAt: string;
  updatedAt: string;
}

export interface FinancialStatement {
  year: number;
  assets: number;
  liabilities: number;
  equity: number;
  revenue: number;
  netProfit: number;
  operatingCashFlow: number;
}

export interface TechnicalProfile {
  employees: number;
  engineers: number;
  technicians: number;
  saudiEmployees: number;
  avgEngineerExperience: number;
  avgTechnicianExperience: number;
  equipmentCount?: number;
  completedProjects?: number;
}

export interface DocumentStatus {
  key: string;
  title: string;
  status: 'مكتمل' | 'ناقص' | 'يحتاج تحديث';
  expiryDate?: string;
  updatedAt?: string;
}

export interface WorkspaceSectionStatus {
  key: 'profile' | 'financial' | 'technical' | 'documents' | 'classification';
  title: string;
  readiness: number;
  status: 'مكتمل' | 'يحتاج عمل' | 'حرج';
  notes: string[];
}

export interface EngineResult {
  score: number;
  grade: ClassificationGrade;
  confidence: number;
  reasons: string[];
  recommendations: string[];
}

export interface AuditLogEntry {
  id: string;
  entityType: 'company' | 'financial' | 'technical' | 'document' | 'classification';
  entityId: string;
  action: 'create' | 'update' | 'delete' | 'evaluate' | 'restore' | 'backup';
  description: string;
  createdAt: string;
}

export interface RawasiSnapshot {
  version: 2;
  companies: Company[];
  auditLog: AuditLogEntry[];
  users: RawasiUser[];
  currentUserId?: string;
  updatedAt: string;
}

export type UserRole = 'admin' | 'classification_consultant' | 'financial_reviewer' | 'technical_reviewer' | 'readonly';

export type PermissionKey =
  | 'Company.Read'
  | 'Company.Edit'
  | 'Company.Delete'
  | 'Financial.Edit'
  | 'Financial.Approve'
  | 'Technical.Edit'
  | 'Documents.Edit'
  | 'Classification.Run'
  | 'Reports.Export'
  | 'Users.Manage'
  | 'Audit.Read';

export interface RawasiUser {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  status: 'active' | 'suspended';
  createdAt: string;
  lastLoginAt?: string;
}
