import { ShieldCheck, UserCog, Users } from 'lucide-react';
import { Card } from '../../components/Card';
import { createSecurityAdvisory, getPermissionMatrix, roleLabels } from '../../engines/security/securityEngine';
import type { RawasiUser, UserRole } from '../../lib/types';

interface SecurityCenterProps {
  users: RawasiUser[];
  currentUser: RawasiUser | null;
  onUsersChange: (users: RawasiUser[]) => void;
  onCurrentUserChange: (userId: string) => void;
}

const roles: UserRole[] = ['admin', 'classification_consultant', 'financial_reviewer', 'technical_reviewer', 'readonly'];

function createUser(): RawasiUser {
  return {
    id: crypto.randomUUID(),
    name: 'مستخدم جديد',
    email: `user-${Date.now()}@rawasi.local`,
    role: 'readonly',
    status: 'active',
    createdAt: new Date().toISOString(),
    lastLoginAt: undefined,
  };
}

export function SecurityCenter({ users, currentUser, onUsersChange, onCurrentUserChange }: SecurityCenterProps) {
  const matrix = getPermissionMatrix(users);
  const advisory = createSecurityAdvisory(currentUser, users);

  function updateUser(userId: string, patch: Partial<RawasiUser>) {
    onUsersChange(users.map((user) => (user.id === userId ? { ...user, ...patch } : user)));
  }

  function addUser() {
    onUsersChange([createUser(), ...users]);
  }

  function removeUser(userId: string) {
    const next = users.filter((user) => user.id !== userId);
    onUsersChange(next);
    if (currentUser?.id === userId && next[0]) onCurrentUserChange(next[0].id);
  }

  return (
    <div className="grid gap-5">
      <div className="grid gap-5 lg:grid-cols-3">
        <Card title="الجلسة الحالية">
          <div className="flex items-center gap-3">
            <span className="rounded-2xl bg-rawasi-navy p-3 text-white"><ShieldCheck size={24} /></span>
            <div>
              <p className="text-lg font-black">{currentUser?.name ?? 'لا يوجد مستخدم'}</p>
              <p className="text-sm text-slate-500">{currentUser ? roleLabels[currentUser.role] : 'غير محدد'}</p>
            </div>
          </div>
          <select className="mt-4 w-full rounded-xl border border-slate-200 p-3" value={currentUser?.id ?? ''} onChange={(event) => onCurrentUserChange(event.target.value)}>
            {users.map((user) => <option key={user.id} value={user.id}>{user.name} · {roleLabels[user.role]}</option>)}
          </select>
        </Card>

        <Card title="مؤشر الأمان">
          <div className={`rounded-2xl p-4 ${advisory.level === 'high' ? 'bg-red-50 text-red-800' : advisory.level === 'medium' ? 'bg-amber-50 text-amber-800' : 'bg-emerald-50 text-emerald-800'}`}>
            <p className="font-black">{advisory.title}</p>
            <p className="mt-2 text-sm leading-7">{advisory.description}</p>
          </div>
        </Card>

        <Card title="ملخص المستخدمين">
          <div className="flex items-center gap-3">
            <span className="rounded-2xl bg-rawasi-green p-3 text-white"><Users size={24} /></span>
            <div>
              <p className="text-3xl font-black">{users.length}</p>
              <p className="text-sm text-slate-500">مستخدم مسجل في البيئة المحلية</p>
            </div>
          </div>
          <button className="mt-4 w-full rounded-xl bg-rawasi-green px-4 py-3 font-black text-white" type="button" onClick={addUser}>إضافة مستخدم</button>
        </Card>
      </div>

      <Card title="إدارة المستخدمين والأدوار">
        <div className="grid gap-3">
          {users.map((user) => (
            <div key={user.id} className="grid gap-3 rounded-2xl border border-slate-200 p-4 lg:grid-cols-[1.2fr_1.2fr_1fr_1fr_auto]">
              <input className="rounded-xl border border-slate-200 p-3" value={user.name} onChange={(event) => updateUser(user.id, { name: event.target.value })} />
              <input className="rounded-xl border border-slate-200 p-3" value={user.email} onChange={(event) => updateUser(user.id, { email: event.target.value })} />
              <select className="rounded-xl border border-slate-200 p-3" value={user.role} onChange={(event) => updateUser(user.id, { role: event.target.value as UserRole })}>
                {roles.map((role) => <option key={role} value={role}>{roleLabels[role]}</option>)}
              </select>
              <select className="rounded-xl border border-slate-200 p-3" value={user.status} onChange={(event) => updateUser(user.id, { status: event.target.value as RawasiUser['status'] })}>
                <option value="active">نشط</option>
                <option value="suspended">موقوف</option>
              </select>
              <button className="rounded-xl border border-red-200 px-4 py-3 font-bold text-red-700" type="button" onClick={() => removeUser(user.id)}>حذف</button>
            </div>
          ))}
        </div>
      </Card>

      <Card title="مصفوفة الصلاحيات">
        <div className="overflow-auto">
          <table className="w-full min-w-[900px] text-sm">
            <thead>
              <tr className="bg-slate-50 text-right">
                <th className="p-3">المستخدم</th>
                <th className="p-3">الدور</th>
                {matrix[0]?.permissions.map((item) => <th key={item.permission} className="p-3 text-center">{item.permission}</th>)}
              </tr>
            </thead>
            <tbody>
              {matrix.map((row) => (
                <tr key={row.user.id} className="border-t border-slate-100">
                  <td className="p-3 font-bold">{row.user.name}</td>
                  <td className="p-3"><span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-bold">{row.roleLabel}</span></td>
                  {row.permissions.map((item) => (
                    <td key={item.permission} className="p-3 text-center">
                      <span className={`inline-flex h-7 w-7 items-center justify-center rounded-full text-xs font-black ${item.allowed ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-400'}`}>{item.allowed ? '✓' : '–'}</span>
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <Card title="ملاحظات Sprint H">
        <div className="grid gap-3 lg:grid-cols-3">
          <div className="rounded-2xl border border-slate-200 p-4">
            <UserCog className="text-rawasi-green" />
            <p className="mt-3 font-black">Identity محلي مؤقت</p>
            <p className="mt-2 text-sm leading-7 text-slate-600">هذا الإصدار يجهز نموذج المستخدمين والصلاحيات داخل المتصفح. التشفير وتسجيل الدخول الحقيقي سيتم ربطهما عند Sprint PostgreSQL/API.</p>
          </div>
          <div className="rounded-2xl border border-slate-200 p-4">
            <ShieldCheck className="text-rawasi-green" />
            <p className="mt-3 font-black">Permission Engine مركزي</p>
            <p className="mt-2 text-sm leading-7 text-slate-600">الواجهات يمكنها الآن الاعتماد على صلاحيات صريحة مثل Company.Edit وReports.Export بدل شروط متناثرة.</p>
          </div>
          <div className="rounded-2xl border border-slate-200 p-4">
            <Users className="text-rawasi-green" />
            <p className="mt-3 font-black">جاهز للتوسع</p>
            <p className="mt-2 text-sm leading-7 text-slate-600">نفس الموديلات ستنتقل لاحقًا إلى API وقاعدة بيانات دون إعادة تصميم تجربة المستخدم.</p>
          </div>
        </div>
      </Card>
    </div>
  );
}
