import { Download, FileSpreadsheet, Printer } from 'lucide-react';
import { Card } from '../../components/Card';
import { buildExecutiveReport, exportExecutiveReportAsCsv, exportExecutiveReportAsHtml } from '../../engines/report/executiveReportEngine';
import type { Company, EngineResult } from '../../lib/types';

function statusClass(status: string) {
  if (status === 'قوي') return 'border-emerald-200 bg-emerald-50 text-emerald-700';
  if (status === 'متوسط') return 'border-amber-200 bg-amber-50 text-amber-700';
  return 'border-red-200 bg-red-50 text-red-700';
}

function downloadFile(filename: string, content: string, type: string) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(url);
}

export function ExecutiveReports({ company, result }: { company: Company; result: EngineResult }) {
  const report = buildExecutiveReport(company, result);
  const reportHtml = exportExecutiveReportAsHtml(report);

  function printReport() {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;
    printWindow.document.write(reportHtml);
    printWindow.document.close();
    printWindow.focus();
    window.setTimeout(() => printWindow.print(), 250);
  }

  return (
    <section className="grid gap-5">
      <Card title="مركز التقرير التنفيذي">
        <div className="grid gap-5 xl:grid-cols-[1.15fr_.85fr]">
          <div>
            <div className="inline-flex rounded-full bg-rawasi-green/10 px-3 py-2 text-sm font-black text-rawasi-green">RAWASI Executive Report</div>
            <h2 className="mt-4 text-3xl font-black text-rawasi-navy">{report.companyName}</h2>
            <p className="mt-3 leading-8 text-slate-700">{report.summary}</p>
            <p className="mt-4 rounded-2xl bg-slate-50 p-4 text-sm font-bold text-slate-600">{report.boardRecommendation}</p>
          </div>
          <div className="rounded-3xl bg-gradient-to-l from-rawasi-navy to-rawasi-blue p-5 text-white">
            <p className="text-sm text-white/75">جاهزية التقديم التنفيذية</p>
            <b className="mt-3 block text-6xl">{report.readiness}%</b>
            <p className="mt-4 leading-8 text-white/85">هذا المؤشر يجمع جاهزية الملف المالي والفني والمستندي واكتمال البيانات المستخدمة في قرار التصنيف.</p>
            <div className="mt-5 flex flex-wrap gap-2">
              <button className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-3 font-black text-rawasi-navy" type="button" onClick={printReport}><Printer size={18} /> طباعة / PDF</button>
              <button className="inline-flex items-center gap-2 rounded-xl bg-white/15 px-4 py-3 font-black text-white" type="button" onClick={() => downloadFile('rawasi-executive-report.html', reportHtml, 'text/html;charset=utf-8')}><Download size={18} /> HTML</button>
              <button className="inline-flex items-center gap-2 rounded-xl bg-white/15 px-4 py-3 font-black text-white" type="button" onClick={() => downloadFile('rawasi-kpis.csv', exportExecutiveReportAsCsv(report), 'text/csv;charset=utf-8')}><FileSpreadsheet size={18} /> CSV</button>
            </div>
          </div>
        </div>
      </Card>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-5">
        {report.kpis.map((kpi) => (
          <div key={kpi.key} className={`rounded-2xl border p-4 ${statusClass(kpi.status)}`}>
            <span className="text-sm font-bold opacity-80">{kpi.title}</span>
            <b className="mt-2 block text-2xl">{kpi.value}</b>
            <p className="mt-2 text-sm leading-7">{kpi.note}</p>
          </div>
        ))}
      </div>

      <div className="grid gap-5 xl:grid-cols-3">
        {report.sections.map((section) => (
          <Card key={section.title} title={section.title}>
            {section.items.length ? (
              <ul className="space-y-2">
                {section.items.map((item) => <li key={item} className="rounded-xl bg-slate-50 p-3 text-sm leading-7 text-slate-700">{item}</li>)}
              </ul>
            ) : <p className="text-sm text-slate-500">لا توجد ملاحظات بارزة في هذا القسم حاليًا.</p>}
          </Card>
        ))}
      </div>

      <Card title="خطة العمل التنفيذية">
        <ol className="grid gap-3 md:grid-cols-2">
          {report.actionPlan.length ? report.actionPlan.map((item) => (
            <li key={item} className="rounded-2xl border border-slate-200 bg-white p-4 text-sm font-bold leading-7 text-slate-700">{item}</li>
          )) : <li className="rounded-2xl bg-emerald-50 p-4 text-emerald-700">لا توجد فجوات رئيسية؛ يوصى بالمراجعة النهائية للتقرير والمستندات.</li>}
        </ol>
      </Card>
    </section>
  );
}
