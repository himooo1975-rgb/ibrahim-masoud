import { useMemo, useState } from 'react';
import { FileText, UploadCloud, Wand2 } from 'lucide-react';
import { Card } from '../../components/Card';
import { analyzeFinancialStatement } from '../../engines/financial/financialEngine';
import { buildFinancialImportTemplate, importFinancialStatementFromText } from '../../engines/import/financialImportEngine';
import type { Company } from '../../lib/types';

interface SmartDocumentsProps {
  company: Company;
  onChange: (company: Company) => void;
}

function numberFormat(value: number) {
  return value.toLocaleString('ar-SA', { maximumFractionDigits: 2 });
}

export function SmartDocuments({ company, onChange }: SmartDocumentsProps) {
  const [sourceText, setSourceText] = useState(() => buildFinancialImportTemplate(company.financial));
  const [lastImportedAt, setLastImportedAt] = useState<string | null>(null);
  const importResult = useMemo(() => importFinancialStatementFromText(sourceText, company.financial), [sourceText, company.financial]);
  const analysis = useMemo(() => analyzeFinancialStatement(importResult.statement), [importResult.statement]);

  async function readFile(file: File | undefined) {
    if (!file) return;
    const text = await file.text();
    setSourceText(text);
  }

  function approveImport() {
    const documents = company.documents.map((doc) => (
      doc.key === 'financial_statement'
        ? { ...doc, status: 'مكتمل' as const, updatedAt: new Date().toISOString() }
        : doc
    ));
    onChange({ ...company, financial: importResult.statement, documents, updatedAt: new Date().toISOString() });
    setLastImportedAt(new Date().toLocaleString('ar-SA'));
  }

  return (
    <section className="grid gap-5">
      <Card title="مركز المستندات الذكي · Financial Import">
        <div className="grid gap-5 xl:grid-cols-[1fr_.9fr]">
          <div className="space-y-4">
            <div className="rounded-2xl bg-slate-50 p-4 text-sm leading-7 text-slate-700">
              الصق نص القوائم المالية أو ارفع ملف TXT/CSV قابل للقراءة. هذه المرحلة لا تنفذ OCR للصور بعد، لكنها تؤسس Mapping Engine قبل Sprint OCR الحقيقي.
            </div>
            <label className="inline-flex cursor-pointer items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-3 font-black text-slate-700">
              <UploadCloud size={18} /> رفع ملف نصي / CSV
              <input className="hidden" type="file" accept=".txt,.csv,.json,text/plain,text/csv,application/json" onChange={(event) => void readFile(event.target.files?.[0])} />
            </label>
            <textarea
              className="min-h-[300px] w-full rounded-2xl border border-slate-200 p-4 font-mono text-sm leading-7 outline-none focus:border-rawasi-green"
              dir="rtl"
              value={sourceText}
              onChange={(event) => setSourceText(event.target.value)}
            />
            <button className="inline-flex items-center gap-2 rounded-xl bg-rawasi-green px-5 py-3 font-black text-white" type="button" onClick={approveImport}>
              <Wand2 size={18} /> اعتماد وربط القوائم بالشركة
            </button>
            {lastImportedAt && <p className="text-sm font-bold text-emerald-700">تم اعتماد آخر ربط في: {lastImportedAt}</p>}
          </div>

          <div className="space-y-4">
            <div className="rounded-3xl bg-gradient-to-l from-rawasi-navy to-rawasi-blue p-5 text-white">
              <p className="text-sm text-white/70">ثقة الاستخراج</p>
              <b className="mt-2 block text-5xl">{importResult.confidence}%</b>
              <p className="mt-3 text-sm leading-7 text-white/80">تم التعرف على {importResult.fields.length} بنود من أصل 6 بنود مالية أساسية.</p>
            </div>

            <Card title="الأرقام المستخرجة">
              <div className="space-y-2">
                {importResult.fields.map((field) => (
                  <div key={field.key} className="rounded-xl border border-slate-200 p-3">
                    <div className="flex items-center justify-between gap-3">
                      <b className="text-slate-800">{field.title}</b>
                      <span className="rounded-full bg-emerald-50 px-3 py-1 text-sm font-bold text-emerald-700">{numberFormat(field.value)}</span>
                    </div>
                    <p className="mt-2 text-xs leading-6 text-slate-500">{field.matchedLine}</p>
                  </div>
                ))}
                {!importResult.fields.length && <p className="text-sm text-slate-500">لا توجد بنود مستخرجة بعد.</p>}
              </div>
            </Card>

            <Card title="تحقق وربط مالي">
              <ul className="space-y-2">
                {importResult.warnings.map((warning) => <li key={warning} className="rounded-xl bg-amber-50 p-3 text-sm font-bold text-amber-800">{warning}</li>)}
                {!importResult.warnings.length && <li className="rounded-xl bg-emerald-50 p-3 text-sm font-bold text-emerald-800">لا توجد تحذيرات جوهرية في بيانات الاستخراج.</li>}
              </ul>
              <div className="mt-4 grid gap-3 sm:grid-cols-3">
                <div className="rounded-xl bg-slate-50 p-3"><span className="text-xs text-slate-500">Credit</span><b className="block text-xl text-rawasi-navy">{analysis.creditGrade}</b></div>
                <div className="rounded-xl bg-slate-50 p-3"><span className="text-xs text-slate-500">Score</span><b className="block text-xl text-rawasi-navy">{analysis.creditScore}/100</b></div>
                <div className="rounded-xl bg-slate-50 p-3"><span className="text-xs text-slate-500">Risk</span><b className="block text-xl text-rawasi-navy">{analysis.riskLevel}</b></div>
              </div>
            </Card>

            <Card title="معاينة المصدر">
              <ol className="list-decimal space-y-2 pr-5 text-sm leading-7 text-slate-600">
                {importResult.sourcePreview.map((line) => <li key={line}>{line}</li>)}
              </ol>
            </Card>
          </div>
        </div>
      </Card>
    </section>
  );
}
