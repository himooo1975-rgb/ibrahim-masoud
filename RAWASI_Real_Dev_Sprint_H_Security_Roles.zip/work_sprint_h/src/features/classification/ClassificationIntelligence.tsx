import { useMemo, useState } from 'react';
import { BrainCircuit, Gauge, Route, Sparkles, Target, TrendingUp } from 'lucide-react';
import { Card } from '../../components/Card';
import { buildClassificationIntelligence, type ScenarioInput } from '../../engines/classification/classificationIntelligenceEngine';
import type { Company, EngineResult } from '../../lib/types';

function statusColor(value: number) {
  if (value >= 75) return 'text-emerald-700 bg-emerald-50 border-emerald-200';
  if (value >= 50) return 'text-amber-700 bg-amber-50 border-amber-200';
  return 'text-red-700 bg-red-50 border-red-200';
}

function priorityClass(priority: string) {
  if (priority === 'عاجلة') return 'bg-red-50 text-red-700 border-red-200';
  if (priority === 'مرتفعة') return 'bg-amber-50 text-amber-700 border-amber-200';
  if (priority === 'متوسطة') return 'bg-blue-50 text-blue-700 border-blue-200';
  return 'bg-slate-50 text-slate-700 border-slate-200';
}

export function ClassificationIntelligence({ company, result }: { company: Company; result: EngineResult }) {
  const intelligence = useMemo(() => buildClassificationIntelligence(company, result), [company, result]);
  const completedDocuments = company.documents.filter((doc) => doc.status === 'مكتمل').length;
  const [scenario, setScenario] = useState<ScenarioInput>({
    equityIncreasePercent: 10,
    liabilityReductionPercent: 5,
    extraEngineers: 2,
    extraTechnicians: 3,
    extraSaudiEmployees: 2,
    completedDocuments: company.documents.length,
  });
  const scenarioResult = useMemo(() => intelligence.simulate(scenario), [intelligence, scenario]);

  function patchScenario<K extends keyof ScenarioInput>(key: K, value: string) {
    setScenario((current) => ({ ...current, [key]: Number(value) || 0 }));
  }

  return (
    <section className="grid gap-5">
      <Card title="مركز ذكاء التصنيف">
        <div className="grid gap-4 xl:grid-cols-[1.2fr_.8fr]">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full bg-rawasi-green/10 px-3 py-2 text-sm font-black text-rawasi-green">
              <BrainCircuit size={18} /> RAWASI Classification Intelligence
            </div>
            <h3 className="mt-4 text-3xl font-black text-rawasi-navy">{intelligence.base.grade} · {intelligence.base.score}/100</h3>
            <p className="mt-3 leading-8 text-slate-700">{intelligence.executiveNarrative}</p>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className={`rounded-2xl border p-4 ${statusColor(intelligence.confidence)}`}>
              <span className="text-sm">ثقة القرار</span>
              <b className="mt-2 block text-3xl">{intelligence.confidence}%</b>
            </div>
            <div className={`rounded-2xl border p-4 ${statusColor(100 - intelligence.gapToTarget)}`}>
              <span className="text-sm">الفجوة للهدف</span>
              <b className="mt-2 block text-3xl">{Math.ceil(intelligence.gapToTarget)} نقطة</b>
            </div>
            <div className={`rounded-2xl border p-4 ${statusColor(intelligence.dataCompleteness)}`}>
              <span className="text-sm">اكتمال البيانات</span>
              <b className="mt-2 block text-3xl">{intelligence.dataCompleteness}%</b>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 text-slate-700">
              <span className="text-sm">الدرجة المستهدفة</span>
              <b className="mt-2 block text-3xl">{intelligence.targetGrade}</b>
            </div>
          </div>
        </div>
      </Card>

      <div className="grid gap-5 xl:grid-cols-3">
        <Card title="مكونات التصنيف">
          <div className="grid gap-3">
            {[
              ['القوة المالية', intelligence.financialScore],
              ['القوة الفنية', intelligence.technicalScore],
              ['اكتمال المستندات', intelligence.documentScore],
            ].map(([title, value]) => (
              <div key={String(title)}>
                <div className="mb-2 flex justify-between text-sm font-bold text-slate-700"><span>{title}</span><span>{value}%</span></div>
                <div className="h-2 overflow-hidden rounded-full bg-slate-100"><div className="h-full rounded-full bg-rawasi-green" style={{ width: `${value}%` }} /></div>
              </div>
            ))}
          </div>
        </Card>

        <Card title="أسرع طريق للتحسين">
          <div className="grid gap-3">
            {intelligence.nextBestActions.slice(0, 3).map((item, index) => (
              <div key={item.key} className="rounded-2xl border border-slate-200 bg-slate-50 p-3">
                <div className="flex items-center justify-between gap-3"><b>{index + 1}. {item.title}</b><span className={`rounded-full border px-2 py-1 text-xs font-black ${priorityClass(item.priority)}`}>{item.priority}</span></div>
                <p className="mt-2 text-sm leading-7 text-slate-600">{item.recommendation}</p>
                <p className="mt-2 text-sm font-black text-rawasi-green">أثر متوقع: +{item.impact.toFixed(1)} نقطة</p>
              </div>
            ))}
          </div>
        </Card>

        <Card title="خريطة الدرجة المستهدفة">
          <div className="grid gap-4">
            <div className="flex items-center justify-between rounded-2xl bg-slate-50 p-4"><span className="flex items-center gap-2"><Gauge size={18} /> الدرجة الحالية</span><b>{intelligence.base.grade}</b></div>
            <div className="flex items-center justify-between rounded-2xl bg-slate-50 p-4"><span className="flex items-center gap-2"><Target size={18} /> الدرجة المستهدفة</span><b>{intelligence.targetGrade}</b></div>
            <div className="flex items-center justify-between rounded-2xl bg-slate-50 p-4"><span className="flex items-center gap-2"><Route size={18} /> النقاط المطلوبة</span><b>{Math.ceil(intelligence.gapToTarget)}</b></div>
          </div>
        </Card>
      </div>

      <Card title="تحليل الفجوات التفصيلي">
        <div className="overflow-auto">
          <table className="w-full min-w-[760px] border-separate border-spacing-y-2 text-sm">
            <thead><tr className="text-slate-500"><th className="p-2 text-right">البند</th><th>الحالي</th><th>المستهدف</th><th>الفجوة</th><th>الأثر</th><th>الأولوية</th><th className="text-right">التوصية</th></tr></thead>
            <tbody>
              {intelligence.gapItems.map((item) => (
                <tr key={item.key} className="rounded-2xl bg-white shadow-sm">
                  <td className="rounded-r-2xl border-y border-r border-slate-100 p-3 font-bold text-rawasi-navy">{item.title}</td>
                  <td className="border-y border-slate-100 p-3 text-center">{item.current.toFixed(1)}</td>
                  <td className="border-y border-slate-100 p-3 text-center">{item.target.toFixed(1)}</td>
                  <td className="border-y border-slate-100 p-3 text-center">{item.gap.toFixed(1)}</td>
                  <td className="border-y border-slate-100 p-3 text-center font-black text-rawasi-green">+{item.impact.toFixed(1)}</td>
                  <td className="border-y border-slate-100 p-3 text-center"><span className={`rounded-full border px-2 py-1 text-xs font-black ${priorityClass(item.priority)}`}>{item.priority}</span></td>
                  <td className="rounded-l-2xl border-y border-l border-slate-100 p-3 text-slate-600">{item.recommendation}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <Card title="محاكي ماذا لو؟">
        <div className="grid gap-5 xl:grid-cols-[1fr_360px]">
          <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            <label className="grid gap-2 text-sm font-bold text-slate-700">زيادة حقوق الملكية %<input className="rounded-xl border border-slate-200 p-3" type="number" value={scenario.equityIncreasePercent} onChange={(event) => patchScenario('equityIncreasePercent', event.target.value)} /></label>
            <label className="grid gap-2 text-sm font-bold text-slate-700">خفض الالتزامات %<input className="rounded-xl border border-slate-200 p-3" type="number" value={scenario.liabilityReductionPercent} onChange={(event) => patchScenario('liabilityReductionPercent', event.target.value)} /></label>
            <label className="grid gap-2 text-sm font-bold text-slate-700">مهندسون إضافيون<input className="rounded-xl border border-slate-200 p-3" type="number" value={scenario.extraEngineers} onChange={(event) => patchScenario('extraEngineers', event.target.value)} /></label>
            <label className="grid gap-2 text-sm font-bold text-slate-700">فنيون إضافيون<input className="rounded-xl border border-slate-200 p-3" type="number" value={scenario.extraTechnicians} onChange={(event) => patchScenario('extraTechnicians', event.target.value)} /></label>
            <label className="grid gap-2 text-sm font-bold text-slate-700">سعوديون إضافيون<input className="rounded-xl border border-slate-200 p-3" type="number" value={scenario.extraSaudiEmployees} onChange={(event) => patchScenario('extraSaudiEmployees', event.target.value)} /></label>
            <label className="grid gap-2 text-sm font-bold text-slate-700">المستندات المكتملة<input className="rounded-xl border border-slate-200 p-3" type="number" min={completedDocuments} max={company.documents.length} value={scenario.completedDocuments} onChange={(event) => patchScenario('completedDocuments', event.target.value)} /></label>
          </div>
          <div className="rounded-3xl bg-gradient-to-l from-rawasi-navy to-rawasi-blue p-5 text-white">
            <div className="flex items-center gap-2 text-white/75"><Sparkles size={18} /> نتيجة السيناريو</div>
            <b className="mt-4 block text-5xl">{scenarioResult.score}</b>
            <p className="mt-2 text-xl font-black">{scenarioResult.grade}</p>
            <p className="mt-4 rounded-2xl bg-white/10 p-3 leading-8">{scenarioResult.summary}</p>
            <p className="mt-3 flex items-center gap-2 text-sm text-white/80"><TrendingUp size={16} /> الفرق عن الوضع الحالي: {scenarioResult.delta > 0 ? '+' : ''}{scenarioResult.delta} نقطة</p>
          </div>
        </div>
      </Card>
    </section>
  );
}
