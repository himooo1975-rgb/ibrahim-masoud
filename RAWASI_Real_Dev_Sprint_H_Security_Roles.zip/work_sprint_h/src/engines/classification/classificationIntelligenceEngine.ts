import type { ClassificationGrade, Company, EngineResult } from '../../lib/types';
import { calculateFinancialRatios } from '../financial/financialEngine';

export interface GapItem {
  key: string;
  title: string;
  current: number;
  target: number;
  gap: number;
  impact: number;
  priority: 'عاجلة' | 'مرتفعة' | 'متوسطة' | 'منخفضة';
  recommendation: string;
}

export interface ScenarioInput {
  equityIncreasePercent: number;
  liabilityReductionPercent: number;
  extraEngineers: number;
  extraTechnicians: number;
  extraSaudiEmployees: number;
  completedDocuments: number;
}

export interface ScenarioResult {
  score: number;
  grade: ClassificationGrade;
  delta: number;
  confidence: number;
  summary: string;
}

export interface ClassificationIntelligenceResult {
  base: EngineResult;
  targetGrade: ClassificationGrade;
  targetScore: number;
  gapToTarget: number;
  confidence: number;
  dataCompleteness: number;
  financialScore: number;
  technicalScore: number;
  documentScore: number;
  gapItems: GapItem[];
  nextBestActions: GapItem[];
  executiveNarrative: string;
  simulate: (input: ScenarioInput) => ScenarioResult;
}

const gradeTargets: Record<ClassificationGrade, number> = {
  الأولى: 85,
  الثانية: 70,
  الثالثة: 55,
  الرابعة: 40,
  الخامسة: 25,
  'غير مصنف': 0,
};

function gradeFromScore(score: number): ClassificationGrade {
  if (score >= 85) return 'الأولى';
  if (score >= 70) return 'الثانية';
  if (score >= 55) return 'الثالثة';
  if (score >= 40) return 'الرابعة';
  if (score >= 25) return 'الخامسة';
  return 'غير مصنف';
}

function clamp(value: number, min = 0, max = 100) {
  return Math.min(max, Math.max(min, value));
}

function technicalScore(company: Company) {
  const employees = Math.max(1, company.technical.employees);
  const engineerRatio = company.technical.engineers / employees;
  const technicianRatio = company.technical.technicians / employees;
  const saudiRatio = company.technical.saudiEmployees / employees;
  return Math.round(
    Math.min(100, engineerRatio * 200) * 0.35 +
      Math.min(100, technicianRatio * 160) * 0.25 +
      Math.min(100, saudiRatio * 140) * 0.2 +
      Math.min(100, company.technical.avgEngineerExperience * 8) * 0.1 +
      Math.min(100, company.technical.avgTechnicianExperience * 7) * 0.1,
  );
}

function documentScore(company: Company) {
  return Math.round((company.documents.filter((doc) => doc.status === 'مكتمل').length / Math.max(1, company.documents.length)) * 100);
}

function priorityFromImpact(impact: number): GapItem['priority'] {
  if (impact >= 8) return 'عاجلة';
  if (impact >= 5) return 'مرتفعة';
  if (impact >= 2.5) return 'متوسطة';
  return 'منخفضة';
}

function createGapItems(company: Company, financialScore: number, techScore: number, docsScore: number): GapItem[] {
  const employees = Math.max(1, company.technical.employees);
  const engineerRatio = (company.technical.engineers / employees) * 100;
  const technicianRatio = (company.technical.technicians / employees) * 100;
  const saudiRatio = (company.technical.saudiEmployees / employees) * 100;
  const ratios = calculateFinancialRatios(company.financial);
  const completedDocs = company.documents.filter((doc) => doc.status === 'مكتمل').length;

  const items: GapItem[] = [
    {
      key: 'financial_strength',
      title: 'القوة المالية والتقييم الائتماني',
      current: financialScore,
      target: 78,
      gap: Math.max(0, 78 - financialScore),
      impact: clamp((78 - financialScore) * 0.32, 0, 12),
      priority: priorityFromImpact(clamp((78 - financialScore) * 0.32, 0, 12)),
      recommendation: 'تحسين حقوق الملكية وخفض الالتزامات قصيرة الأجل ورفع التدفقات النقدية التشغيلية.',
    },
    {
      key: 'liquidity',
      title: 'السيولة',
      current: ratios.currentStrength,
      target: 75,
      gap: Math.max(0, 75 - ratios.currentStrength),
      impact: clamp((75 - ratios.currentStrength) * 0.08, 0, 7),
      priority: priorityFromImpact(clamp((75 - ratios.currentStrength) * 0.08, 0, 7)),
      recommendation: 'رفع الأصول المتداولة أو تخفيض الالتزامات المتداولة لتحسين نسبة التداول.',
    },
    {
      key: 'profitability',
      title: 'الربحية',
      current: ratios.profitability,
      target: 70,
      gap: Math.max(0, 70 - ratios.profitability),
      impact: clamp((70 - ratios.profitability) * 0.07, 0, 6),
      priority: priorityFromImpact(clamp((70 - ratios.profitability) * 0.07, 0, 6)),
      recommendation: 'تحسين هامش الربح عبر ضبط تكاليف المشاريع ورفع كفاءة التسعير.',
    },
    {
      key: 'engineers',
      title: 'نسبة المهندسين',
      current: engineerRatio,
      target: 12,
      gap: Math.max(0, 12 - engineerRatio),
      impact: clamp((12 - engineerRatio) * 0.65, 0, 8),
      priority: priorityFromImpact(clamp((12 - engineerRatio) * 0.65, 0, 8)),
      recommendation: 'زيادة عدد المهندسين أو تحديث بيانات الكوادر الهندسية المؤهلة.',
    },
    {
      key: 'technicians',
      title: 'نسبة الفنيين',
      current: technicianRatio,
      target: 22,
      gap: Math.max(0, 22 - technicianRatio),
      impact: clamp((22 - technicianRatio) * 0.35, 0, 7),
      priority: priorityFromImpact(clamp((22 - technicianRatio) * 0.35, 0, 7)),
      recommendation: 'رفع نسبة الفنيين المسجلين على المنشأة وتوثيق خبراتهم.',
    },
    {
      key: 'saudization',
      title: 'نسبة السعودة',
      current: saudiRatio,
      target: 30,
      gap: Math.max(0, 30 - saudiRatio),
      impact: clamp((30 - saudiRatio) * 0.18, 0, 5),
      priority: priorityFromImpact(clamp((30 - saudiRatio) * 0.18, 0, 5)),
      recommendation: 'تحسين نسبة السعودة والكوادر السعودية ذات الأجور المرتفعة عند الإمكان.',
    },
    {
      key: 'documents',
      title: 'اكتمال المستندات',
      current: completedDocs,
      target: company.documents.length,
      gap: Math.max(0, company.documents.length - completedDocs),
      impact: clamp((company.documents.length - completedDocs) * 2.2, 0, 10),
      priority: priorityFromImpact(clamp((company.documents.length - completedDocs) * 2.2, 0, 10)),
      recommendation: 'استكمال المستندات الناقصة أو تحديث المستندات التي تحتاج مراجعة قبل التقديم.',
    },
  ];

  return items.filter((item) => item.gap > 0.01 || item.impact > 0.01).sort((a, b) => b.impact - a.impact);
}

function applyScenario(company: Company, input: ScenarioInput): Company {
  const completed = Math.max(0, Math.min(company.documents.length, input.completedDocuments));
  return {
    ...company,
    financial: {
      ...company.financial,
      equity: Math.round(company.financial.equity * (1 + input.equityIncreasePercent / 100)),
      liabilities: Math.round(company.financial.liabilities * (1 - input.liabilityReductionPercent / 100)),
    },
    technical: {
      ...company.technical,
      engineers: company.technical.engineers + input.extraEngineers,
      technicians: company.technical.technicians + input.extraTechnicians,
      saudiEmployees: company.technical.saudiEmployees + input.extraSaudiEmployees,
      employees: company.technical.employees + input.extraEngineers + input.extraTechnicians + input.extraSaudiEmployees,
    },
    documents: company.documents.map((doc, index) => (index < completed ? { ...doc, status: 'مكتمل' } : doc)),
  };
}

export function buildClassificationIntelligence(company: Company, base: EngineResult): ClassificationIntelligenceResult {
  const financial = calculateFinancialRatios(company.financial);
  const financialScore = financial.score;
  const techScore = technicalScore(company);
  const docsScore = documentScore(company);
  const dataCompleteness = Math.round(
    (Number(company.name.trim().length > 0) * 12 +
      Number(company.commercialRegistration.trim().length > 0) * 12 +
      Number(company.financial.assets > 0) * 16 +
      Number(company.financial.revenue > 0) * 12 +
      Number(company.technical.employees > 0) * 14 +
      Number(company.technical.engineers > 0) * 12 +
      Number(company.documents.some((doc) => doc.status === 'مكتمل')) * 12 +
      Number(company.projects.some((project) => project.name.trim().length > 0)) * 10),
  );
  const targetScore = gradeTargets[company.targetGrade] ?? 70;
  const gapToTarget = Math.max(0, targetScore - base.score);
  const gapItems = createGapItems(company, financialScore, techScore, docsScore);
  const nextBestActions = gapItems.slice(0, 5);
  const confidence = Math.round((base.confidence * 0.55 + dataCompleteness * 0.45) * 10) / 10;
  const executiveNarrative = gapToTarget <= 0
    ? `الشركة تحقق متطلبات الدرجة المستهدفة ${company.targetGrade} وفق البيانات الحالية، مع ضرورة مراجعة المستندات قبل التقديم.`
    : `الشركة تحتاج إلى ${Math.ceil(gapToTarget)} نقطة تقريبًا للوصول إلى الدرجة المستهدفة ${company.targetGrade}. أكثر البنود تأثيرًا: ${nextBestActions.slice(0, 3).map((item) => item.title).join('، ')}.`;

  return {
    base,
    targetGrade: company.targetGrade,
    targetScore,
    gapToTarget,
    confidence,
    dataCompleteness,
    financialScore,
    technicalScore: techScore,
    documentScore: docsScore,
    gapItems,
    nextBestActions,
    executiveNarrative,
    simulate(input: ScenarioInput): ScenarioResult {
      const simulatedCompany = applyScenario(company, input);
      const simulatedFinancial = calculateFinancialRatios(simulatedCompany.financial).score;
      const simulatedTech = technicalScore(simulatedCompany);
      const simulatedDocs = documentScore(simulatedCompany);
      const simulatedScore = Math.round(simulatedFinancial * 0.45 + simulatedTech * 0.35 + simulatedDocs * 0.2);
      const delta = simulatedScore - base.score;
      const grade = gradeFromScore(simulatedScore);
      return {
        score: simulatedScore,
        grade,
        delta,
        confidence: clamp(confidence + Math.min(8, Math.max(0, input.completedDocuments - company.documents.filter((doc) => doc.status === 'مكتمل').length) * 1.5)),
        summary: delta > 0 ? `السيناريو يرفع النتيجة ${delta} نقطة ويصل إلى ${grade}.` : `السيناريو لا يرفع النتيجة الحالية؛ راجع الأرقام المدخلة.`,
      };
    },
  };
}
