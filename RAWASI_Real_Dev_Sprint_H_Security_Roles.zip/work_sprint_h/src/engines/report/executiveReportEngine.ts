import type { Company, EngineResult } from '../../lib/types';
import { buildClassificationIntelligence } from '../classification/classificationIntelligenceEngine';
import { analyzeFinancialStatement } from '../financial/financialEngine';

export interface ExecutiveKpi {
  key: string;
  title: string;
  value: string;
  status: 'قوي' | 'متوسط' | 'حرج';
  note: string;
}

export interface ExecutiveReportSection {
  title: string;
  items: string[];
}

export interface ExecutiveReport {
  generatedAt: string;
  companyName: string;
  summary: string;
  kpis: ExecutiveKpi[];
  sections: ExecutiveReportSection[];
  actionPlan: string[];
  boardRecommendation: string;
  readiness: number;
}

function statusFromPercent(value: number): ExecutiveKpi['status'] {
  if (value >= 75) return 'قوي';
  if (value >= 50) return 'متوسط';
  return 'حرج';
}

function currency(value: number) {
  return `${Math.round(value).toLocaleString('ar-SA')} ريال`;
}

function escapeHtml(value: string) {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

export function buildExecutiveReport(company: Company, result: EngineResult): ExecutiveReport {
  const intelligence = buildClassificationIntelligence(company, result);
  const financial = analyzeFinancialStatement(company.financial);
  const completedDocs = company.documents.filter((doc) => doc.status === 'مكتمل').length;
  const docsReadiness = Math.round((completedDocs / Math.max(1, company.documents.length)) * 100);
  const readiness = Math.round(
    intelligence.financialScore * 0.35 + intelligence.technicalScore * 0.25 + docsReadiness * 0.2 + intelligence.dataCompleteness * 0.2,
  );
  const topGaps = intelligence.gapItems.slice(0, 5);
  const actionPlan = topGaps.map((gap, index) => `${index + 1}. ${gap.recommendation} (أثر متوقع +${gap.impact.toFixed(1)} نقطة).`);
  const summary = intelligence.gapToTarget <= 0
    ? `تظهر نتائج التحليل أن ${company.name || 'الشركة'} تحقق الدرجة المستهدفة ${company.targetGrade} وفق البيانات الحالية، مع ضرورة إكمال المراجعة النهائية للمستندات قبل التقديم.`
    : `تحتاج ${company.name || 'الشركة'} إلى نحو ${Math.ceil(intelligence.gapToTarget)} نقطة للوصول إلى الدرجة المستهدفة ${company.targetGrade}. تتركز الفجوات الأعلى أثرًا في ${topGaps.slice(0, 3).map((item) => item.title).join('، ')}.`;

  return {
    generatedAt: new Date().toISOString(),
    companyName: company.name || 'شركة غير مسماة',
    summary,
    readiness,
    kpis: [
      {
        key: 'classification',
        title: 'التصنيف الحالي',
        value: result.grade,
        status: statusFromPercent(result.score),
        note: `${result.score}/100 ونسبة ثقة ${intelligence.confidence}%.`,
      },
      {
        key: 'target',
        title: 'الدرجة المستهدفة',
        value: company.targetGrade,
        status: intelligence.gapToTarget <= 0 ? 'قوي' : 'متوسط',
        note: intelligence.gapToTarget <= 0 ? 'الهدف محقق وفق البيانات الحالية.' : `الفجوة: ${Math.ceil(intelligence.gapToTarget)} نقطة.`,
      },
      {
        key: 'financial',
        title: 'التقييم الائتماني',
        value: `${financial.creditGrade} · ${financial.creditScore}/100`,
        status: statusFromPercent(financial.creditScore),
        note: `مستوى المخاطر المالية: ${financial.riskLevel}.`,
      },
      {
        key: 'readiness',
        title: 'جاهزية التقديم',
        value: `${readiness}%`,
        status: statusFromPercent(readiness),
        note: `${completedDocs}/${company.documents.length} مستند مكتمل وبيانات مكتملة بنسبة ${intelligence.dataCompleteness}%.`,
      },
      {
        key: 'projects',
        title: 'قيمة المشاريع المسجلة',
        value: currency(company.projects.reduce((sum, project) => sum + project.value, 0)),
        status: company.projects.some((project) => project.name.trim().length > 0) ? 'قوي' : 'متوسط',
        note: `${company.projects.length} مشروع/مشاريع داخل ملف الشركة.`,
      },
    ],
    sections: [
      {
        title: 'ملخص نقاط القوة',
        items: [
          ...financial.strengths.slice(0, 3),
          ...(docsReadiness >= 70 ? [`اكتمال المستندات عند ${docsReadiness}% وهو مستوى مناسب كبداية.`] : []),
          ...(intelligence.technicalScore >= 70 ? [`الجاهزية الفنية ${intelligence.technicalScore}% وتدعم قرار التصنيف.`] : []),
        ].slice(0, 5),
      },
      {
        title: 'أبرز الفجوات',
        items: topGaps.map((gap) => `${gap.title}: الفجوة ${gap.gap.toFixed(1)}، والأثر المتوقع +${gap.impact.toFixed(1)} نقطة.`),
      },
      {
        title: 'المخاطر والملاحظات',
        items: [
          ...financial.validation.map((issue) => issue.message),
          ...(financial.weaknesses.length ? financial.weaknesses.slice(0, 3) : []),
          ...(docsReadiness < 100 ? [`يوجد ${company.documents.length - completedDocs} مستند ناقص أو يحتاج تحديث.`] : []),
        ].slice(0, 6),
      },
    ],
    actionPlan,
    boardRecommendation: intelligence.gapToTarget <= 0
      ? 'التوصية للإدارة: اعتماد الملف للمراجعة النهائية وتجهيز نسخة التقديم الرسمية مع تدقيق المستندات قبل الإرسال.'
      : 'التوصية للإدارة: اعتماد خطة تحسين قصيرة المدى تركز على أعلى فجوات أثرًا قبل التقديم الرسمي، ثم إعادة تشغيل محرك التصنيف بعد تحديث البيانات.',
  };
}

export function exportExecutiveReportAsHtml(report: ExecutiveReport) {
  const kpis = report.kpis.map((kpi) => `<div class="kpi"><span>${escapeHtml(kpi.title)}</span><strong>${escapeHtml(kpi.value)}</strong><p>${escapeHtml(kpi.note)}</p></div>`).join('');
  const sections = report.sections.map((section) => `
    <section><h2>${escapeHtml(section.title)}</h2><ul>${section.items.map((item) => `<li>${escapeHtml(item)}</li>`).join('')}</ul></section>
  `).join('');
  const actions = report.actionPlan.map((item) => `<li>${escapeHtml(item)}</li>`).join('');
  return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>تقرير ${escapeHtml(report.companyName)}</title><style>
    body{font-family:Tahoma,Arial,sans-serif;margin:0;background:#f4f7f7;color:#12232e;line-height:1.8}.page{max-width:980px;margin:auto;padding:36px}.hero{background:linear-gradient(120deg,#0d2d38,#0b7a70);color:#fff;border-radius:24px;padding:28px}.kpis{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin:20px 0}.kpi,section{background:#fff;border:1px solid #d9e5e5;border-radius:18px;padding:18px;margin-top:14px}.kpi span{color:#647780}.kpi strong{display:block;font-size:26px;margin-top:6px}h1,h2{margin:0 0 10px}@media print{body{background:#fff}.page{padding:0}.kpi,section{break-inside:avoid}}
  </style></head><body><div class="page"><div class="hero"><h1>منصة الرواسي · تقرير تنفيذي</h1><h2>${escapeHtml(report.companyName)}</h2><p>${escapeHtml(report.summary)}</p><p>تاريخ الإصدار: ${new Date(report.generatedAt).toLocaleString('ar-SA')}</p></div><div class="kpis">${kpis}</div>${sections}<section><h2>خطة العمل المقترحة</h2><ol>${actions}</ol></section><section><h2>توصية الإدارة</h2><p>${escapeHtml(report.boardRecommendation)}</p></section></div></body></html>`;
}

export function exportExecutiveReportAsCsv(report: ExecutiveReport) {
  const rows = [
    ['المؤشر', 'القيمة', 'الحالة', 'الملاحظة'],
    ...report.kpis.map((kpi) => [kpi.title, kpi.value, kpi.status, kpi.note]),
  ];
  return rows.map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(',')).join('\n');
}
