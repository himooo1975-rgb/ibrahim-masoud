import type { PermissionKey, RawasiUser, UserRole } from '../../lib/types';

export const roleLabels: Record<UserRole, string> = {
  admin: 'مدير النظام',
  classification_consultant: 'مستشار التصنيف',
  financial_reviewer: 'المراجع المالي',
  technical_reviewer: 'المراجع الفني',
  readonly: 'قارئ فقط',
};

export const rolePermissions: Record<UserRole, PermissionKey[]> = {
  admin: [
    'Company.Read',
    'Company.Edit',
    'Company.Delete',
    'Financial.Edit',
    'Financial.Approve',
    'Technical.Edit',
    'Documents.Edit',
    'Classification.Run',
    'Reports.Export',
    'Users.Manage',
    'Audit.Read',
  ],
  classification_consultant: [
    'Company.Read',
    'Company.Edit',
    'Financial.Edit',
    'Technical.Edit',
    'Documents.Edit',
    'Classification.Run',
    'Reports.Export',
    'Audit.Read',
  ],
  financial_reviewer: ['Company.Read', 'Financial.Edit', 'Financial.Approve', 'Classification.Run', 'Reports.Export'],
  technical_reviewer: ['Company.Read', 'Technical.Edit', 'Documents.Edit', 'Classification.Run', 'Reports.Export'],
  readonly: ['Company.Read', 'Reports.Export'],
};

export function getPermissionsForRole(role: UserRole): PermissionKey[] {
  return rolePermissions[role] ?? rolePermissions.readonly;
}

export function hasPermission(user: RawasiUser | null, permission: PermissionKey): boolean {
  if (!user || user.status !== 'active') return false;
  return getPermissionsForRole(user.role).includes(permission);
}

export function getPermissionMatrix(users: RawasiUser[]) {
  const permissions: PermissionKey[] = [
    'Company.Read',
    'Company.Edit',
    'Company.Delete',
    'Financial.Edit',
    'Financial.Approve',
    'Technical.Edit',
    'Documents.Edit',
    'Classification.Run',
    'Reports.Export',
    'Users.Manage',
    'Audit.Read',
  ];

  return users.map((user) => ({
    user,
    roleLabel: roleLabels[user.role],
    permissions: permissions.map((permission) => ({
      permission,
      allowed: hasPermission(user, permission),
    })),
  }));
}

export function createSecurityAdvisory(user: RawasiUser | null, users: RawasiUser[]) {
  const inactiveUsers = users.filter((item) => item.status !== 'active').length;
  const admins = users.filter((item) => item.role === 'admin' && item.status === 'active').length;
  const missingAdmin = admins === 0;

  return {
    level: missingAdmin ? 'high' : inactiveUsers > 0 ? 'medium' : 'low',
    title: missingAdmin ? 'لا يوجد مدير نظام نشط' : inactiveUsers > 0 ? 'يوجد مستخدمون غير نشطين' : 'إعدادات الأمان مستقرة',
    description: missingAdmin
      ? 'يجب وجود مدير نظام نشط واحد على الأقل لإدارة الصلاحيات.'
      : inactiveUsers > 0
        ? 'راجع المستخدمين غير النشطين وحدد هل يجب حذفهم أو إعادة تفعيلهم.'
        : `الجلسة الحالية تعمل باسم ${user?.name ?? 'غير محدد'} وبصلاحيات واضحة.`,
  };
}
