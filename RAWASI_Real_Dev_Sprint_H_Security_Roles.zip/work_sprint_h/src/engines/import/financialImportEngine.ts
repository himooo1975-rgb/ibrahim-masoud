import type { FinancialStatement } from '../../lib/types';

export interface ExtractedFinancialField {
  key: keyof FinancialStatement;
  title: string;
  value: number;
  confidence: number;
  matchedLine: string;
}

export interface FinancialImportResult {
  statement: FinancialStatement;
  fields: ExtractedFinancialField[];
  missingFields: Array<keyof FinancialStatement>;
  warnings: string[];
  confidence: number;
  sourcePreview: string[];
}

const FIELD_LABELS: Record<keyof FinancialStatement, string> = {
  year: 'السنة المالية',
  assets: 'إجمالي الأصول',
  liabilities: 'إجمالي الخصوم',
  equity: 'حقوق الملكية',
  revenue: 'الإيرادات',
  netProfit: 'صافي الربح',
  operatingCashFlow: 'التدفقات النقدية التشغيلية',
};

const FIELD_PATTERNS: Array<{ key: keyof FinancialStatement; patterns: RegExp[]; confidence: number }> = [
  { key: 'assets', confidence: 94, patterns: [/إجمالي\s*الأصول/i, /مجموع\s*الأصول/i, /total\s*assets/i, /assets/i] },
  { key: 'liabilities', confidence: 92, patterns: [/إجمالي\s*الخصوم/i, /مجموع\s*الالتزامات/i, /إجمالي\s*الالتزامات/i, /total\s*liabilities/i, /liabilities/i] },
  { key: 'equity', confidence: 92, patterns: [/حقوق\s*الملكية/i, /إجمالي\s*حقوق\s*الملكية/i, /صافي\s*حقوق\s*الملكية/i, /equity/i] },
  { key: 'revenue', confidence: 90, patterns: [/الإيرادات/i, /ايرادات/i, /المبيعات/i, /إجمالي\s*الدخل/i, /revenue/i, /sales/i] },
  { key: 'netProfit', confidence: 90, patterns: [/صافي\s*الربح/i, /صافي\s*الدخل/i, /ربح\s*السنة/i, /net\s*profit/i, /net\s*income/i] },
  { key: 'operatingCashFlow', confidence: 84, patterns: [/التدفقات\s*النقدية\s*التشغيلية/i, /صافي\s*النقد\s*من\s*الأنشطة\s*التشغيلية/i, /operating\s*cash\s*flow/i, /cash\s*flow\s*from\s*operat/i] },
];

function normalizeArabicDigits(value: string) {
  const arabic = '٠١٢٣٤٥٦٧٨٩';
  const persian = '۰۱۲۳۴۵۶۷۸۹';
  return value.replace(/[٠-٩]/g, (digit) => String(arabic.indexOf(digit))).replace(/[۰-۹]/g, (digit) => String(persian.indexOf(digit)));
}

function parseNumber(value: string): number | null {
  const normalized = normalizeArabicDigits(value)
    .replace(/[٬,\s]/g, '')
    .replace(/\(([-+]?\d+(?:\.\d+)?)\)/, '-$1');
  const match = normalized.match(/[-+]?\d+(?:\.\d+)?/);
  if (!match) return null;
  const parsed = Number(match[0]);
  return Number.isFinite(parsed) ? parsed : null;
}

function extractBestNumber(line: string): number | null {
  const normalized = normalizeArabicDigits(line).replace(/SAR|ر\.س|ريال|﷼/gi, '');
  const matches = normalized.match(/\(?[-+]?\d[\d,٬\s]*(?:\.\d+)?\)?/g) ?? [];
  if (!matches.length) return null;
  const numeric = matches.map(parseNumber).filter((item): item is number => item !== null);
  if (!numeric.length) return null;
  return numeric.reduce((largest, current) => Math.abs(current) > Math.abs(largest) ? current : largest, numeric[0]);
}

function extractYear(text: string, fallbackYear: number) {
  const normalized = normalizeArabicDigits(text);
  const years = normalized.match(/20\d{2}/g)?.map(Number).filter((year) => year >= 2000 && year <= 2100) ?? [];
  return years.length ? Math.max(...years) : fallbackYear;
}

export function importFinancialStatementFromText(text: string, current: FinancialStatement): FinancialImportResult {
  const lines = text
    .split(/\r?\n|\|/)
    .map((line) => line.trim())
    .filter(Boolean)
    .slice(0, 500);

  const statement: FinancialStatement = { ...current, year: extractYear(text, current.year) };
  const fields: ExtractedFinancialField[] = [];
  const usedKeys = new Set<keyof FinancialStatement>();

  for (const line of lines) {
    for (const rule of FIELD_PATTERNS) {
      if (usedKeys.has(rule.key)) continue;
      if (!rule.patterns.some((pattern) => pattern.test(line))) continue;
      const value = extractBestNumber(line);
      if (value === null) continue;
      statement[rule.key] = value as never;
      usedKeys.add(rule.key);
      fields.push({ key: rule.key, title: FIELD_LABELS[rule.key], value, confidence: rule.confidence, matchedLine: line });
    }
  }

  const missingFields = (Object.keys(FIELD_LABELS) as Array<keyof FinancialStatement>)
    .filter((key) => key !== 'year')
    .filter((key) => !usedKeys.has(key) && !statement[key]);

  const warnings: string[] = [];
  const balanceGap = Math.abs(statement.assets - (statement.liabilities + statement.equity));
  if (statement.assets > 0 && balanceGap / statement.assets > 0.03) {
    warnings.push('الأصول لا تساوي الخصوم + حقوق الملكية بهامش مقبول. راجع ربط البنود قبل الاعتماد.');
  }
  if (missingFields.length) warnings.push(`بنود لم يتم التعرف عليها تلقائيًا: ${missingFields.map((key) => FIELD_LABELS[key]).join('، ')}.`);
  if (!fields.length) warnings.push('لم يتم التعرف على أرقام مالية. جرّب لصق نص قابل للنسخ أو CSV بدل PDF صورة.');

  const confidence = Math.round((fields.reduce((sum, field) => sum + field.confidence, 0) / Math.max(1, Object.keys(FIELD_LABELS).length - 1)) * 10) / 10;

  return {
    statement,
    fields,
    missingFields,
    warnings,
    confidence: Math.min(100, confidence),
    sourcePreview: lines.slice(0, 8),
  };
}

export function buildFinancialImportTemplate(statement: FinancialStatement) {
  return [
    `السنة المالية: ${statement.year}`,
    `إجمالي الأصول: ${statement.assets}`,
    `إجمالي الخصوم: ${statement.liabilities}`,
    `حقوق الملكية: ${statement.equity}`,
    `الإيرادات: ${statement.revenue}`,
    `صافي الربح: ${statement.netProfit}`,
    `التدفقات النقدية التشغيلية: ${statement.operatingCashFlow}`,
  ].join('\n');
}
