import type { Company, RawasiDataStoreSnapshot } from '@rawasi/core';
import { RawasiRepository } from '@rawasi/core';

const LEGACY_COMPANY_KEY = 'rawasi.enterprise.company.v1';
const SNAPSHOT_KEY = 'rawasi.enterprise.snapshot.v1';

function readSnapshot(): RawasiDataStoreSnapshot | null {
  try {
    const raw = localStorage.getItem(SNAPSHOT_KEY);
    return raw ? (JSON.parse(raw) as RawasiDataStoreSnapshot) : null;
  } catch {
    return null;
  }
}

function writeSnapshot(snapshot: RawasiDataStoreSnapshot) {
  localStorage.setItem(SNAPSHOT_KEY, JSON.stringify(snapshot));
}

export function loadCompany(fallback: Company): Company {
  const snapshot = readSnapshot();
  if (snapshot?.companies?.length) {
    const repo = RawasiRepository.fromSnapshot(snapshot);
    const company = repo.getCompany(snapshot.companies[0].id, fallback);
    if (company) return company;
  }

  try {
    const legacyRaw = localStorage.getItem(LEGACY_COMPANY_KEY);
    if (!legacyRaw) return fallback;
    const legacyCompany = { ...fallback, ...JSON.parse(legacyRaw) } as Company;
    saveCompany(legacyCompany);
    return legacyCompany;
  } catch {
    return fallback;
  }
}

export function saveCompany(company: Company) {
  const repo = RawasiRepository.fromSnapshot(readSnapshot() || undefined);
  repo.saveCompany(company, 'local-user');
  writeSnapshot(repo.exportSnapshot());
  // Keep a short-term compatibility copy for earlier builds.
  localStorage.setItem(LEGACY_COMPANY_KEY, JSON.stringify(company));
}

export function exportRawasiSnapshot() {
  return readSnapshot();
}

export function importRawasiSnapshot(snapshot: RawasiDataStoreSnapshot) {
  writeSnapshot(snapshot);
}

export function resetCompany() {
  localStorage.removeItem(LEGACY_COMPANY_KEY);
  localStorage.removeItem(SNAPSHOT_KEY);
}
