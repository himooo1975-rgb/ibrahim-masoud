import { useEffect, useMemo, useState } from 'react';
import type { Company, ClassificationGrade, FinancialInput, TechnicalInput, TimelineEvent } from '@rawasi/core';
import { applyExtractedFinancials, buildBetaReadiness, buildDecision, buildExecutiveReport, buildFinancialMapping, buildWorkspace, exportReportAsText, extractFinancialsFromText, getTechnicalRulesCatalog, gradeLabel, simulateCompany, validateFinancialInput } from '@rawasi/core';
import { demoCompany } from './data/demoCompany';
import { loadCompany, resetCompany, saveCompany } from './services/storage';
import { FactorList } from './components/FactorList';
import { KpiCard } from './components/KpiCard';

const financialLabels: Record<keyof FinancialInput, string> = {
  revenue: 'الإيرادات',
  netProfit: 'صافي الربح',
  assets: 'إجمالي الأصول',
  liabilities: 'إجمالي الالتزامات',
  equity: 'حقوق الملكية',
  cash: 'النقد وما في حكمه',
  currentAssets: 'الأصول المتداولة',
  currentLiabilities: 'الالتزامات المتداولة',
  operatingCashFlow: 'التدفق النقدي التشغيلي'
};

const technicalLabels: Record<keyof TechnicalInput, string> = {
  companySize: 'حجم المنشأة',
  engineersPercent: 'نسبة المهندسين %',
  techniciansPercent: 'نسبة الفنيين %',
  engineersExperience: 'متوسط خبرات المهندسين',
  techniciansExperience: 'متوسط خبرات الفنيين',
  saudizationPercent: 'نسبة السعودة %',
  saudiEngineersPercent: 'نسبة المهندسين السعوديين %'
};

const statusLabel = { good: 'جاهز', warning: 'يحتاج تحسين', critical: 'حرج' } as const;

function timelineTypeLabel(type: TimelineEvent['type']) {
  const labels: Record<TimelineEvent['type'], string> = {
    company: 'شركة',
    financial: 'مالي',
    technical: 'فني',
    document: 'مستند',
    classification: 'تصنيف',
    system: 'نظام'
  };
  return labels[type];
}

export function App() {
  const [company, setCompany] = useState<Company>(() => loadCompany(demoCompany));
  const [simPatch, setSimPatch] = useState({ equityDelta: 0, liabilitiesDelta: 0, currentAssetsDelta: 0, engineersPercentDelta: 0 });
  const [financialText, setFinancialText] = useState('الإيرادات 15000000\nصافي الربح 1450000\nإجمالي الأصول 23000000\nإجمالي الالتزامات 9200000\nحقوق الملكية 13800000\nالنقد وما في حكمه 2500000\nالأصول المتداولة 7600000\nالالتزامات المتداولة 4100000\nالتدفق النقدي التشغيلي 1800000');
  const decision = useMemo(() => buildDecision(company), [company]);
  const betaReadiness = useMemo(() => buildBetaReadiness(company), [company]);
  const workspace = useMemo(() => buildWorkspace(company), [company]);
  const simulation = useMemo(() => simulateCompany(company, simPatch), [company, simPatch]);
  const executiveReport = useMemo(() => buildExecutiveReport(company, decision), [company, decision]);
  const technicalRulesCatalog = useMemo(() => getTechnicalRulesCatalog(), []);
  const extraction = useMemo(() => extractFinancialsFromText(financialText), [financialText]);
  const mapping = useMemo(() => buildFinancialMapping(extraction.fields), [extraction]);
  const validationIssues = useMemo(() => validateFinancialInput(company.financial), [company.financial]);

  useEffect(() => saveCompany(company), [company]);

  const updateCompany = <K extends keyof Company>(key: K, value: Company[K]) => {
    setCompany(prev => ({ ...prev, [key]: value }));
  };

  const updateFinancial = (key: keyof FinancialInput, value: number) => {
    setCompany(prev => ({ ...prev, financial: { ...prev.financial, [key]: Number.isFinite(value) ? value : 0 } }));
  };

  const updateTechnical = (key: keyof TechnicalInput, value: number | TechnicalInput['companySize']) => {
    setCompany(prev => ({ ...prev, technical: { ...prev.technical, [key]: value } }));
  };

  const downloadExecutiveReport = () => {
    const blob = new Blob([exportReportAsText(executiveReport)], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `rawasi-executive-report-${company.crNumber || company.id}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const toggleDocument = (id: string) => {
    setCompany(prev => ({
      ...prev,
      documents: prev.documents.map(doc => doc.id === id ? { ...doc, present: !doc.present } : doc),
      timeline: [
        ...(prev.timeline ?? []),
        {
          id: `doc-${Date.now()}`,
          at: new Date().toISOString(),
          title: 'تحديث حالة مستند',
          description: `تم تغيير حالة المستند: ${prev.documents.find(doc => doc.id === id)?.name ?? id}.`,
          type: 'document'
        }
      ]
    }));
  };

  const applyExtracted = () => {
    const result = applyExtractedFinancials(company, extraction.values);
    setCompany(result.company);
  };

  return (
    <main className="app-shell">
      <aside className="sidebar">
        <div className="brand-mark">ر</div>
        <h1>منصة الرواسي</h1>
        <p>مساحة عمل متخصصة لتجهيز ورفع تصنيف شركات المقاولات.</p>
        <nav>
          <a href="#operations">غرفة العمليات</a>
          <a href="#workspace">Workspace</a>
          <a href="#company">ملف الشركة</a>
          <a href="#finance">المركز المالي</a>
          <a href="#technical">المركز الفني</a>
          <a href="#financial-extraction">استخراج القوائم</a>
          <a href="#beta-readiness">جاهزية Beta</a>
          <a href="#classification-engine">محرك التصنيف</a>
          <a href="#rules">محرك القواعد</a>
          <a href="#documents">المستندات</a>
          <a href="#classification">التصنيف</a>
          <a href="#recommendations">خطة التوصيات</a>
          <a href="#executive-report">التقرير التنفيذي</a>
          <a href="#board-dashboard">لوحة الإدارة</a>
          <a href="#roadmap">خارطة التحسين</a>
          <a href="#timeline">السجل الزمني</a>
          <a href="#simulator">المحاكي</a>
        </nav>
      </aside>

      <section className="content">
        <header className="hero" id="operations">
          <div>
            <span className="eyebrow">RAWASI Enterprise • Commit 10</span>
            <h2>Beta Integration & Stabilization</h2>
            <p>{decision.executiveSummary}</p>
            <div className="hero-actions">
              <button onClick={() => { resetCompany(); setCompany(demoCompany); }}>إعادة بيانات العرض</button>
              <button onClick={downloadExecutiveReport}>تنزيل تقرير نصي</button>
              <button className="primary" onClick={() => window.print()}>طباعة التقرير التنفيذي</button>
            </div>
          </div>
          <div className="score-card">
            <span>الدرجة المتوقعة</span>
            <strong>{gradeLabel(decision.grade)}</strong>
            <small>اكتمال مساحة العمل: {workspace.completion}%</small>
            <small>الجاهزية للهدف: {decision.readiness}%</small>
            <small>نسبة الثقة: {decision.confidence}%</small>
          </div>
        </header>

        <section className="kpi-grid">
          <KpiCard title="النقاط الإجمالية" value={`${decision.totalScore}/100`} hint="ناتج Classification Pipeline" tone="blue" />
          <KpiCard title="نسبة الثقة" value={`${decision.confidence}%`} hint="اكتمال البيانات والأدلة" tone={decision.confidence >= 80 ? 'green' : 'gold'} />
          <KpiCard title="الدرجة المستهدفة" value={gradeLabel(decision.targetGrade)} hint={decision.targetAchieved ? 'محققة حاليًا' : 'تحتاج خطة تحسين'} tone={decision.targetAchieved ? 'green' : 'gold'} />
          <KpiCard title="اكتمال Workspace" value={`${workspace.completion}%`} hint="ملف الشركة + المراكز" tone={workspace.completion >= 80 ? 'green' : 'gold'} />
          <KpiCard title="جاهزية Beta" value={`${betaReadiness.score}%`} hint={betaReadiness.canIssueBetaReport ? 'جاهزة للتجربة الداخلية' : betaReadiness.nextAction} tone={betaReadiness.status === 'good' ? 'green' : betaReadiness.status === 'warning' ? 'gold' : 'red'} />
          <KpiCard title="الفجوة للهدف" value={`${Math.max(0, decision.classification.targetThreshold - decision.totalScore)} نقطة`} hint="مقارنة بالدرجة المستهدفة" tone={decision.targetAchieved ? 'green' : 'gold'} />
        </section>

        <section className="card" id="workspace">
          <h3>مراكز ملف الشركة</h3>
          <p className="muted">هذه المراكز تمنح المستشار صورة واحدة عن وضع الشركة بدل التنقل بين شاشات متفرقة.</p>
          <div className="center-grid">
            {workspace.centers.map(center => (
              <article className={`center-card status-${center.status}`} key={center.key}>
                <div>
                  <span>{statusLabel[center.status]}</span>
                  <h4>{center.title}</h4>
                  <p>{center.summary}</p>
                </div>
                <strong>{center.score}%</strong>
                <small>{center.nextAction}</small>
              </article>
            ))}
          </div>
        </section>

        <section className="grid two" id="company">
          <article className="card">
            <h3>بيانات الشركة</h3>
            <div className="form-grid">
              <label>اسم الشركة<input value={company.name} onChange={event => updateCompany('name', event.target.value)} /></label>
              <label>السجل التجاري<input value={company.crNumber} onChange={event => updateCompany('crNumber', event.target.value)} /></label>
              <label>رقم المنشأة<input value={company.entityNumber ?? ''} onChange={event => updateCompany('entityNumber', event.target.value)} /></label>
              <label>المدينة<input value={company.city ?? ''} onChange={event => updateCompany('city', event.target.value)} /></label>
              <label>عدد الفروع<input type="number" value={company.branches ?? 0} onChange={event => updateCompany('branches', Number(event.target.value))} /></label>
              <label>النشاط الرئيسي<input value={company.mainActivity ?? ''} onChange={event => updateCompany('mainActivity', event.target.value)} /></label>
              <label>سنة القوائم المالية<input type="number" value={company.financialYear ?? new Date().getFullYear()} onChange={event => updateCompany('financialYear', Number(event.target.value))} /></label>
              <label>الدرجة المستهدفة
                <select value={company.targetGrade} onChange={event => updateCompany('targetGrade', Number(event.target.value) as ClassificationGrade)}>
                  {[1,2,3,4,5].map(grade => <option value={grade} key={grade}>الدرجة {grade}</option>)}
                </select>
              </label>
            </div>
          </article>

          <article className="card" id="classification">
            <h3>مركز التصنيف</h3>
            <div className="classification-path">
              <div><span>الدرجة الحالية</span><strong>{gradeLabel(decision.grade)}</strong></div>
              <div className="path-line"><i style={{ width: `${Math.min(100, decision.readiness)}%` }} /></div>
              <div><span>الدرجة المستهدفة</span><strong>{gradeLabel(decision.targetGrade)}</strong></div>
            </div>
            <p className="muted">{workspace.nextBestAction}</p>
          </article>
        </section>

        <section className="grid two">
          <article className="card" id="finance">
            <h3>المركز المالي</h3>
            <div className="form-grid">
              {(Object.keys(company.financial) as Array<keyof FinancialInput>).map(key => (
                <label key={key}><span>{financialLabels[key]}</span><input type="number" value={company.financial[key]} onChange={event => updateFinancial(key, Number(event.target.value))} /></label>
              ))}
            </div>
          </article>

          <article className="card" id="technical">
            <h3>المركز الفني</h3>
            <label>حجم المنشأة
              <select value={company.technical.companySize} onChange={event => updateTechnical('companySize', event.target.value as TechnicalInput['companySize'])}>
                <option value="micro">متناهية الصغر</option>
                <option value="small">صغيرة</option>
                <option value="medium">متوسطة</option>
                <option value="large">كبيرة</option>
              </select>
            </label>
            <div className="form-grid">
              {(Object.keys(company.technical) as Array<keyof TechnicalInput>).filter(key => key !== 'companySize').map(key => (
                <label key={key}><span>{technicalLabels[key]}</span><input type="number" value={company.technical[key] as number} onChange={event => updateTechnical(key, Number(event.target.value))} /></label>
              ))}
            </div>
          </article>
        </section>




        <section className="card" id="beta-readiness">
          <div className="section-head">
            <div>
              <span className="eyebrow">Commit 10 Integration Gate</span>
              <h3>جاهزية RAWASI Beta</h3>
              <p className="muted">هذه الشاشة تجمع رحلة الشركة والمحركات في نقطة تحقق واحدة قبل اعتبار الملف جاهزًا للتجربة الداخلية أو التقرير التنفيذي.</p>
            </div>
            <div className={`beta-badge status-${betaReadiness.status}`}>
              <span>مؤشر الجاهزية</span>
              <strong>{betaReadiness.score}%</strong>
              <small>{betaReadiness.canIssueBetaReport ? 'جاهز للتجربة الداخلية' : 'يحتاج معالجة قبل الاعتماد'}</small>
            </div>
          </div>
          <div className="workflow-grid">
            {betaReadiness.workflow.map(step => (
              <article className={`workflow-step status-${step.status}`} key={step.key}>
                <span>{step.completed ? 'مكتمل' : 'غير مكتمل'}</span>
                <h4>{step.title}</h4>
                <p>{step.message}</p>
              </article>
            ))}
          </div>
          <div className="grid two compact-grid">
            <article className="mini-panel">
              <h4>صحة المحركات</h4>
              {betaReadiness.engineHealth.map(item => (
                <div className={`engine-health status-${item.status}`} key={item.engine}>
                  <strong>{item.engine}</strong>
                  <span>{item.message}</span>
                </div>
              ))}
            </article>
            <article className="mini-panel">
              <h4>الإجراء التالي</h4>
              <p className="muted">{betaReadiness.nextAction}</p>
              {betaReadiness.blockers.length > 0 && <ul className="warning-list danger">{betaReadiness.blockers.map(item => <li key={item}>{item}</li>)}</ul>}
              {betaReadiness.blockers.length === 0 && betaReadiness.warnings.length > 0 && <ul className="warning-list">{betaReadiness.warnings.map(item => <li key={item}>{item}</li>)}</ul>}
              {betaReadiness.blockers.length === 0 && betaReadiness.warnings.length === 0 && <p className="muted">لا توجد موانع أو تحذيرات جوهرية في رحلة Beta الحالية.</p>}
            </article>
          </div>
        </section>

        <section className="card" id="financial-extraction">
          <h3>محرك استخراج القوائم المالية</h3>
          <p className="muted">Commit 9 يضيف مسارًا أوليًا لاستخراج البنود المالية من نص منسوخ من PDF أو Excel. في المرحلة التالية يتم استبدال اللصق بخدمة OCR/Parser حقيقية.</p>
          <div className="grid two">
            <label>
              نص القوائم المالية
              <textarea className="statement-textarea" value={financialText} onChange={event => setFinancialText(event.target.value)} />
            </label>
            <div className="extraction-summary">
              <div className="score-mini">
                <span>تغطية البنود</span>
                <strong>{extraction.coverage}%</strong>
                <small>{extraction.fields.length} بنود مقروءة من 9</small>
              </div>
              <button className="primary" onClick={applyExtracted}>اعتماد الأرقام وإعادة الحساب</button>
              {extraction.warnings.length ? <ul className="warning-list">{extraction.warnings.map(item => <li key={item}>{item}</li>)}</ul> : <p className="muted">لم تظهر تحذيرات جوهرية في الاستخراج الحالي.</p>}
              {validationIssues.length ? <ul className="warning-list">{validationIssues.map(issue => <li key={issue.key}>{issue.title}: {issue.message}</li>)}</ul> : <p className="muted">البيانات المالية الحالية صالحة مبدئيًا للحساب.</p>}
            </div>
          </div>
          <div className="table-card">
            <table>
              <thead><tr><th>البند الداخلي</th><th>القيمة المستخرجة</th><th>الثقة</th><th>السطر المصدر</th></tr></thead>
              <tbody>
                {mapping.map(row => (
                  <tr key={row.targetKey}>
                    <td>{row.targetLabel}</td>
                    <td>{row.status === 'mapped' ? row.value?.toLocaleString('ar-SA') : 'غير مقروء'}</td>
                    <td>{row.confidence ? `${row.confidence}%` : '—'}</td>
                    <td>{row.sourceLine ?? '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section className="card" id="classification-engine">
          <h3>Recommendation Engine</h3>
          <p className="muted">هذا القسم يعرض نتيجة خط أنابيب التصنيف: المالي، الفني، المستندات، ثم الثقة والفجوات المطلوبة للوصول إلى الدرجة المستهدفة.</p>
          <div className="pipeline-grid">
            {decision.classification.components.map(component => (
              <article className={`pipeline-card status-${component.status}`} key={component.key}>
                <span>{component.title}</span>
                <strong>{component.score}%</strong>
                <small>الوزن: {(component.weight * 100).toFixed(0)}% • المساهمة: {component.weightedScore} نقطة</small>
                <small>عدد الأدلة: {component.evidenceCount}</small>
              </article>
            ))}
          </div>
          <div className="classification-insights">
            <div>
              <span>نسبة الثقة</span>
              <strong>{decision.confidence}%</strong>
              <small>تزيد مع اكتمال القوائم، البيانات الفنية، والمستندات.</small>
            </div>
            <div>
              <span>الحد المطلوب للهدف</span>
              <strong>{decision.classification.targetThreshold}</strong>
              <small>الفجوة الحالية: {Math.max(0, decision.classification.targetThreshold - decision.totalScore)} نقطة.</small>
            </div>
            <div>
              <span>آخر تقييم</span>
              <strong>{gradeLabel(decision.classification.history[0].grade)}</strong>
              <small>{decision.classification.history[0].note}</small>
            </div>
          </div>
        </section>

        <section className="card" id="missing-requirements">
          <h3>متطلبات ناقصة مؤثرة على التصنيف</h3>
          {decision.missingRequirements.length === 0 ? <p className="muted">لا توجد متطلبات ناقصة مؤثرة وفق البيانات الحالية.</p> : (
            <div className="requirements-list">
              {decision.missingRequirements.slice(0, 8).map(requirement => (
                <article className={`requirement status-${requirement.severity}`} key={requirement.id}>
                  <div>
                    <span>{requirement.domain}</span>
                    <h4>{requirement.title}</h4>
                    <p>الحالي: {requirement.current}</p>
                    <p>المطلوب: {requirement.required}</p>
                    <small>{requirement.recommendation}</small>
                  </div>
                  <strong>+{requirement.impact}</strong>
                </article>
              ))}
            </div>
          )}
        </section>

        <section className="card" id="rules">
          <h3>RAWASI Rules Engine</h3>
          <p className="muted">جميع قواعد التقييم الفني أصبحت في مستودع قواعد مستقل، مع رقم قاعدة وإصدار ومرجع صفحة من الدليل. الواجهة لا تحتوي على شروط تصنيف مباشرة؛ هي تعرض فقط نتائج محرك القواعد.</p>
          <div className="rules-grid">
            {technicalRulesCatalog.map(rule => (
              <article className="rule-card" key={rule.id}>
                <span>{rule.id} • v{rule.version}</span>
                <h4>{rule.title}</h4>
                <p>{rule.source.table ?? 'قاعدة تقييم'} — صفحة {rule.source.page}</p>
                <strong>{rule.maxScore} نقطة</strong>
                <small>{rule.weightGroup === 'basic' ? 'معيار أساسي' : 'معيار إضافي'}</small>
              </article>
            ))}
          </div>
        </section>

        <section className="grid two" id="documents">
          <article className="card">
            <h3>مركز المستندات</h3>
            {company.documents.map(doc => (
              <label className="check-row" key={doc.id}>
                <input type="checkbox" checked={doc.present} onChange={() => toggleDocument(doc.id)} />
                <span>{doc.name}</span>
                <small>{doc.category ?? 'classification'}</small>
              </label>
            ))}
          </article>
          <article className="card">
            <h3>جاهزية ملف التقديم</h3>
            <FactorList title="العوائق الحرجة" items={decision.blockers} empty="لا توجد عوائق حرجة في البيانات الحالية." />
          </article>
        </section>

        <section className="grid three" id="decision">
          <FactorList title="العوائق الحرجة" items={decision.blockers} empty="لا توجد عوائق حرجة في البيانات الحالية." />
          <FactorList title="نقاط القوة" items={decision.strengths} empty="أدخل بيانات أكثر لاستخراج نقاط القوة." />
          <FactorList title="خطة رفع التصنيف" items={decision.recommendations} empty="لا توجد توصيات مطلوبة حاليًا." />
        </section>

        <section className="card" id="recommendations">
          <h3>Recommendation Engine</h3>
          <p className="muted">{decision.recommendationPlan.summary}</p>
          {decision.recommendationPlan.alerts.length > 0 && (
            <div className="alert-list">
              {decision.recommendationPlan.alerts.map(alert => <div className="smart-alert" key={alert}>{alert}</div>)}
            </div>
          )}
          <div className="recommendation-grid">
            {decision.recommendationPlan.actions.slice(0, 8).map(action => (
              <article className={`recommendation-card priority-${action.priority}`} key={action.id}>
                <div>
                  <span>{action.priority === 'urgent' ? 'عاجل' : action.priority === 'high' ? 'مرتفع' : action.priority === 'medium' ? 'متوسط' : 'منخفض'}</span>
                  <h4>{action.title}</h4>
                  <p>{action.reason}</p>
                  <strong>{action.action}</strong>
                  <small>المدة: {action.timeframe} • الجهد: {action.effort === 'low' ? 'منخفض' : action.effort === 'medium' ? 'متوسط' : 'مرتفع'} • الثقة: {action.confidence}%</small>
                </div>
                <div className="impact-badge">
                  <b>+{action.expectedImpact}</b>
                  <small>نقطة</small>
                  <em>{gradeLabel(action.simulatedGrade)}</em>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="grid two" id="roadmap">
          <article className="card">
            <h3>خارطة رفع التصنيف</h3>
            <div className="roadmap-list">
              {decision.recommendationPlan.phases.map(phase => (
                <article className="phase-card" key={phase.title}>
                  <span>{phase.timeframe}</span>
                  <h4>{phase.title}</h4>
                  <p>الأثر المتوقع: +{phase.expectedGain} نقطة</p>
                  <ul>
                    {phase.actions.map(action => <li key={action.id}>{action.action}</li>)}
                  </ul>
                </article>
              ))}
            </div>
          </article>
          <article className="card">
            <h3>Quick Wins</h3>
            {decision.recommendationPlan.quickWins.length === 0 ? <p className="muted">لا توجد فرص سريعة حالياً.</p> : (
              <div className="quick-list">
                {decision.recommendationPlan.quickWins.map(action => (
                  <div className="quick-item" key={action.id}>
                    <strong>{action.title}</strong>
                    <span>+{action.expectedImpact} نقطة</span>
                    <small>{action.timeframe}</small>
                  </div>
                ))}
              </div>
            )}
            <h3 style={{ marginTop: '18px' }}>إجراءات استراتيجية</h3>
            {decision.recommendationPlan.strategicActions.length === 0 ? <p className="muted">لا توجد إجراءات استراتيجية عالية الجهد حالياً.</p> : (
              <div className="quick-list">
                {decision.recommendationPlan.strategicActions.map(action => (
                  <div className="quick-item" key={action.id}>
                    <strong>{action.title}</strong>
                    <span>+{action.expectedImpact} نقطة</span>
                    <small>{action.timeframe}</small>
                  </div>
                ))}
              </div>
            )}
          </article>
        </section>


        <section className="card executive-report" id="executive-report">
          <div className="section-head">
            <div>
              <span className="eyebrow">Executive Report Engine V2</span>
              <h3>التقرير التنفيذي</h3>
              <p className="muted">تقرير قابل للطباعة موجه للإدارة، يجمع التصنيف، الجاهزية، المخاطر، وخطة العمل في صفحة واحدة.</p>
            </div>
            <div className="report-id">{executiveReport.reportId}</div>
          </div>
          <div className="report-hero">
            <div>
              <span>الشركة</span>
              <strong>{executiveReport.companyName}</strong>
              <small>{new Date(executiveReport.generatedAt).toLocaleString('ar-SA')}</small>
            </div>
            <div>
              <span>التصنيف الحالي</span>
              <strong>{executiveReport.classification}</strong>
              <small>المستهدف: {executiveReport.targetClassification}</small>
            </div>
            <div>
              <span>جاهزية التصنيف</span>
              <strong>{executiveReport.readiness}%</strong>
              <small>الثقة: {executiveReport.confidence}%</small>
            </div>
          </div>
          <div className="board-summary">
            <h4>{executiveReport.headline}</h4>
            <p>{executiveReport.boardSummary}</p>
          </div>
          <div className="report-sections">
            {executiveReport.sections.map(section => (
              <article key={section.title}>
                <h4>{section.title}</h4>
                <p>{section.body}</p>
                <ul>
                  {section.bullets.map(bullet => <li key={bullet}>{bullet}</li>)}
                </ul>
              </article>
            ))}
          </div>
        </section>

        <section className="card" id="board-dashboard">
          <h3>لوحة الإدارة</h3>
          <p className="muted">مؤشرات مختصرة تساعد الإدارة على معرفة جاهزية ملف التصنيف بدون الدخول في التفاصيل الفنية.</p>
          <div className="executive-kpis">
            {executiveReport.kpis.map(kpi => (
              <article className={`executive-kpi status-${kpi.status}`} key={kpi.key}>
                <span>{kpi.title}</span>
                <strong>{kpi.value}{kpi.unit}</strong>
                <small>{kpi.description}</small>
              </article>
            ))}
          </div>
        </section>

        <section className="card" id="timeline">
          <h3>السجل الزمني لملف الشركة</h3>
          <div className="timeline">
            {workspace.timeline.map(event => (
              <article key={event.id}>
                <span>{timelineTypeLabel(event.type)}</span>
                <div>
                  <strong>{event.title}</strong>
                  <p>{event.description}</p>
                  <small>{new Date(event.at).toLocaleString('ar-SA')}</small>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="card" id="simulator">
          <h3>محاكي ماذا لو؟</h3>
          <p className="muted">عدّل السيناريو دون تغيير بيانات الشركة الأصلية، وشاهد أثره على الدرجة.</p>
          <div className="simulator-grid">
            <label>زيادة حقوق الملكية<input type="number" value={simPatch.equityDelta} onChange={event => setSimPatch(prev => ({ ...prev, equityDelta: Number(event.target.value) }))} /></label>
            <label>تخفيض الالتزامات<input type="number" value={Math.abs(simPatch.liabilitiesDelta)} onChange={event => setSimPatch(prev => ({ ...prev, liabilitiesDelta: -Math.abs(Number(event.target.value)) }))} /></label>
            <label>زيادة الأصول المتداولة<input type="number" value={simPatch.currentAssetsDelta} onChange={event => setSimPatch(prev => ({ ...prev, currentAssetsDelta: Number(event.target.value) }))} /></label>
            <label>زيادة نسبة المهندسين<input type="number" value={simPatch.engineersPercentDelta} onChange={event => setSimPatch(prev => ({ ...prev, engineersPercentDelta: Number(event.target.value) }))} /></label>
            <div className="simulation-result">
              <span>النتيجة بعد السيناريو</span>
              <strong>{gradeLabel(simulation.decision.grade)}</strong>
              <small>{simulation.decision.totalScore}/100 نقطة</small>
            </div>
          </div>
        </section>
      </section>
    </main>
  );
}
