import type { RawasiDataStoreSnapshot } from '../types-enterprise';

export const RAWASI_SCHEMA_VERSION = 1 as const;

export function nowIso() {
  return new Date().toISOString();
}

export function createId(prefix: string) {
  const safePrefix = prefix.replace(/[^a-z0-9_-]/gi, '').toLowerCase() || 'id';
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
    return `${safePrefix}_${crypto.randomUUID()}`;
  }
  return `${safePrefix}_${Date.now()}_${Math.random().toString(16).slice(2)}`;
}

export function createEmptySnapshot(): RawasiDataStoreSnapshot {
  return {
    schemaVersion: RAWASI_SCHEMA_VERSION,
    exportedAt: nowIso(),
    users: [],
    companies: [],
    financialStatements: [],
    technicalProfiles: [],
    documents: [],
    classificationRuns: [],
    auditEvents: []
  };
}

export function normalizeSnapshot(input: Partial<RawasiDataStoreSnapshot> | null | undefined): RawasiDataStoreSnapshot {
  const empty = createEmptySnapshot();
  if (!input) return empty;
  return {
    schemaVersion: RAWASI_SCHEMA_VERSION,
    exportedAt: input.exportedAt || empty.exportedAt,
    users: Array.isArray(input.users) ? input.users : [],
    companies: Array.isArray(input.companies) ? input.companies : [],
    financialStatements: Array.isArray(input.financialStatements) ? input.financialStatements : [],
    technicalProfiles: Array.isArray(input.technicalProfiles) ? input.technicalProfiles : [],
    documents: Array.isArray(input.documents) ? input.documents : [],
    classificationRuns: Array.isArray(input.classificationRuns) ? input.classificationRuns : [],
    auditEvents: Array.isArray(input.auditEvents) ? input.auditEvents : []
  };
}
