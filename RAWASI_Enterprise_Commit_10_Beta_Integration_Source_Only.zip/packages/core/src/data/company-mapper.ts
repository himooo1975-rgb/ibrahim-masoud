import type { Company } from '../types';
import type { CompanyRecord, DocumentRecord, FinancialStatementRecord, TechnicalProfileRecord } from '../types-enterprise';
import { createId, nowIso } from './schema';

export function companyToRecords(company: Company) {
  const stamp = nowIso();
  const companyRecord: CompanyRecord = {
    id: company.id || createId('company'),
    profile: {
      name: company.name,
      crNumber: company.crNumber,
      activity: company.activity,
      targetGrade: company.targetGrade,
      entityNumber: company.entityNumber,
      branches: company.branches,
      city: company.city,
      mainActivity: company.mainActivity,
      financialYear: company.financialYear
    },
    createdAt: stamp,
    updatedAt: stamp,
    status: 'draft'
  };

  const financialStatement: FinancialStatementRecord = {
    id: createId('fin'),
    companyId: companyRecord.id,
    year: company.financialYear || new Date().getFullYear(),
    source: 'manual',
    values: company.financial,
    createdAt: stamp,
    updatedAt: stamp
  };

  const technicalProfile: TechnicalProfileRecord = {
    id: createId('tech'),
    companyId: companyRecord.id,
    values: company.technical,
    source: 'manual',
    createdAt: stamp,
    updatedAt: stamp
  };

  const documents: DocumentRecord[] = company.documents.map((document, index) => ({
    ...document,
    id: document.id || createId(`doc_${index}`),
    companyId: companyRecord.id,
    version: 1,
    uploadedAt: document.present ? stamp : undefined
  }));

  return { companyRecord, financialStatement, technicalProfile, documents };
}

export function recordsToCompany(
  companyRecord: CompanyRecord,
  financialStatements: FinancialStatementRecord[],
  technicalProfiles: TechnicalProfileRecord[],
  documents: DocumentRecord[],
  fallback: Company
): Company {
  const latestFinancial = [...financialStatements].sort((a, b) => b.year - a.year || b.updatedAt.localeCompare(a.updatedAt))[0];
  const latestTechnical = [...technicalProfiles].sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))[0];
  return {
    ...fallback,
    id: companyRecord.id,
    ...companyRecord.profile,
    financialYear: latestFinancial?.year ?? companyRecord.profile.financialYear,
    financial: latestFinancial?.values ?? fallback.financial,
    technical: latestTechnical?.values ?? fallback.technical,
    documents: documents.map(({ companyId: _companyId, storagePath: _storagePath, uploadedBy: _uploadedBy, version: _version, ...document }) => document),
    timeline: fallback.timeline || []
  };
}
