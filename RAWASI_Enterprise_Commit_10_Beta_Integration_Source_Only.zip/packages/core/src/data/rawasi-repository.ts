import type { Company } from '../types';
import type { AuditEventRecord, RawasiDataStoreSnapshot } from '../types-enterprise';
import { companyToRecords, recordsToCompany } from './company-mapper';
import { RawasiInMemoryDatabase } from './in-memory-database';
import { createId, nowIso } from './schema';

export class RawasiRepository {
  constructor(private readonly db = new RawasiInMemoryDatabase()) {}

  static fromSnapshot(snapshot?: Partial<RawasiDataStoreSnapshot>) {
    return new RawasiRepository(new RawasiInMemoryDatabase(snapshot));
  }

  exportSnapshot() {
    return this.db.getSnapshot();
  }

  importSnapshot(snapshot: Partial<RawasiDataStoreSnapshot>) {
    this.db.replaceSnapshot(snapshot);
  }

  saveCompany(company: Company, userId?: string) {
    const stamp = nowIso();
    const { companyRecord, financialStatement, technicalProfile, documents } = companyToRecords(company);
    const current = this.db.getSnapshot();
    const existing = current.companies.find(item => item.id === companyRecord.id || item.profile.crNumber === companyRecord.profile.crNumber);
    const resolvedCompany = existing
      ? { ...existing, profile: companyRecord.profile, updatedAt: stamp }
      : { ...companyRecord, createdAt: stamp, updatedAt: stamp };

    this.db.upsert('companies', resolvedCompany);
    this.db.upsert('financialStatements', { ...financialStatement, companyId: resolvedCompany.id, updatedAt: stamp });
    this.db.upsert('technicalProfiles', { ...technicalProfile, companyId: resolvedCompany.id, updatedAt: stamp });
    documents.forEach(document => this.db.upsert('documents', { ...document, companyId: resolvedCompany.id }));
    this.addAudit({
      companyId: resolvedCompany.id,
      userId,
      entityType: 'company',
      entityId: resolvedCompany.id,
      title: existing ? 'تحديث ملف الشركة' : 'إنشاء ملف شركة',
      description: `تم حفظ ملف ${resolvedCompany.profile.name}`,
      type: 'company'
    });
    return resolvedCompany.id;
  }

  listCompanies(fallback: Company): Company[] {
    const snapshot = this.db.getSnapshot();
    return snapshot.companies.map(companyRecord => this.getCompany(companyRecord.id, fallback)).filter(Boolean) as Company[];
  }

  getCompany(companyId: string, fallback: Company) {
    const snapshot = this.db.getSnapshot();
    const companyRecord = snapshot.companies.find(company => company.id === companyId);
    if (!companyRecord) return null;
    return recordsToCompany(
      companyRecord,
      snapshot.financialStatements.filter(item => item.companyId === companyId),
      snapshot.technicalProfiles.filter(item => item.companyId === companyId),
      snapshot.documents.filter(item => item.companyId === companyId),
      { ...fallback, id: companyId }
    );
  }

  addAudit(event: Omit<AuditEventRecord, 'id' | 'at'>) {
    this.db.upsert('auditEvents', {
      id: createId('audit'),
      at: nowIso(),
      ...event
    });
  }
}
