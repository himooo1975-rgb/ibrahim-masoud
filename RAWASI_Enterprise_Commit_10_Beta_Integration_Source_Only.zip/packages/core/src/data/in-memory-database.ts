import type { RawasiDataStoreSnapshot } from '../types-enterprise';
import { createEmptySnapshot, normalizeSnapshot, nowIso } from './schema';

export class RawasiInMemoryDatabase {
  private snapshot: RawasiDataStoreSnapshot;

  constructor(initial?: Partial<RawasiDataStoreSnapshot>) {
    this.snapshot = normalizeSnapshot(initial);
  }

  getSnapshot(): RawasiDataStoreSnapshot {
    return JSON.parse(JSON.stringify({ ...this.snapshot, exportedAt: nowIso() }));
  }

  replaceSnapshot(snapshot: Partial<RawasiDataStoreSnapshot>) {
    this.snapshot = normalizeSnapshot(snapshot);
  }

  reset() {
    this.snapshot = createEmptySnapshot();
  }

  upsert<T extends { id: string }>(collection: keyof RawasiDataStoreSnapshot, record: T) {
    const list = this.snapshot[collection];
    if (!Array.isArray(list)) throw new Error(`Collection ${String(collection)} is not writable`);
    const index = list.findIndex(item => (item as { id: string }).id === record.id);
    if (index >= 0) {
      (list as unknown as T[])[index] = record;
    } else {
      (list as unknown as T[]).push(record);
    }
  }

  remove(collection: keyof RawasiDataStoreSnapshot, id: string) {
    const list = this.snapshot[collection];
    if (!Array.isArray(list)) throw new Error(`Collection ${String(collection)} is not writable`);
    const index = list.findIndex(item => (item as { id: string }).id === id);
    if (index >= 0) list.splice(index, 1);
  }
}
