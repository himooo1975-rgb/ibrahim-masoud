import type { ClassificationResult, Company, DecisionResult, DocumentItem, FinancialInput, RecommendationPlan, TechnicalInput, TimelineEvent } from './types';

export type RawasiEntityId = string;
export type RawasiUserRole = 'owner' | 'admin' | 'consultant' | 'reviewer' | 'viewer';
export type RawasiPermission =
  | 'company.read'
  | 'company.write'
  | 'financial.write'
  | 'technical.write'
  | 'documents.write'
  | 'classification.run'
  | 'reports.export'
  | 'settings.manage';

export type RawasiUser = {
  id: RawasiEntityId;
  name: string;
  email: string;
  role: RawasiUserRole;
  permissions: RawasiPermission[];
  active: boolean;
  createdAt: string;
};

export type CompanyRecord = {
  id: RawasiEntityId;
  profile: Pick<Company, 'name' | 'crNumber' | 'activity' | 'targetGrade' | 'entityNumber' | 'branches' | 'city' | 'mainActivity' | 'financialYear'>;
  createdAt: string;
  updatedAt: string;
  status: 'draft' | 'in-review' | 'ready' | 'submitted' | 'archived';
};

export type FinancialStatementRecord = {
  id: RawasiEntityId;
  companyId: RawasiEntityId;
  year: number;
  source: 'manual' | 'excel' | 'pdf' | 'ocr' | 'api';
  values: FinancialInput;
  uploadedDocumentId?: RawasiEntityId;
  createdAt: string;
  updatedAt: string;
};

export type TechnicalProfileRecord = {
  id: RawasiEntityId;
  companyId: RawasiEntityId;
  values: TechnicalInput;
  source: 'manual' | 'api' | 'import';
  createdAt: string;
  updatedAt: string;
};

export type DocumentRecord = DocumentItem & {
  companyId: RawasiEntityId;
  fileName?: string;
  fileSize?: number;
  storagePath?: string;
  uploadedAt?: string;
  uploadedBy?: RawasiEntityId;
  version: number;
};

export type ClassificationRunRecord = {
  id: RawasiEntityId;
  companyId: RawasiEntityId;
  runAt: string;
  runBy?: RawasiEntityId;
  decision: DecisionResult;
  classification: ClassificationResult;
  recommendationPlan: RecommendationPlan;
  ruleSetVersion: string;
  note?: string;
};

export type AuditEventRecord = TimelineEvent & {
  companyId?: RawasiEntityId;
  userId?: RawasiEntityId;
  entityType: 'company' | 'financial' | 'technical' | 'document' | 'classification' | 'report' | 'system';
  entityId?: RawasiEntityId;
  metadata?: Record<string, unknown>;
};

export type RawasiDataStoreSnapshot = {
  schemaVersion: 1;
  exportedAt: string;
  users: RawasiUser[];
  companies: CompanyRecord[];
  financialStatements: FinancialStatementRecord[];
  technicalProfiles: TechnicalProfileRecord[];
  documents: DocumentRecord[];
  classificationRuns: ClassificationRunRecord[];
  auditEvents: AuditEventRecord[];
};
