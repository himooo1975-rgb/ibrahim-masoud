import type { FinancialInput } from '../types';

export type ExtractedFinancialField = {
  key: keyof FinancialInput;
  label: string;
  value: number;
  confidence: number;
  matchedLine: string;
};

export type FinancialExtractionResult = {
  sourceType: 'text' | 'csv' | 'manual';
  rawText: string;
  fields: ExtractedFinancialField[];
  values: Partial<FinancialInput>;
  coverage: number;
  warnings: string[];
};

const FIELD_PATTERNS: Record<keyof FinancialInput, { label: string; aliases: string[] }> = {
  revenue: { label: 'الإيرادات', aliases: ['الايرادات', 'الإيرادات', 'المبيعات', 'إيرادات العقود', 'إيرادات النشاط'] },
  netProfit: { label: 'صافي الربح', aliases: ['صافي الربح', 'صافي الدخل', 'ربح السنة', 'صافي ربح السنة', 'الربح بعد الزكاة'] },
  assets: { label: 'إجمالي الأصول', aliases: ['إجمالي الأصول', 'اجمالي الاصول', 'مجموع الأصول', 'مجموع الاصول'] },
  liabilities: { label: 'إجمالي الالتزامات', aliases: ['إجمالي الالتزامات', 'اجمالي الالتزامات', 'مجموع الالتزامات', 'إجمالي المطلوبات'] },
  equity: { label: 'حقوق الملكية', aliases: ['حقوق الملكية', 'إجمالي حقوق الملكية', 'اجمالي حقوق الملكية', 'حقوق الملاك'] },
  cash: { label: 'النقد وما في حكمه', aliases: ['النقد وما في حكمه', 'النقدية', 'النقد لدى البنوك', 'النقد وما يعادله'] },
  currentAssets: { label: 'الأصول المتداولة', aliases: ['الأصول المتداولة', 'اجمالي الأصول المتداولة', 'إجمالي الأصول المتداولة'] },
  currentLiabilities: { label: 'الالتزامات المتداولة', aliases: ['الالتزامات المتداولة', 'إجمالي الالتزامات المتداولة', 'المطلوبات المتداولة'] },
  operatingCashFlow: { label: 'التدفق النقدي التشغيلي', aliases: ['التدفق النقدي التشغيلي', 'صافي النقد من الأنشطة التشغيلية', 'النقد الناتج من التشغيل', 'صافي التدفقات النقدية التشغيلية'] }
};

function normalizeArabic(input: string) {
  return input
    .replace(/[أإآ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ة/g, 'ه')
    .replace(/ؤ/g, 'و')
    .replace(/ئ/g, 'ي')
    .replace(/[ًٌٍَُِّْ]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function parseNumber(line: string): number | null {
  const cleaned = line
    .replace(/[٬,]/g, '')
    .replace(/[−–—]/g, '-')
    .replace(/\(([^)]+)\)/g, '-$1');
  const matches = cleaned.match(/-?\d+(?:\.\d+)?/g);
  if (!matches?.length) return null;
  const value = Number(matches[matches.length - 1]);
  return Number.isFinite(value) ? value : null;
}

function confidenceFor(line: string, alias: string) {
  const normalizedLine = normalizeArabic(line);
  const normalizedAlias = normalizeArabic(alias);
  if (normalizedLine.includes(normalizedAlias)) return Math.min(98, 72 + Math.round((normalizedAlias.length / Math.max(10, normalizedLine.length)) * 80));
  return 0;
}

export function extractFinancialsFromText(rawText: string, sourceType: FinancialExtractionResult['sourceType'] = 'text'): FinancialExtractionResult {
  const lines = rawText.split(/\r?\n/).map(line => line.trim()).filter(Boolean);
  const fields: ExtractedFinancialField[] = [];
  const values: Partial<FinancialInput> = {};
  const warnings: string[] = [];

  for (const [key, config] of Object.entries(FIELD_PATTERNS) as Array<[keyof FinancialInput, typeof FIELD_PATTERNS[keyof FinancialInput]]>) {
    let best: ExtractedFinancialField | null = null;
    for (const line of lines) {
      for (const alias of config.aliases) {
        const confidence = confidenceFor(line, alias);
        if (!confidence) continue;
        const value = parseNumber(line);
        if (value === null) continue;
        if (!best || confidence > best.confidence) {
          best = { key, label: config.label, value, confidence, matchedLine: line };
        }
      }
    }
    if (best) {
      fields.push(best);
      values[key] = best.value;
    }
  }

  if (values.assets && values.liabilities && values.equity) {
    const diff = Math.abs(values.assets - values.liabilities - values.equity);
    const tolerance = Math.max(5, values.assets * 0.03);
    if (diff > tolerance) warnings.push(`معادلة الميزانية غير متزنة بالكامل: الأصول لا تساوي الالتزامات + حقوق الملكية بفارق ${Math.round(diff).toLocaleString('ar-SA')}.`);
  }

  const requiredCount = Object.keys(FIELD_PATTERNS).length;
  const coverage = Math.round((fields.length / requiredCount) * 100);
  if (coverage < 60) warnings.push('نسبة تغطية البنود المالية منخفضة؛ يفضل مراجعة الربط أو الإدخال اليدوي قبل الاعتماد.');

  return { sourceType, rawText, fields, values, coverage, warnings };
}

export function mergeFinancialInput(base: FinancialInput, extracted: Partial<FinancialInput>): FinancialInput {
  return { ...base, ...Object.fromEntries(Object.entries(extracted).filter(([, value]) => Number.isFinite(value))) } as FinancialInput;
}
