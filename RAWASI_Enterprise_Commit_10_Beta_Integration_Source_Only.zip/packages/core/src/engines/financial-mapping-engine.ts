import type { FinancialInput } from '../types';
import type { ExtractedFinancialField } from './financial-extraction-engine';

export type FinancialMappingRow = {
  targetKey: keyof FinancialInput;
  targetLabel: string;
  value?: number;
  sourceLine?: string;
  confidence?: number;
  status: 'mapped' | 'missing';
};

const labels: Record<keyof FinancialInput, string> = {
  revenue: 'الإيرادات',
  netProfit: 'صافي الربح',
  assets: 'إجمالي الأصول',
  liabilities: 'إجمالي الالتزامات',
  equity: 'حقوق الملكية',
  cash: 'النقد وما في حكمه',
  currentAssets: 'الأصول المتداولة',
  currentLiabilities: 'الالتزامات المتداولة',
  operatingCashFlow: 'التدفق النقدي التشغيلي'
};

export function buildFinancialMapping(fields: ExtractedFinancialField[]): FinancialMappingRow[] {
  return (Object.keys(labels) as Array<keyof FinancialInput>).map(key => {
    const field = fields.find(item => item.key === key);
    return {
      targetKey: key,
      targetLabel: labels[key],
      value: field?.value,
      sourceLine: field?.matchedLine,
      confidence: field?.confidence,
      status: field ? 'mapped' : 'missing'
    };
  });
}
