import type { FinancialInput, ReadinessStatus } from '../types';

export type FinancialValidationIssue = {
  key: string;
  title: string;
  status: ReadinessStatus;
  message: string;
};

export function validateFinancialInput(input: FinancialInput): FinancialValidationIssue[] {
  const issues: FinancialValidationIssue[] = [];
  const required: Array<keyof FinancialInput> = ['revenue', 'assets', 'liabilities', 'equity', 'currentAssets', 'currentLiabilities'];
  for (const key of required) {
    if (!Number.isFinite(input[key]) || input[key] <= 0) {
      issues.push({ key, title: `بيان مالي مطلوب: ${key}`, status: 'critical', message: 'هذا البند مطلوب لاحتساب التقييم المالي بدرجة ثقة مناسبة.' });
    }
  }

  if (input.assets > 0 && input.liabilities >= 0 && input.equity >= 0) {
    const diff = Math.abs(input.assets - input.liabilities - input.equity);
    const tolerance = Math.max(5, input.assets * 0.03);
    if (diff > tolerance) {
      issues.push({ key: 'balance-equation', title: 'اتزان الميزانية', status: 'warning', message: `يوجد فرق تقريبي ${Math.round(diff).toLocaleString('ar-SA')} بين الأصول ومجموع الالتزامات وحقوق الملكية.` });
    }
  }

  if (input.currentLiabilities > input.liabilities && input.liabilities > 0) {
    issues.push({ key: 'current-liabilities', title: 'الالتزامات المتداولة', status: 'warning', message: 'الالتزامات المتداولة أكبر من إجمالي الالتزامات؛ راجع الإدخال.' });
  }

  return issues;
}
