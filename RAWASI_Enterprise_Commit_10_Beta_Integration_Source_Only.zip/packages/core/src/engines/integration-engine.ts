import type { Company, DecisionResult, ReadinessStatus } from '../types';
import { buildDecision } from './decision-engine';
import { buildExecutiveReport } from './executive-report-engine';
import { validateFinancialInput } from './financial-validation-engine';
import { buildWorkspace } from './workspace-engine';

export type WorkflowStepKey =
  | 'company-profile'
  | 'financial-data'
  | 'technical-data'
  | 'documents'
  | 'classification'
  | 'recommendations'
  | 'executive-report';

export type WorkflowStep = {
  key: WorkflowStepKey;
  title: string;
  status: ReadinessStatus;
  completed: boolean;
  message: string;
};

export type EngineHealthItem = {
  engine: string;
  status: ReadinessStatus;
  message: string;
};

export type BetaReadinessResult = {
  score: number;
  status: ReadinessStatus;
  canIssueBetaReport: boolean;
  workflow: WorkflowStep[];
  engineHealth: EngineHealthItem[];
  blockers: string[];
  warnings: string[];
  nextAction: string;
  decision: DecisionResult;
};

function statusFromPercent(value: number): ReadinessStatus {
  if (value >= 80) return 'good';
  if (value >= 55) return 'warning';
  return 'critical';
}

function boolStep(key: WorkflowStepKey, title: string, completed: boolean, message: string, warningMessage?: string): WorkflowStep {
  return {
    key,
    title,
    completed,
    status: completed ? 'good' : 'critical',
    message: completed ? message : (warningMessage ?? 'غير مكتمل')
  };
}

function hasUsableFinancialData(company: Company) {
  const required = ['revenue', 'assets', 'liabilities', 'equity', 'currentAssets', 'currentLiabilities'] as const;
  return required.every(key => Number.isFinite(company.financial[key]) && company.financial[key] > 0);
}

function hasUsableTechnicalData(company: Company) {
  const technicalKeys = ['engineersPercent', 'techniciansPercent', 'engineersExperience', 'techniciansExperience'] as const;
  return technicalKeys.some(key => Number.isFinite(company.technical[key]) && company.technical[key] > 0);
}

export function buildWorkflowStatus(company: Company, decision: DecisionResult = buildDecision(company)): WorkflowStep[] {
  const financialIssues = validateFinancialInput(company.financial);
  const requiredDocs = company.documents.filter(doc => doc.required);
  const presentRequiredDocs = requiredDocs.filter(doc => doc.present);
  const report = buildExecutiveReport(company, decision);

  return [
    boolStep(
      'company-profile',
      'إنشاء ملف الشركة',
      Boolean(company.name?.trim() && company.crNumber?.trim()),
      'بيانات الشركة الأساسية مكتملة.',
      'أدخل اسم الشركة والسجل التجاري قبل تشغيل التصنيف.'
    ),
    {
      key: 'financial-data',
      title: 'القوائم المالية',
      completed: hasUsableFinancialData(company) && !financialIssues.some(issue => issue.status === 'critical'),
      status: financialIssues.some(issue => issue.status === 'critical') ? 'critical' : financialIssues.length ? 'warning' : 'good',
      message: financialIssues.length ? financialIssues.map(issue => issue.message).join(' / ') : 'القوائم المالية قابلة للحساب.'
    },
    boolStep(
      'technical-data',
      'البيانات الفنية',
      hasUsableTechnicalData(company),
      'البيانات الفنية كافية لتشغيل Rules Engine.',
      'أدخل نسب الكوادر والخبرات الفنية لرفع ثقة القرار.'
    ),
    {
      key: 'documents',
      title: 'مستندات التصنيف',
      completed: requiredDocs.length > 0 && presentRequiredDocs.length === requiredDocs.length,
      status: requiredDocs.length === 0 ? 'warning' : presentRequiredDocs.length === requiredDocs.length ? 'good' : presentRequiredDocs.length / requiredDocs.length >= 0.6 ? 'warning' : 'critical',
      message: `${presentRequiredDocs.length} من ${requiredDocs.length} مستند مطلوب مكتمل.`
    },
    {
      key: 'classification',
      title: 'احتساب التصنيف',
      completed: decision.confidence >= 55,
      status: statusFromPercent(decision.confidence),
      message: `تم احتساب التصنيف بدرجة ثقة ${decision.confidence}%.`
    },
    {
      key: 'recommendations',
      title: 'خطة التحسين',
      completed: decision.targetAchieved || decision.recommendationPlan.actions.length > 0,
      status: decision.targetAchieved || decision.recommendationPlan.actions.length > 0 ? 'good' : 'warning',
      message: decision.targetAchieved ? 'الدرجة المستهدفة محققة، والخطة للمحافظة على الجاهزية.' : `${decision.recommendationPlan.actions.length} إجراء مقترح لرفع التصنيف.`
    },
    {
      key: 'executive-report',
      title: 'التقرير التنفيذي',
      completed: Boolean(report.sections.length && report.kpis.length),
      status: report.sections.length && report.kpis.length ? 'good' : 'warning',
      message: report.sections.length && report.kpis.length ? 'التقرير التنفيذي قابل للإصدار والطباعة.' : 'يحتاج التقرير بيانات إضافية قبل الاعتماد.'
    }
  ];
}

export function buildEngineHealth(company: Company, decision: DecisionResult = buildDecision(company)): EngineHealthItem[] {
  const workspace = buildWorkspace(company);
  const financialIssues = validateFinancialInput(company.financial);
  const report = buildExecutiveReport(company, decision);
  return [
    {
      engine: 'Workspace Engine',
      status: statusFromPercent(workspace.completion),
      message: `اكتمال مساحة العمل ${workspace.completion}%.`
    },
    {
      engine: 'Financial Engine',
      status: financialIssues.some(issue => issue.status === 'critical') ? 'critical' : financialIssues.length ? 'warning' : 'good',
      message: financialIssues.length ? `${financialIssues.length} ملاحظة مالية تحتاج مراجعة.` : 'البيانات المالية صالحة للحساب.'
    },
    {
      engine: 'Rules Engine',
      status: decision.technicalScore >= 55 ? 'good' : decision.technicalScore >= 35 ? 'warning' : 'critical',
      message: `النقاط الفنية الحالية ${decision.technicalScore}%.`
    },
    {
      engine: 'Classification Engine',
      status: statusFromPercent(decision.confidence),
      message: `التصنيف ${decision.grade} مع ثقة ${decision.confidence}%.`
    },
    {
      engine: 'Recommendation Engine',
      status: decision.targetAchieved || decision.recommendationPlan.actions.length > 0 ? 'good' : 'warning',
      message: decision.targetAchieved ? 'لا توجد فجوة حرجة تجاه الدرجة المستهدفة.' : `${decision.recommendationPlan.actions.length} توصية مولدة.`
    },
    {
      engine: 'Executive Report Engine',
      status: report.sections.length >= 3 ? 'good' : 'warning',
      message: `${report.sections.length} أقسام تنفيذية جاهزة.`
    }
  ];
}

export function buildBetaReadiness(company: Company): BetaReadinessResult {
  const decision = buildDecision(company);
  const workflow = buildWorkflowStatus(company, decision);
  const engineHealth = buildEngineHealth(company, decision);
  const blockers = workflow.filter(step => step.status === 'critical').map(step => `${step.title}: ${step.message}`);
  const warnings = [
    ...workflow.filter(step => step.status === 'warning').map(step => `${step.title}: ${step.message}`),
    ...engineHealth.filter(item => item.status === 'warning').map(item => `${item.engine}: ${item.message}`)
  ];
  const workflowScore = Math.round(workflow.reduce((sum, step) => sum + (step.status === 'good' ? 100 : step.status === 'warning' ? 65 : 20), 0) / workflow.length);
  const engineScore = Math.round(engineHealth.reduce((sum, item) => sum + (item.status === 'good' ? 100 : item.status === 'warning' ? 65 : 20), 0) / engineHealth.length);
  const score = Math.round((workflowScore * 0.55) + (engineScore * 0.45));
  const status = blockers.length ? 'critical' : statusFromPercent(score);
  const nextAction = blockers[0] ?? warnings[0] ?? 'النسخة التجريبية جاهزة للتجربة الداخلية على ملف شركة حقيقي.';

  return {
    score,
    status,
    canIssueBetaReport: blockers.length === 0 && score >= 75,
    workflow,
    engineHealth,
    blockers,
    warnings,
    nextAction,
    decision
  };
}
