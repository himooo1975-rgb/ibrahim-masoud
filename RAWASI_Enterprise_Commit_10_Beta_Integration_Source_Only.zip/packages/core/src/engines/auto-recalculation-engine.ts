import type { Company, DecisionResult, FinancialInput } from '../types';
import { buildDecision } from './decision-engine';
import { mergeFinancialInput } from './financial-extraction-engine';

export type AutoRecalculationResult = {
  company: Company;
  decision: DecisionResult;
  changedFields: Array<keyof FinancialInput>;
  note: string;
};

export function applyExtractedFinancials(company: Company, extracted: Partial<FinancialInput>): AutoRecalculationResult {
  const nextFinancial = mergeFinancialInput(company.financial, extracted);
  const changedFields = (Object.keys(nextFinancial) as Array<keyof FinancialInput>).filter(key => nextFinancial[key] !== company.financial[key]);
  const nextCompany: Company = {
    ...company,
    financial: nextFinancial,
    timeline: [
      ...(company.timeline ?? []),
      {
        id: `financial-extract-${Date.now()}`,
        at: new Date().toISOString(),
        title: 'اعتماد أرقام قوائم مالية مستخرجة',
        description: `تم تحديث ${changedFields.length} بند مالي وإعادة احتساب التصنيف.`,
        type: 'financial'
      }
    ]
  };
  return {
    company: nextCompany,
    decision: buildDecision(nextCompany),
    changedFields,
    note: changedFields.length ? 'تمت إعادة الحساب بعد اعتماد الأرقام المستخرجة.' : 'لم تتغير أي قيم مالية بعد الاستخراج.'
  };
}
