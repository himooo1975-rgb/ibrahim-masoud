import type { Company, DecisionResult, RecommendationAction, TimelineEvent } from '../types';
import { gradeLabel } from './classification-engine';
import { buildExecutiveKpis, type ExecutiveKpi } from './kpi-engine';
import { buildWorkspace } from './workspace-engine';

export type ExecutiveReportSection = {
  title: string;
  body: string;
  bullets: string[];
};

export type ExecutiveReport = {
  reportId: string;
  generatedAt: string;
  companyName: string;
  classification: string;
  targetClassification: string;
  readiness: number;
  confidence: number;
  headline: string;
  executiveSummary: string;
  boardSummary: string;
  kpis: ExecutiveKpi[];
  strengths: string[];
  blockers: string[];
  priorityActions: RecommendationAction[];
  phases: Array<{ title: string; timeframe: string; expectedGain: number; actions: string[] }>;
  timeline: TimelineEvent[];
  sections: ExecutiveReportSection[];
};

function pickTop(items: Array<{ label?: string; title?: string; explanation?: string; recommendation?: string }>, limit: number) {
  return items.slice(0, limit).map(item => item.label ?? item.title ?? item.explanation ?? item.recommendation ?? 'بند غير محدد');
}

export function buildExecutiveReport(company: Company, decision: DecisionResult): ExecutiveReport {
  const workspace = buildWorkspace(company);
  const kpis = buildExecutiveKpis(company, decision);
  const priorityActions = decision.recommendationPlan.actions.slice(0, 5);
  const strengths = pickTop(decision.strengths, 5);
  const blockers = decision.missingRequirements.slice(0, 6).map(item => `${item.title}: ${item.recommendation}`);
  const gap = Math.max(0, decision.classification.targetThreshold - decision.totalScore);

  const headline = decision.targetAchieved
    ? `الشركة تحقق ${gradeLabel(decision.targetGrade)} مع جاهزية ${decision.readiness}%.`
    : `الشركة تحتاج ${gap} نقطة للوصول إلى ${gradeLabel(decision.targetGrade)}.`;

  const boardSummary = [
    `التصنيف المتوقع الحالي: ${gradeLabel(decision.grade)}.` ,
    `الدرجة المستهدفة: ${gradeLabel(decision.targetGrade)}.` ,
    `نسبة الثقة في القرار: ${decision.confidence}%.`,
    decision.targetAchieved ? 'التوصية: الاستعداد للتقديم مع الحفاظ على اكتمال الملف.' : `التوصية: تنفيذ أعلى ${priorityActions.length} إجراءات قبل التقديم.`
  ].join(' ');

  return {
    reportId: `RAWASI-RPT-${company.id}-${Date.now()}`,
    generatedAt: new Date().toISOString(),
    companyName: company.name,
    classification: gradeLabel(decision.grade),
    targetClassification: gradeLabel(decision.targetGrade),
    readiness: decision.readiness,
    confidence: decision.confidence,
    headline,
    executiveSummary: decision.executiveSummary,
    boardSummary,
    kpis,
    strengths,
    blockers,
    priorityActions,
    phases: decision.recommendationPlan.phases.map(phase => ({
      title: phase.title,
      timeframe: phase.timeframe,
      expectedGain: phase.expectedGain,
      actions: phase.actions.map(action => action.action)
    })),
    timeline: workspace.timeline.slice(0, 8),
    sections: [
      {
        title: 'ملخص الإدارة',
        body: boardSummary,
        bullets: [headline, decision.recommendationPlan.summary]
      },
      {
        title: 'أهم المخاطر',
        body: blockers.length ? 'توجد ملاحظات مؤثرة يجب إغلاقها قبل التقديم.' : 'لا توجد ملاحظات حرجة وفق البيانات الحالية.',
        bullets: blockers.length ? blockers : ['المحافظة على اكتمال ملف التقديم وتحديث البيانات قبل الإرسال.']
      },
      {
        title: 'خطة العمل التنفيذية',
        body: 'تم ترتيب الخطة حسب الأثر المتوقع والأولوية التنفيذية.',
        bullets: priorityActions.map(action => `${action.action} — أثر متوقع +${action.expectedImpact} نقطة خلال ${action.timeframe}.`)
      }
    ]
  };
}

export function exportReportAsText(report: ExecutiveReport) {
  const lines = [
    'منصة الرواسي - التقرير التنفيذي',
    `رقم التقرير: ${report.reportId}`,
    `الشركة: ${report.companyName}`,
    `التصنيف الحالي: ${report.classification}`,
    `التصنيف المستهدف: ${report.targetClassification}`,
    `الجاهزية: ${report.readiness}%`,
    `الثقة: ${report.confidence}%`,
    '',
    'الملخص التنفيذي:',
    report.boardSummary,
    '',
    'المؤشرات:',
    ...report.kpis.map(kpi => `- ${kpi.title}: ${kpi.value}${kpi.unit} — ${kpi.description}`),
    '',
    'الإجراءات ذات الأولوية:',
    ...report.priorityActions.map(action => `- ${action.action} (+${action.expectedImpact} نقطة / ${action.timeframe})`)
  ];
  return lines.join('\n');
}
