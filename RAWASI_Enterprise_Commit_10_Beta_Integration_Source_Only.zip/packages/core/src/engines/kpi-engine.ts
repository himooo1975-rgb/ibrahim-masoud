import type { Company, DecisionResult, ReadinessStatus } from '../types';
import { analyzeDocuments } from './document-engine';

export type ExecutiveKpi = {
  key: string;
  title: string;
  value: number;
  unit: '%' | 'نقطة' | 'عدد';
  status: ReadinessStatus;
  description: string;
};

function statusFromPercent(value: number): ReadinessStatus {
  if (value >= 80) return 'good';
  if (value >= 55) return 'warning';
  return 'critical';
}

function clamp(value: number) {
  return Math.max(0, Math.min(100, Math.round(value)));
}

export function buildExecutiveKpis(company: Company, decision: DecisionResult): ExecutiveKpi[] {
  const documents = analyzeDocuments(company.documents);
  const financialCompleteness = clamp(
    (Object.values(company.financial).filter(value => typeof value === 'number' && value > 0).length / Object.keys(company.financial).length) * 100
  );
  const technicalCompleteness = clamp(
    (Object.entries(company.technical).filter(([key, value]) => key === 'companySize' || (typeof value === 'number' && value >= 0)).length / Object.keys(company.technical).length) * 100
  );
  const blockersRisk = clamp(100 - decision.blockers.length * 18 - decision.missingRequirements.length * 5);
  const actionCoverage = decision.recommendationPlan.actions.length
    ? clamp((decision.recommendationPlan.quickWins.length / decision.recommendationPlan.actions.length) * 100)
    : 100;

  return [
    {
      key: 'classification-readiness',
      title: 'جاهزية التصنيف',
      value: decision.readiness,
      unit: '%',
      status: statusFromPercent(decision.readiness),
      description: 'مؤشر مركب يقيس قرب الشركة من الدرجة المستهدفة.'
    },
    {
      key: 'confidence',
      title: 'ثقة القرار',
      value: decision.confidence,
      unit: '%',
      status: statusFromPercent(decision.confidence),
      description: 'تقيس اكتمال البيانات والأدلة المستخدمة في قرار التصنيف.'
    },
    {
      key: 'documents',
      title: 'اكتمال المستندات',
      value: documents.score,
      unit: '%',
      status: statusFromPercent(documents.score),
      description: `${documents.completed} من ${documents.required} مستندات مطلوبة مكتملة.`
    },
    {
      key: 'financial-completeness',
      title: 'اكتمال البيانات المالية',
      value: financialCompleteness,
      unit: '%',
      status: statusFromPercent(financialCompleteness),
      description: 'يقيس عدد الحقول المالية القابلة للحساب داخل المركز المالي.'
    },
    {
      key: 'technical-completeness',
      title: 'اكتمال البيانات الفنية',
      value: technicalCompleteness,
      unit: '%',
      status: statusFromPercent(technicalCompleteness),
      description: 'يقيس جاهزية مدخلات الكوادر والخبرة والسعودة.'
    },
    {
      key: 'risk',
      title: 'مستوى المخاطر',
      value: blockersRisk,
      unit: '%',
      status: statusFromPercent(blockersRisk),
      description: 'كلما ارتفع المؤشر انخفضت المخاطر الحرجة قبل التقديم.'
    },
    {
      key: 'action-coverage',
      title: 'فرص التحسين السريع',
      value: actionCoverage,
      unit: '%',
      status: statusFromPercent(actionCoverage),
      description: 'نسبة التوصيات منخفضة الجهد إلى إجمالي خطة التحسين.'
    }
  ];
}
