# RAWASI Enterprise Data Layer

Commit 8 introduces the first enterprise-grade data layer.

## Why this matters

The early prototype stored one company object directly in browser storage. That was useful for experimentation, but it is not enough for a platform that will later support users, permissions, audit logs, reports, database persistence and API integration.

## New data model

The data is now represented as independent records:

- `CompanyRecord`
- `FinancialStatementRecord`
- `TechnicalProfileRecord`
- `DocumentRecord`
- `ClassificationRunRecord`
- `AuditEventRecord`
- `RawasiUser`

The UI still works with a friendly `Company` object, but the repository maps it internally to enterprise records.

## Repository layer

`RawasiRepository` provides a stable interface for:

- Saving companies
- Listing companies
- Loading a company workspace
- Exporting and importing snapshots
- Writing audit events

## Current persistence

For Commit 8, persistence remains browser-based through `localStorage`, but the stored shape is now a full enterprise snapshot:

`rawasi.enterprise.snapshot.v1`

This makes it easier to move to PostgreSQL/API later without rewriting the UI.

## Next step

Commit 9 should add a real API boundary and database-ready adapters.
