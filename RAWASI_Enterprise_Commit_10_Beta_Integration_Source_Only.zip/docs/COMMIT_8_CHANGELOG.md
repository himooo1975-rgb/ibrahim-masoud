# Commit 8 — Enterprise Data Layer

## Added

- Enterprise data model types.
- `RawasiRepository` as the first repository/service layer.
- `RawasiInMemoryDatabase` for local runtime operations.
- Snapshot import/export foundation.
- Migration path from the legacy single-company localStorage key.
- Audit event creation on company save.
- Documentation for the enterprise data layer.

## Changed

- Web storage service now saves an enterprise snapshot instead of only a single company object.
- The existing UI remains compatible while the internal data model becomes database-ready.

## Verified

- `npm run check`
- `npm run build`
