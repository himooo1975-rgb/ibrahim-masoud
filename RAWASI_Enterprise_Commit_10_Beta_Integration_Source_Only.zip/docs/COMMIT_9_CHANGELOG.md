# Commit 9 Changelog — OCR + Financial Extraction Core

## Added

- Financial Extraction Engine for Arabic financial statement text.
- Financial Mapping Engine.
- Financial Validation Engine.
- Auto Recalculation Engine.
- UI section: Financial Statements Extraction.
- Extraction coverage, confidence, source line display, and warnings.

## Notes

This commit implements the core extraction pipeline using pasted text. Full OCR/file parsing is planned for the next integration stage.
