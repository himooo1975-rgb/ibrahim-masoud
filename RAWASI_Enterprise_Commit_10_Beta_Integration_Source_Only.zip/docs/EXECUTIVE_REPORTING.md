# Executive Reporting

Commit 7 introduces the first executive reporting layer for RAWASI.

## Engines

- `buildExecutiveKpis(company, decision)` produces management KPIs.
- `buildExecutiveReport(company, decision)` produces a structured executive report.
- `exportReportAsText(report)` provides a simple export path until PDF/Word export is implemented.

## Report Contents

- Company name and report id.
- Current and target classification.
- Classification readiness.
- Decision confidence.
- Board summary.
- Risk blockers.
- Priority actions.
- Roadmap phases.
- Timeline snapshot.

## Purpose

The executive report is intended for management-level communication. It does not replace the detailed classification working file; it summarizes the decision, the gap, and the next actions.
