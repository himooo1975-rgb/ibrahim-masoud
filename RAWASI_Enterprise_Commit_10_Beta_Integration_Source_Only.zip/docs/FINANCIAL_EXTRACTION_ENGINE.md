# RAWASI Financial Extraction Engine

Commit 9 introduces the first structured layer for extracting financial statement values from copied text.

## Scope

This is not full OCR yet. It creates the core extraction pipeline:

1. Receive financial statement text.
2. Match Arabic financial labels and synonyms.
3. Extract numeric values.
4. Map values to RAWASI financial model.
5. Validate balance and required fields.
6. Apply extracted values and trigger recalculation.

## Engines

- `FinancialExtractionEngine`: reads text and extracts financial fields.
- `FinancialMappingEngine`: maps extracted fields to RAWASI internal keys.
- `FinancialValidationEngine`: checks required fields and balance equation.
- `AutoRecalculationEngine`: applies values to company data and recalculates decision output.

## Current supported fields

- Revenue
- Net Profit
- Assets
- Liabilities
- Equity
- Cash
- Current Assets
- Current Liabilities
- Operating Cash Flow

## Next step

Commit 10 should connect this pipeline to real file import/OCR and test it with actual financial statement samples.
