# RAWASI Platform - Real Development Sprint D

Sprint D يبني **Company Workspace** كملف شركة ذكي داخل منصة الرواسي.

## التشغيل

```bash
npm install
npm run dev
```

## الفحص

```bash
npm run check
npm run build
```

## الجديد
- Company Workspace متعدد المراكز.
- مراكز الملف:
  - بيانات الشركة والملكية ومجلس الإدارة.
  - المركز المالي.
  - المركز الفني.
  - مركز المستندات.
  - مركز التصنيف.
  - Activity Timeline.
- Workspace Engine لحساب جاهزية كل مركز.
- ترقية بيانات Sprint B تلقائيًا لدعم الملاك، أعضاء المجلس، الفروع، والمشاريع.
- استمرار منع تكرار السجل التجاري والحفظ المحلي والنسخ الاحتياطي.

## ملاحظة
هذه نسخة Source Only ولا تحتوي على `node_modules` أو `dist`.


## Sprint D - Financial Intelligence

أضاف هذا الإصدار محرك التحليل المالي، التقييم الائتماني المالي، شاشة الذكاء المالي، وفحص جودة القوائم.

## Sprint F — Classification Intelligence

أضيف في هذا الإصدار:

- محرك ذكاء التصنيف.
- تحليل الفجوات للدرجة المستهدفة.
- محاكي ماذا لو؟.
- أسرع طريق للتحسين.
- ثقة القرار واكتمال البيانات.

التشغيل:

```bash
npm install
npm run dev
```

الفحص:

```bash
npm run check
npm run build
```


## Sprint F — Executive Reports

هذا الإصدار يضيف مركز التقرير التنفيذي، ويحول نتائج محركات الرواسي إلى مخرجات قابلة للطباعة والتصدير.

### New Modules

- `src/engines/report/executiveReportEngine.ts`
- `src/features/reports/ExecutiveReports.tsx`
- `docs/EXECUTIVE_REPORTING.md`
- `docs/SPRINT_F_CHANGELOG.md`

### Verification

```bash
npm install
npm run check
npm run build
```
