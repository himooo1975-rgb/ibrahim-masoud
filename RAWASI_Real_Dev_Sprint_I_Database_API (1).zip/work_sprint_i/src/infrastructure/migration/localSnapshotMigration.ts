import type { Company, RawasiSnapshot } from '../../lib/types';

export interface MigrationTableCount {
  table: string;
  count: number;
}

export interface MigrationPreview {
  companyRows: number;
  tableCounts: MigrationTableCount[];
  warnings: string[];
}

function countDocuments(companies: Company[]) {
  return companies.reduce((total, company) => total + company.documents.length, 0);
}

function countProjects(companies: Company[]) {
  return companies.reduce((total, company) => total + company.projects.length, 0);
}

function countBranches(companies: Company[]) {
  return companies.reduce((total, company) => total + company.branches.length, 0);
}

function countOwners(companies: Company[]) {
  return companies.reduce((total, company) => total + company.owners.length, 0);
}

function countBoard(companies: Company[]) {
  return companies.reduce((total, company) => total + company.boardMembers.length, 0);
}

export function previewLocalSnapshotMigration(snapshot: RawasiSnapshot): MigrationPreview {
  const warnings: string[] = [];
  const duplicateRegisters = new Set<string>();
  const seenRegisters = new Set<string>();

  snapshot.companies.forEach((company) => {
    const register = company.commercialRegistration.trim();
    if (!register) warnings.push(`الشركة "${company.name}" لا تحتوي على سجل تجاري صالح.`);
    if (seenRegisters.has(register)) duplicateRegisters.add(register);
    seenRegisters.add(register);
  });

  duplicateRegisters.forEach((register) => warnings.push(`يوجد تكرار في السجل التجاري: ${register}.`));

  return {
    companyRows: snapshot.companies.length,
    tableCounts: [
      { table: 'Company', count: snapshot.companies.length },
      { table: 'CompanyBranch', count: countBranches(snapshot.companies) },
      { table: 'CompanyOwner', count: countOwners(snapshot.companies) },
      { table: 'BoardMember', count: countBoard(snapshot.companies) },
      { table: 'Project', count: countProjects(snapshot.companies) },
      { table: 'FinancialStatement', count: snapshot.companies.length },
      { table: 'TechnicalProfile', count: snapshot.companies.length },
      { table: 'Document', count: countDocuments(snapshot.companies) },
      { table: 'User', count: snapshot.users.length },
      { table: 'AuditLog', count: snapshot.auditLog.length },
    ],
    warnings,
  };
}
