import type { Company, RawasiSnapshot, RawasiUser } from '../../lib/types';

export interface EnterpriseRepository {
  load(): RawasiSnapshot | Promise<RawasiSnapshot>;
  saveCompany(company: Company): RawasiSnapshot | Promise<RawasiSnapshot>;
  deleteCompany(companyId: string): RawasiSnapshot | Promise<RawasiSnapshot>;
  saveUsers(users: RawasiUser[], currentUserId?: string): RawasiSnapshot | Promise<RawasiSnapshot>;
  exportBackup(): string | Promise<string>;
  importBackup(json: string): RawasiSnapshot | Promise<RawasiSnapshot>;
}

export type RepositoryMode = 'local' | 'api-ready';
