import type { RawasiSnapshot } from '../../lib/types';

export interface DatabaseReadinessItem {
  key: string;
  title: string;
  status: 'جاهز' | 'يتطلب إعداد' | 'اختياري';
  detail: string;
}

export function evaluateDatabaseReadiness(snapshot: RawasiSnapshot): DatabaseReadinessItem[] {
  return [
    {
      key: 'schema',
      title: 'Prisma Schema',
      status: 'جاهز',
      detail: 'تم تجهيز schema.prisma بجداول الشركات، المستخدمين، القوائم، التصنيف، التوصيات، وسجل التدقيق.',
    },
    {
      key: 'companies',
      title: 'بيانات الشركات',
      status: snapshot.companies.length > 0 ? 'جاهز' : 'يتطلب إعداد',
      detail: `${snapshot.companies.length} شركة جاهزة للترحيل من Snapshot المحلي إلى قاعدة البيانات.`,
    },
    {
      key: 'users',
      title: 'المستخدمون والصلاحيات',
      status: snapshot.users.length > 0 ? 'جاهز' : 'يتطلب إعداد',
      detail: `${snapshot.users.length} مستخدم/دور موجود في Snapshot الحالي.`,
    },
    {
      key: 'api',
      title: 'API Contracts',
      status: 'جاهز',
      detail: 'تم تعريف واجهات الشركات والمستخدمين والنسخ الاحتياطية تمهيدًا لربط Backend فعلي.',
    },
    {
      key: 'migration',
      title: 'Migration Plan',
      status: 'جاهز',
      detail: 'تم تجهيز مخطط تحويل Snapshot إلى كيانات قاعدة البيانات دون فقدان بيانات.',
    },
    {
      key: 'database-url',
      title: 'DATABASE_URL',
      status: 'يتطلب إعداد',
      detail: 'يجب ضبط DATABASE_URL عند تشغيل PostgreSQL في بيئة الإنتاج أو التطوير.',
    },
  ];
}
