import type { Company, RawasiSnapshot, RawasiUser } from '../../lib/types';
import type { ApiResult, CompanyApi, SecurityApi, SnapshotApi } from './apiTypes';

async function request<T>(path: string, init?: RequestInit): Promise<ApiResult<T>> {
  try {
    const response = await fetch(path, {
      headers: { 'Content-Type': 'application/json', ...(init?.headers ?? {}) },
      ...init,
    });
    const payload = (await response.json().catch(() => null)) as T | { error?: string } | null;
    if (!response.ok) {
      return { ok: false, error: (payload as { error?: string } | null)?.error ?? `HTTP ${response.status}` };
    }
    return { ok: true, data: payload as T };
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : 'تعذر الاتصال بواجهة API.' };
  }
}

export class RawasiApiClient implements CompanyApi, SecurityApi, SnapshotApi {
  constructor(private readonly baseUrl = '/api') {}

  listCompanies() {
    return request<Company[]>(`${this.baseUrl}/companies`);
  }

  getCompany(companyId: string) {
    return request<Company>(`${this.baseUrl}/companies/${companyId}`);
  }

  saveCompany(company: Company) {
    return request<Company>(`${this.baseUrl}/companies/${company.id}`, {
      method: 'PUT',
      body: JSON.stringify(company),
    });
  }

  deleteCompany(companyId: string) {
    return request<{ id: string }>(`${this.baseUrl}/companies/${companyId}`, { method: 'DELETE' });
  }

  listUsers() {
    return request<RawasiUser[]>(`${this.baseUrl}/users`);
  }

  saveUsers(users: RawasiUser[]) {
    return request<RawasiUser[]>(`${this.baseUrl}/users`, {
      method: 'PUT',
      body: JSON.stringify({ users }),
    });
  }

  exportSnapshot() {
    return request<RawasiSnapshot>(`${this.baseUrl}/snapshot`);
  }

  importSnapshot(snapshot: RawasiSnapshot) {
    return request<RawasiSnapshot>(`${this.baseUrl}/snapshot`, {
      method: 'POST',
      body: JSON.stringify(snapshot),
    });
  }
}
