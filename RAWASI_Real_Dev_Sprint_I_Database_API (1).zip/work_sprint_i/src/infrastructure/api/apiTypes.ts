import type { Company, RawasiSnapshot, RawasiUser } from '../../lib/types';

export interface ApiResult<T> {
  ok: boolean;
  data?: T;
  error?: string;
}

export interface CompanyApi {
  listCompanies(): Promise<ApiResult<Company[]>>;
  getCompany(companyId: string): Promise<ApiResult<Company>>;
  saveCompany(company: Company): Promise<ApiResult<Company>>;
  deleteCompany(companyId: string): Promise<ApiResult<{ id: string }>>;
}

export interface SecurityApi {
  listUsers(): Promise<ApiResult<RawasiUser[]>>;
  saveUsers(users: RawasiUser[]): Promise<ApiResult<RawasiUser[]>>;
}

export interface SnapshotApi {
  exportSnapshot(): Promise<ApiResult<RawasiSnapshot>>;
  importSnapshot(snapshot: RawasiSnapshot): Promise<ApiResult<RawasiSnapshot>>;
}
