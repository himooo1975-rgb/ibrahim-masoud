import { Database, Server, ShieldCheck, UploadCloud } from 'lucide-react';
import { Card } from '../../components/Card';
import { evaluateDatabaseReadiness } from '../../infrastructure/repositories/databaseReadiness';
import { previewLocalSnapshotMigration } from '../../infrastructure/migration/localSnapshotMigration';
import type { RawasiSnapshot } from '../../lib/types';

interface EnterpriseDatabaseProps {
  snapshot: RawasiSnapshot;
}

const statusClass = {
  'جاهز': 'bg-emerald-50 text-emerald-700 border-emerald-200',
  'يتطلب إعداد': 'bg-amber-50 text-amber-700 border-amber-200',
  'اختياري': 'bg-slate-50 text-slate-700 border-slate-200',
};

export function EnterpriseDatabase({ snapshot }: EnterpriseDatabaseProps) {
  const readiness = evaluateDatabaseReadiness(snapshot);
  const migration = previewLocalSnapshotMigration(snapshot);
  const readyCount = readiness.filter((item) => item.status === 'جاهز').length;
  const readinessPercent = Math.round((readyCount / readiness.length) * 100);

  return (
    <section className="grid gap-5">
      <div className="grid gap-4 lg:grid-cols-4">
        <Card title="جاهزية قاعدة البيانات">
          <div className="text-4xl font-black text-rawasi-navy">{readinessPercent}%</div>
          <p className="mt-2 text-sm leading-7 text-slate-600">Sprint I يجهز الانتقال من التخزين المحلي إلى PostgreSQL + Prisma + API.</p>
        </Card>
        <Card title="الشركات الجاهزة للترحيل">
          <div className="text-4xl font-black text-rawasi-green">{migration.companyRows}</div>
          <p className="mt-2 text-sm text-slate-600">من Snapshot الحالي.</p>
        </Card>
        <Card title="المستخدمون">
          <div className="text-4xl font-black text-rawasi-blue">{snapshot.users.length}</div>
          <p className="mt-2 text-sm text-slate-600">جاهزون للتحويل إلى جدول Users.</p>
        </Card>
        <Card title="سجل التدقيق">
          <div className="text-4xl font-black text-amber-700">{snapshot.auditLog.length}</div>
          <p className="mt-2 text-sm text-slate-600">عملية محفوظة قبل الترحيل.</p>
        </Card>
      </div>

      <div className="grid gap-5 lg:grid-cols-[1.1fr_0.9fr]">
        <Card title="Enterprise Database Readiness">
          <div className="space-y-3">
            {readiness.map((item) => (
              <div key={item.key} className="rounded-2xl border border-slate-200 bg-white p-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <h3 className="font-black text-slate-900">{item.title}</h3>
                  <span className={`rounded-full border px-3 py-1 text-xs font-black ${statusClass[item.status]}`}>{item.status}</span>
                </div>
                <p className="mt-2 text-sm leading-7 text-slate-600">{item.detail}</p>
              </div>
            ))}
          </div>
        </Card>

        <Card title="Migration Preview">
          <div className="space-y-2">
            {migration.tableCounts.map((row) => (
              <div key={row.table} className="flex items-center justify-between rounded-xl bg-slate-50 px-4 py-3 text-sm">
                <span className="font-bold text-slate-700">{row.table}</span>
                <span className="font-black text-rawasi-navy">{row.count}</span>
              </div>
            ))}
          </div>
          {migration.warnings.length > 0 ? (
            <div className="mt-4 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm leading-7 text-amber-800">
              <h4 className="font-black">تنبيهات قبل الترحيل</h4>
              <ul className="mt-2 list-inside list-disc">
                {migration.warnings.map((warning) => <li key={warning}>{warning}</li>)}
              </ul>
            </div>
          ) : (
            <div className="mt-4 rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-sm font-bold text-emerald-800">لا توجد تعارضات ظاهرة في Snapshot الحالي.</div>
          )}
        </Card>
      </div>

      <Card title="خطة الربط المؤسسي">
        <div className="grid gap-4 lg:grid-cols-4">
          <div className="rounded-2xl bg-slate-50 p-4">
            <Database className="text-rawasi-green" />
            <h3 className="mt-3 font-black">PostgreSQL</h3>
            <p className="mt-2 text-sm leading-7 text-slate-600">قاعدة بيانات مركزية للشركات والقوائم والمستندات والتصنيف.</p>
          </div>
          <div className="rounded-2xl bg-slate-50 p-4">
            <Server className="text-rawasi-green" />
            <h3 className="mt-3 font-black">API Layer</h3>
            <p className="mt-2 text-sm leading-7 text-slate-600">واجهات REST جاهزة للفصل بين الواجهة وطبقة البيانات.</p>
          </div>
          <div className="rounded-2xl bg-slate-50 p-4">
            <UploadCloud className="text-rawasi-green" />
            <h3 className="mt-3 font-black">Migration Tool</h3>
            <p className="mt-2 text-sm leading-7 text-slate-600">نقل Snapshot المحلي إلى الجداول دون فقدان البيانات.</p>
          </div>
          <div className="rounded-2xl bg-slate-50 p-4">
            <ShieldCheck className="text-rawasi-green" />
            <h3 className="mt-3 font-black">Audit Ready</h3>
            <p className="mt-2 text-sm leading-7 text-slate-600">تتبع العمليات بعد نقل النظام إلى بيئة متعددة المستخدمين.</p>
          </div>
        </div>
      </Card>

      <Card title="أوامر قاعدة البيانات المقترحة">
        <pre className="overflow-auto rounded-2xl bg-slate-950 p-5 text-left text-sm leading-7 text-emerald-100" dir="ltr">{`DATABASE_URL="postgresql://rawasi:password@localhost:5432/rawasi"
npm run db:generate
npm run db:migrate
npm run dev`}</pre>
      </Card>
    </section>
  );
}
