# Sprint I Changelog — Enterprise Database & API Foundation

## Added
- Prisma schema for PostgreSQL.
- API contracts and `RawasiApiClient`.
- Enterprise repository contracts.
- Database readiness evaluator.
- Local snapshot migration preview.
- Database Center page in the UI.
- Database scripts in `package.json`.

## Changed
- Header and navigation updated to Sprint I.
- App now includes Database Center beside Security and Audit.

## Validation
- `npm run check`
- `npm run build`
