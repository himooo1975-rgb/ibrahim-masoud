# RAWASI Sprint I — Enterprise Database & API Foundation

هذا Sprint يجهز منصة الرواسي للانتقال من التخزين المحلي إلى قاعدة بيانات مؤسسية.

## ما تمت إضافته

- `prisma/schema.prisma` كنموذج قاعدة بيانات PostgreSQL.
- نماذج للشركات، الملاك، مجلس الإدارة، الفروع، المشاريع، القوائم المالية، المؤشرات، البيانات الفنية، المستندات، نتائج التصنيف، التوصيات، المستخدمين، وسجل التدقيق.
- `RawasiApiClient` كواجهة تمهيدية للتعامل مع REST API.
- عقود Repository للفصل بين الواجهة وطبقة البيانات.
- Migration Preview لفحص Snapshot المحلي قبل نقله إلى قاعدة البيانات.
- صفحة "قاعدة البيانات" داخل الواجهة لمتابعة جاهزية الانتقال المؤسسي.

## أوامر مقترحة عند توفر PostgreSQL

```bash
DATABASE_URL="postgresql://rawasi:password@localhost:5432/rawasi"
npm run db:generate
npm run db:migrate
npm run dev
```

## ملاحظات مهمة

- ما زال التطبيق يعمل محليًا عبر `RawasiRepository` حتى لا ينكسر التشغيل.
- طبقة API جاهزة كعقود وعميل، وسيتم ربطها فعليًا عند بناء Backend.
- هذا Sprint لا يزيل Local Storage بعد؛ بل يجهز الانتقال الآمن إلى قاعدة البيانات.
