import type { ScoredFactor, TechnicalInput } from '../types';
import type { RuleExecutionResult } from '../rules/types';
import { constructionTechnicalRules } from '../rules/technical-construction-rules';
import { executeNumericRuleSet, listRuleMetadata } from './rules-engine';

function toFactor(result: RuleExecutionResult): ScoredFactor {
  const unit = result.unit === '%' ? '%' : result.unit === 'year' ? ' سنة' : '';
  return {
    key: result.ruleId,
    label: result.title,
    score: result.score,
    maxScore: result.maxScore,
    status: result.status,
    valueLabel: result.value === null ? 'غير مكتمل' : `${result.value}${unit}`,
    explanation: result.explanation,
    recommendation: result.recommendation,
    expectedImpact: result.expectedImpact,
    ruleId: result.ruleId,
    ruleVersion: result.ruleVersion,
    reference: result.reference,
    sourcePage: result.sourcePage
  };
}

export function analyzeTechnical(input: TechnicalInput) {
  const evaluation = executeNumericRuleSet(constructionTechnicalRules, input, input.companySize);
  const factors = evaluation.results.map(toFactor);

  return {
    score: evaluation.normalizedScore,
    rawScore: Number(evaluation.rawScore.toFixed(3)),
    maxScore: evaluation.maxScore,
    factors,
    ruleSet: {
      id: 'TECHNICAL_CONSTRUCTION_2025_11',
      version: '2025.11',
      source: 'الدليل الاسترشادي لتصنيف المقاولين والشركات والمكاتب الاستشارية الهندسية - نوفمبر 2025',
      rulesCount: constructionTechnicalRules.length
    }
  };
}

export function getTechnicalRulesCatalog() {
  return listRuleMetadata(constructionTechnicalRules);
}
