import type { Company, DecisionResult, ScoredFactor } from '../types';
import { analyzeDocuments } from './document-engine';
import { analyzeFinancial } from './financial-engine';
import { analyzeTechnical } from './technical-engine';
import { evaluateClassification } from './classification-engine';
import { buildRecommendationPlan } from './recommendation-engine';

function byImpact(a: ScoredFactor, b: ScoredFactor) {
  return (b.expectedImpact ?? 0) - (a.expectedImpact ?? 0);
}

export function buildDecision(company: Company): DecisionResult {
  const financial = analyzeFinancial(company.financial);
  const technical = analyzeTechnical(company.technical);
  const documents = analyzeDocuments(company.documents);
  const classification = evaluateClassification(company);
  const recommendationPlan = buildRecommendationPlan(company);

  const allFactors = [...financial.factors, ...technical.factors, ...documents.missingFactors];
  const blockers = allFactors.filter(item => item.status === 'critical').sort(byImpact);
  const recommendations = allFactors.filter(item => item.recommendation).sort(byImpact).slice(0, 8);
  const strengths = allFactors.filter(item => item.status === 'good').slice(0, 6);

  const executiveSummary = classification.targetAchieved
    ? `الشركة تحقق الدرجة المستهدفة ${company.targetGrade} وفق Classification Engine V1، مع نسبة ثقة ${classification.confidence}% ويجب الحفاظ على اكتمال ملف التقديم.`
    : `الشركة لا تحقق الدرجة المستهدفة ${company.targetGrade} حاليًا. الفجوة الحالية ${Math.max(0, classification.targetThreshold - classification.totalScore)} نقطة، وأعلى أولوية هي ${classification.missingRequirements[0]?.title ?? recommendations[0]?.label ?? 'استكمال البيانات الحرجة'}.`;

  return {
    financialScore: financial.score,
    technicalScore: technical.score,
    documentScore: documents.score,
    totalScore: classification.totalScore,
    grade: classification.grade,
    targetGrade: company.targetGrade,
    targetAchieved: classification.targetAchieved,
    readiness: classification.readiness,
    confidence: classification.confidence,
    classification,
    blockers,
    strengths,
    recommendations,
    missingRequirements: classification.missingRequirements,
    executiveSummary,
    recommendationPlan
  };
}
