import type { ClassificationComponent, ClassificationGrade, ClassificationResult, Company, MissingRequirement, ReadinessStatus } from '../types';
import { analyzeDocuments } from './document-engine';
import { analyzeFinancial } from './financial-engine';
import { analyzeTechnical } from './technical-engine';

export function gradeFromScore(score: number): ClassificationGrade {
  if (score >= 85) return 1;
  if (score >= 70) return 2;
  if (score >= 55) return 3;
  if (score >= 40) return 4;
  return 5;
}

export function gradeLabel(grade: ClassificationGrade): string {
  return `الدرجة ${grade}`;
}

export function targetScoreThreshold(grade: ClassificationGrade): number {
  const thresholds: Record<ClassificationGrade, number> = { 1: 85, 2: 70, 3: 55, 4: 40, 5: 20 };
  return thresholds[grade];
}

function statusFromScore(score: number): ReadinessStatus {
  if (score >= 80) return 'good';
  if (score >= 55) return 'warning';
  return 'critical';
}

function weighted(score: number, weight: number) {
  return Math.round(score * weight);
}

function buildMissingRequirements(company: Company): MissingRequirement[] {
  const financial = analyzeFinancial(company.financial);
  const technical = analyzeTechnical(company.technical);
  const documents = analyzeDocuments(company.documents);
  const requirements: MissingRequirement[] = [];

  for (const factor of financial.factors) {
    if (factor.status !== 'good' && factor.recommendation) {
      requirements.push({
        id: `financial-${factor.key}`,
        domain: 'financial',
        title: factor.label,
        current: factor.valueLabel,
        required: factor.status === 'critical' ? 'تحسين جوهري قبل طلب درجة أعلى' : 'تحسين داعم للدرجة المستهدفة',
        severity: factor.status,
        impact: factor.expectedImpact ?? 0,
        recommendation: factor.recommendation
      });
    }
  }

  for (const factor of technical.factors) {
    if (factor.status !== 'good' && factor.recommendation) {
      requirements.push({
        id: `technical-${factor.key}`,
        domain: 'technical',
        title: factor.label,
        current: factor.valueLabel,
        required: factor.reference ?? 'وفق جدول القاعدة الفنية',
        severity: factor.status,
        impact: factor.expectedImpact ?? 0,
        recommendation: factor.recommendation
      });
    }
  }

  for (const factor of documents.missingFactors) {
    requirements.push({
      id: `document-${factor.key}`,
      domain: 'documents',
      title: factor.label,
      current: 'غير مكتمل',
      required: 'مستند مطلوب ضمن ملف التقديم',
      severity: 'critical',
      impact: factor.expectedImpact ?? 0,
      recommendation: factor.recommendation ?? `استكمال ${factor.label}`
    });
  }

  return requirements.sort((a, b) => b.impact - a.impact);
}

function calculateConfidence(company: Company, components: ClassificationComponent[], missing: MissingRequirement[]) {
  const companyCompleteness = company.name && company.crNumber ? 15 : 5;
  const financialCompleteness = Object.values(company.financial).filter(value => typeof value === 'number' && value > 0).length / Object.keys(company.financial).length;
  const technicalCompleteness = Object.entries(company.technical).filter(([key, value]) => key === 'companySize' || (typeof value === 'number' && value >= 0)).length / Object.keys(company.technical).length;
  const documentCompleteness = components.find(component => component.key === 'documents')?.score ?? 0;
  const criticalPenalty = Math.min(18, missing.filter(item => item.severity === 'critical').length * 3);
  const confidence = companyCompleteness + Math.round(financialCompleteness * 35) + Math.round(technicalCompleteness * 25) + Math.round(documentCompleteness * 0.25) - criticalPenalty;
  return Math.max(0, Math.min(100, confidence));
}

export function evaluateClassification(company: Company): ClassificationResult {
  const financial = analyzeFinancial(company.financial);
  const technical = analyzeTechnical(company.technical);
  const documents = analyzeDocuments(company.documents);

  const components: ClassificationComponent[] = [
    {
      key: 'financial',
      title: 'المكون المالي',
      score: financial.score,
      weight: 0.45,
      weightedScore: weighted(financial.score, 0.45),
      status: statusFromScore(financial.score),
      evidenceCount: financial.factors.length
    },
    {
      key: 'technical',
      title: 'المكون الفني',
      score: technical.score,
      weight: 0.4,
      weightedScore: weighted(technical.score, 0.4),
      status: statusFromScore(technical.score),
      evidenceCount: technical.factors.length
    },
    {
      key: 'documents',
      title: 'المستندات والجاهزية',
      score: documents.score,
      weight: 0.15,
      weightedScore: weighted(documents.score, 0.15),
      status: statusFromScore(documents.score),
      evidenceCount: documents.required
    }
  ];

  const totalScore = Math.round(components.reduce((sum, component) => sum + component.weightedScore, 0));
  const grade = gradeFromScore(totalScore);
  const targetThreshold = targetScoreThreshold(company.targetGrade);
  const readiness = Math.min(100, Math.round((totalScore / targetThreshold) * 100));
  const missingRequirements = buildMissingRequirements(company);
  const confidence = calculateConfidence(company, components, missingRequirements);
  const targetAchieved = grade <= company.targetGrade;

  return {
    totalScore,
    grade,
    targetGrade: company.targetGrade,
    targetThreshold,
    targetAchieved,
    readiness,
    confidence,
    components,
    missingRequirements,
    history: [
      {
        at: new Date().toISOString(),
        score: totalScore,
        grade,
        confidence,
        note: 'تقييم آلي من Classification Engine V1 بناءً على المكونات المتاحة.'
      }
    ]
  };
}
