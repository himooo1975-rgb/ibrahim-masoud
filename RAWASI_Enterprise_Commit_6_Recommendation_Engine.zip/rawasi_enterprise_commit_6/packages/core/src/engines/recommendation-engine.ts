import type { ClassificationResult, Company, MissingRequirement, RecommendationAction, RecommendationEffort, RecommendationPhase, RecommendationPlan, RecommendationPriority } from '../types';
import { evaluateClassification, gradeLabel } from './classification-engine';

function priorityFrom(requirement: MissingRequirement, gap: number): RecommendationPriority {
  if (requirement.severity === 'critical' || requirement.impact >= Math.max(4, gap * 0.25)) return 'urgent';
  if (requirement.impact >= 3) return 'high';
  if (requirement.impact >= 1.5) return 'medium';
  return 'low';
}

function effortFrom(requirement: MissingRequirement): RecommendationEffort {
  if (requirement.domain === 'documents') return 'low';
  if (requirement.domain === 'financial') return requirement.impact >= 5 ? 'high' : 'medium';
  if (requirement.domain === 'technical') return requirement.impact >= 4 ? 'medium' : 'low';
  return 'medium';
}

function timeframeFrom(priority: RecommendationPriority, effort: RecommendationEffort): string {
  if (priority === 'urgent' && effort === 'low') return 'خلال 3 أيام';
  if (priority === 'urgent') return 'خلال أسبوعين';
  if (priority === 'high' && effort === 'low') return 'خلال أسبوع';
  if (priority === 'high') return 'خلال شهر';
  if (priority === 'medium') return 'خلال 30-45 يومًا';
  return 'تحسين مستمر';
}

function confidenceFrom(requirement: MissingRequirement, classification: ClassificationResult): number {
  const base = classification.confidence;
  const severityBonus = requirement.severity === 'critical' ? 8 : requirement.severity === 'warning' ? 4 : 0;
  const impactBonus = Math.min(10, Math.round(requirement.impact));
  return Math.max(45, Math.min(98, base + severityBonus + impactBonus - 5));
}

function gradeFromSimulatedScore(score: number): Company['targetGrade'] {
  if (score >= 85) return 1;
  if (score >= 70) return 2;
  if (score >= 55) return 3;
  if (score >= 40) return 4;
  return 5;
}

function buildAction(requirement: MissingRequirement, classification: ClassificationResult): RecommendationAction {
  const gap = Math.max(0, classification.targetThreshold - classification.totalScore);
  const expectedImpact = Math.max(1, Math.round(requirement.impact * 10) / 10);
  const priority = priorityFrom(requirement, gap);
  const effort = effortFrom(requirement);
  const simulatedScore = Math.min(100, Math.round((classification.totalScore + expectedImpact) * 10) / 10);
  return {
    id: `rec-${requirement.id}`,
    domain: requirement.domain,
    title: requirement.title,
    reason: `الحالة الحالية: ${requirement.current}. المطلوب: ${requirement.required}.`,
    action: requirement.recommendation,
    expectedImpact,
    effort,
    priority,
    timeframe: timeframeFrom(priority, effort),
    confidence: confidenceFrom(requirement, classification),
    simulatedScore,
    simulatedGrade: gradeFromSimulatedScore(simulatedScore),
    targetContribution: gap > 0 ? Math.min(100, Math.round((expectedImpact / gap) * 100)) : 100
  };
}

function sortActions(a: RecommendationAction, b: RecommendationAction) {
  const priorityWeight: Record<RecommendationPriority, number> = { urgent: 4, high: 3, medium: 2, low: 1 };
  const effortWeight: Record<RecommendationEffort, number> = { low: 3, medium: 2, high: 1 };
  const aScore = priorityWeight[a.priority] * 100 + a.expectedImpact * 10 + effortWeight[a.effort];
  const bScore = priorityWeight[b.priority] * 100 + b.expectedImpact * 10 + effortWeight[b.effort];
  return bScore - aScore;
}

function sumImpact(actions: RecommendationAction[]) {
  return Math.round(actions.reduce((sum, action) => sum + action.expectedImpact, 0) * 10) / 10;
}

function groupIntoPhases(actions: RecommendationAction[]): RecommendationPhase[] {
  const immediate = actions.filter(action => action.priority === 'urgent' || (action.priority === 'high' && action.effort === 'low'));
  const shortTerm = actions.filter(action => !immediate.includes(action) && (action.priority === 'high' || action.priority === 'medium'));
  const strategic = actions.filter(action => !immediate.includes(action) && !shortTerm.includes(action));
  const phases: RecommendationPhase[] = [];
  if (immediate.length) phases.push({ title: 'المرحلة الأولى: إغلاق العوائق السريعة', timeframe: '0 - 14 يومًا', actions: immediate, expectedGain: sumImpact(immediate) });
  if (shortTerm.length) phases.push({ title: 'المرحلة الثانية: رفع نقاط التصنيف', timeframe: '15 - 45 يومًا', actions: shortTerm, expectedGain: sumImpact(shortTerm) });
  if (strategic.length) phases.push({ title: 'المرحلة الثالثة: تحسينات استراتيجية', timeframe: '45 - 90 يومًا', actions: strategic, expectedGain: sumImpact(strategic) });
  return phases;
}

function buildAlerts(company: Company, classification: ClassificationResult, actions: RecommendationAction[]): string[] {
  const alerts: string[] = [];
  const currentYear = new Date().getFullYear();
  if (!company.financialYear || company.financialYear < currentYear - 1) alerts.push('القوائم المالية قديمة أو غير محددة؛ يفضل تحديث السنة المالية قبل التقديم.');
  const missingDocs = company.documents.filter(doc => doc.required && !doc.present).length;
  if (missingDocs) alerts.push(`يوجد ${missingDocs} مستند مطلوب غير مكتمل ضمن ملف التصنيف.`);
  if (classification.confidence < 70) alerts.push('نسبة الثقة منخفضة بسبب نقص بيانات أو أدلة؛ أكمل البيانات قبل الاعتماد النهائي.');
  if (actions.some(action => action.priority === 'urgent')) alerts.push('توجد توصيات عاجلة يجب تنفيذها قبل إرسال ملف التصنيف.');
  return alerts;
}

export function buildRecommendationPlan(company: Company): RecommendationPlan {
  const classification = evaluateClassification(company);
  const gap = Math.max(0, classification.targetThreshold - classification.totalScore);
  const actions = classification.missingRequirements.map(req => buildAction(req, classification)).sort(sortActions);
  const phases = groupIntoPhases(actions);
  const quickWins = actions.filter(action => action.effort === 'low').slice(0, 4);
  const strategicActions = actions.filter(action => action.effort === 'high' || action.expectedImpact >= 5).slice(0, 4);
  const alerts = buildAlerts(company, classification, actions);
  const accumulatedImpact = sumImpact(actions.slice(0, 5));
  const summary = classification.targetAchieved
    ? `الشركة تحقق ${gradeLabel(company.targetGrade)} حاليًا. يوصى بالحفاظ على الجاهزية وإغلاق أي ملاحظات قبل التقديم.`
    : `الفجوة إلى ${gradeLabel(company.targetGrade)} تبلغ ${gap} نقطة. تنفيذ أول ${Math.min(5, actions.length)} توصيات قد يضيف حتى ${accumulatedImpact} نقطة تقريبًا.`;

  return {
    currentScore: classification.totalScore,
    targetScore: classification.targetThreshold,
    gap,
    currentGrade: classification.grade,
    targetGrade: company.targetGrade,
    targetAchieved: classification.targetAchieved,
    actions,
    phases,
    quickWins,
    strategicActions,
    alerts,
    summary
  };
}

// Legacy helper retained for compatibility with older prototype calls.
export function buildRecommendations(metrics: { liquidity: number; leverage: number; profitability: number }) {
  const recommendations: string[] = [];
  if (metrics.liquidity < 0.8) recommendations.push('تحسين السيولة ورفع النقد المتاح مقارنة بالالتزامات.');
  if (metrics.leverage > 0.45) recommendations.push('خفض المديونية أو زيادة حقوق الملكية.');
  if (metrics.profitability < 0.08) recommendations.push('تحسين هامش الربحية قبل التقديم.');
  return recommendations.length ? recommendations : ['الوضع المالي جيد، ركز على اكتمال المستندات والجاهزية الفنية.'];
}
