import type { CompanySize, ReadinessStatus } from '../types';
import type { NumericRuleBand, NumericThresholdRule, RuleExecutionResult } from '../rules/types';

function normalizeBands(bands: NumericRuleBand[]) {
  return [...bands].sort((a, b) => b.minInclusive - a.minInclusive);
}

function scoreStatus(score: number, maxScore: number): ReadinessStatus {
  const ratio = maxScore > 0 ? score / maxScore : 0;
  if (ratio >= 0.85) return 'good';
  if (ratio >= 0.55) return 'warning';
  return 'critical';
}

function formatUnit(unit: string) {
  if (unit === '%') return '%';
  if (unit === 'year') return ' سنة';
  return '';
}

function buildRecommendation(template: string, nextBand: NumericRuleBand | undefined, unit: string) {
  if (!nextBand) return undefined;
  return template
    .replace('{nextMin}', String(nextBand.minInclusive))
    .replace('{unit}', formatUnit(unit));
}

function findCurrentBand(value: number, bands: NumericRuleBand[]) {
  return normalizeBands(bands).find(band => value >= band.minInclusive);
}

function findNextBand(value: number, bands: NumericRuleBand[]) {
  return [...bands]
    .sort((a, b) => a.minInclusive - b.minInclusive)
    .find(band => value < band.minInclusive);
}

export function executeNumericThresholdRule<TInput extends object>(
  rule: NumericThresholdRule<TInput>,
  input: TInput,
  companySize: CompanySize
): RuleExecutionResult {
  const rawValue = input[rule.inputKey];
  const value = typeof rawValue === 'number' && Number.isFinite(rawValue) ? rawValue : null;
  const bands = rule.tables[companySize] ?? [];
  const reference = `${rule.source.title}${rule.source.table ? `، ${rule.source.table}` : ''}، صفحة ${rule.source.page}`;

  if (value === null) {
    return {
      ruleId: rule.id,
      ruleVersion: rule.version,
      title: rule.title,
      score: 0,
      maxScore: rule.maxScore,
      value,
      unit: rule.unit,
      status: 'critical',
      explanation: `لا يمكن تقييم معيار ${rule.title} لأن القيمة المطلوبة غير متاحة أو غير رقمية.`,
      recommendation: 'استكمال البيانات المطلوبة لهذا المعيار قبل الاعتماد على نتيجة التصنيف.',
      expectedImpact: rule.maxScore,
      reference,
      sourcePage: rule.source.page,
      valid: false
    };
  }

  const currentBand = findCurrentBand(value, bands);
  const nextBand = findNextBand(value, bands);
  const score = currentBand?.score ?? 0;
  const expectedImpact = nextBand ? Math.max(0, nextBand.score - score) : 0;
  const valueLabel = `${value}${formatUnit(rule.unit)}`;
  const explanation = currentBand
    ? `${rule.description} القيمة الحالية ${valueLabel} تقع ضمن شريحة "${currentBand.label}" ولذلك حصلت على ${score} من ${rule.maxScore} نقطة. المرجع: ${reference}.`
    : `${rule.description} القيمة الحالية ${valueLabel} أقل من الحد الأدنى للشريحة المحتسبة، ولذلك لم تمنح نقاطًا لهذا المعيار. المرجع: ${reference}.`;

  return {
    ruleId: rule.id,
    ruleVersion: rule.version,
    title: rule.title,
    score,
    maxScore: rule.maxScore,
    value,
    unit: rule.unit,
    status: scoreStatus(score, rule.maxScore),
    explanation,
    recommendation: buildRecommendation(rule.recommendationTemplate, nextBand, rule.unit),
    expectedImpact,
    reference,
    sourcePage: rule.source.page,
    nextBand,
    valid: true
  };
}

export function executeNumericRuleSet<TInput extends object>(
  rules: Array<NumericThresholdRule<TInput>>,
  input: TInput,
  companySize: CompanySize
) {
  const results = rules.map(rule => executeNumericThresholdRule(rule, input, companySize));
  const rawScore = results.reduce((sum, result) => sum + result.score, 0);
  const maxScore = results.reduce((sum, result) => sum + result.maxScore, 0);
  const normalizedScore = maxScore > 0 ? Math.round((rawScore / maxScore) * 100) : 0;
  return { results, rawScore, maxScore, normalizedScore };
}

export function listRuleMetadata<TInput extends object>(rules: Array<NumericThresholdRule<TInput>>) {
  return rules.map(rule => ({
    id: rule.id,
    version: rule.version,
    domain: rule.domain,
    title: rule.title,
    maxScore: rule.maxScore,
    source: rule.source,
    weightGroup: rule.weightGroup
  }));
}
