export type ClassificationGrade = 1 | 2 | 3 | 4 | 5;
export type CompanySize = 'micro' | 'small' | 'medium' | 'large';
export type ReadinessStatus = 'good' | 'warning' | 'critical';
export type ClassificationDomain = 'financial' | 'technical' | 'documents' | 'governance' | 'performance';

export type FinancialInput = {
  revenue: number;
  netProfit: number;
  assets: number;
  liabilities: number;
  equity: number;
  cash: number;
  currentAssets: number;
  currentLiabilities: number;
  operatingCashFlow: number;
};

export type TechnicalInput = {
  companySize: CompanySize;
  engineersPercent: number;
  techniciansPercent: number;
  engineersExperience: number;
  techniciansExperience: number;
  saudizationPercent: number;
  saudiEngineersPercent: number;
};

export type DocumentItem = {
  id: string;
  name: string;
  required: boolean;
  present: boolean;
  expiresAt?: string;
  category?: 'legal' | 'financial' | 'governance' | 'technical' | 'classification';
  notes?: string;
};

export type TimelineEvent = {
  id: string;
  at: string;
  title: string;
  description: string;
  type: 'company' | 'financial' | 'technical' | 'document' | 'classification' | 'system';
};

export type Company = {
  id: string;
  name: string;
  crNumber: string;
  activity: 'construction' | 'operation-maintenance' | 'ict';
  targetGrade: ClassificationGrade;
  entityNumber?: string;
  branches?: number;
  city?: string;
  mainActivity?: string;
  financialYear?: number;
  financial: FinancialInput;
  technical: TechnicalInput;
  documents: DocumentItem[];
  timeline?: TimelineEvent[];
};

export type ScoredFactor = {
  key: string;
  label: string;
  score: number;
  maxScore: number;
  status: ReadinessStatus;
  valueLabel: string;
  explanation: string;
  recommendation?: string;
  expectedImpact?: number;
  ruleId?: string;
  ruleVersion?: string;
  reference?: string;
  sourcePage?: number;
};

export type MissingRequirement = {
  id: string;
  domain: ClassificationDomain;
  title: string;
  current: string;
  required: string;
  severity: ReadinessStatus;
  impact: number;
  recommendation: string;
};

export type ClassificationComponent = {
  key: ClassificationDomain;
  title: string;
  score: number;
  weight: number;
  weightedScore: number;
  status: ReadinessStatus;
  evidenceCount: number;
};

export type ClassificationResult = {
  totalScore: number;
  grade: ClassificationGrade;
  targetGrade: ClassificationGrade;
  targetThreshold: number;
  targetAchieved: boolean;
  readiness: number;
  confidence: number;
  components: ClassificationComponent[];
  missingRequirements: MissingRequirement[];
  history: Array<{ at: string; score: number; grade: ClassificationGrade; confidence: number; note: string }>;
};

export type DecisionResult = {
  financialScore: number;
  technicalScore: number;
  documentScore: number;
  totalScore: number;
  grade: ClassificationGrade;
  targetGrade: ClassificationGrade;
  targetAchieved: boolean;
  readiness: number;
  confidence: number;
  classification: ClassificationResult;
  blockers: ScoredFactor[];
  strengths: ScoredFactor[];
  recommendations: ScoredFactor[];
  missingRequirements: MissingRequirement[];
  executiveSummary: string;
  recommendationPlan: RecommendationPlan;
};

export type RecommendationPriority = 'urgent' | 'high' | 'medium' | 'low';
export type RecommendationEffort = 'low' | 'medium' | 'high';

export type RecommendationAction = {
  id: string;
  domain: ClassificationDomain;
  title: string;
  reason: string;
  action: string;
  expectedImpact: number;
  effort: RecommendationEffort;
  priority: RecommendationPriority;
  timeframe: string;
  confidence: number;
  simulatedScore: number;
  simulatedGrade: ClassificationGrade;
  targetContribution: number;
};

export type RecommendationPhase = {
  title: string;
  timeframe: string;
  actions: RecommendationAction[];
  expectedGain: number;
};

export type RecommendationPlan = {
  currentScore: number;
  targetScore: number;
  gap: number;
  currentGrade: ClassificationGrade;
  targetGrade: ClassificationGrade;
  targetAchieved: boolean;
  actions: RecommendationAction[];
  phases: RecommendationPhase[];
  quickWins: RecommendationAction[];
  strategicActions: RecommendationAction[];
  alerts: string[];
  summary: string;
};

export type WorkspaceCenter = {
  key: string;
  title: string;
  score: number;
  status: ReadinessStatus;
  summary: string;
  nextAction: string;
};

export type WorkspaceSummary = {
  centers: WorkspaceCenter[];
  completion: number;
  nextBestAction: string;
  timeline: TimelineEvent[];
};
