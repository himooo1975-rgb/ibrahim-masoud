import type { TechnicalInput } from '../types';
import type { NumericThresholdRule } from './types';

const GUIDE_TITLE = 'الدليل الاسترشادي لتصنيف المقاولين والشركات والمكاتب الاستشارية الهندسية - نوفمبر 2025';

export const constructionTechnicalRules: Array<NumericThresholdRule<TechnicalInput>> = [
  {
    id: 'TECH-CON-001',
    version: '2025.11',
    domain: 'technical',
    title: 'نسبة المهندسين من إجمالي العاملين',
    description: 'معيار أساسي ضمن التقييم الفني لمجال التشييد والبناء، ويقيس كثافة الكوادر الهندسية داخل المنشأة.',
    inputKey: 'engineersPercent',
    unit: '%',
    maxScore: 30,
    weightGroup: 'basic',
    source: { title: GUIDE_TITLE, page: 4, table: 'جدول رقم (1)' },
    tables: {
      micro: [
        { minInclusive: 48, score: 30, label: '48% فأكثر' },
        { minInclusive: 32, score: 27.5, label: 'من 32% إلى أقل من 48%' },
        { minInclusive: 22, score: 18, label: 'من 22% إلى أقل من 32%' },
        { minInclusive: 16, score: 13.5, label: 'من 16% إلى أقل من 22%' },
        { minInclusive: 0.5, score: 5, label: 'من 0.5% إلى أقل من 16%' }
      ],
      small: [
        { minInclusive: 18, score: 30, label: '18% فأكثر' },
        { minInclusive: 7, score: 27.5, label: 'من 7% إلى أقل من 18%' },
        { minInclusive: 5, score: 18, label: 'من 5% إلى أقل من 7%' },
        { minInclusive: 2, score: 13.5, label: 'من 2% إلى أقل من 5%' },
        { minInclusive: 0.5, score: 5, label: 'من 0.5% إلى أقل من 2%' }
      ],
      medium: [
        { minInclusive: 6, score: 30, label: '6% فأكثر' },
        { minInclusive: 4, score: 27.5, label: 'من 4% إلى أقل من 6%' },
        { minInclusive: 2, score: 18, label: 'من 2% إلى أقل من 4%' },
        { minInclusive: 1, score: 13.5, label: 'من 1% إلى أقل من 2%' },
        { minInclusive: 0.5, score: 5, label: 'من 0.5% إلى أقل من 1%' }
      ],
      large: [
        { minInclusive: 6, score: 30, label: '6% فأكثر' },
        { minInclusive: 4, score: 27.5, label: 'من 4% إلى أقل من 6%' },
        { minInclusive: 2, score: 18, label: 'من 2% إلى أقل من 4%' },
        { minInclusive: 1, score: 13.5, label: 'من 1% إلى أقل من 2%' },
        { minInclusive: 0.5, score: 5, label: 'من 0.5% إلى أقل من 1%' }
      ]
    },
    recommendationTemplate: 'رفع نسبة المهندسين إلى {nextMin}{unit} على الأقل للانتقال إلى شريحة أعلى في التقييم الفني.'
  },
  {
    id: 'TECH-CON-002',
    version: '2025.11',
    domain: 'technical',
    title: 'نسبة الفنيين من إجمالي العاملين',
    description: 'معيار أساسي يقيس جاهزية الكوادر الفنية المساندة للتنفيذ في مجال التشييد والبناء.',
    inputKey: 'techniciansPercent',
    unit: '%',
    maxScore: 30,
    weightGroup: 'basic',
    source: { title: GUIDE_TITLE, page: 4, table: 'جدول رقم (2)' },
    tables: {
      micro: [
        { minInclusive: 49, score: 30, label: '49% فأكثر' },
        { minInclusive: 32, score: 27.5, label: 'من 32% إلى أقل من 49%' },
        { minInclusive: 19, score: 18, label: 'من 19% إلى أقل من 32%' },
        { minInclusive: 16, score: 13.5, label: 'من 16% إلى أقل من 19%' },
        { minInclusive: 0.5, score: 5, label: 'من 0.5% إلى أقل من 16%' }
      ],
      small: [
        { minInclusive: 12, score: 30, label: '12% فأكثر' },
        { minInclusive: 7, score: 27.5, label: 'من 7% إلى أقل من 12%' },
        { minInclusive: 4, score: 18, label: 'من 4% إلى أقل من 7%' },
        { minInclusive: 2, score: 13.5, label: 'من 2% إلى أقل من 4%' },
        { minInclusive: 0.5, score: 5, label: 'من 0.5% إلى أقل من 2%' }
      ],
      medium: [
        { minInclusive: 4, score: 30, label: '4% فأكثر' },
        { minInclusive: 3, score: 27.5, label: 'من 3% إلى أقل من 4%' },
        { minInclusive: 2, score: 18, label: 'من 2% إلى أقل من 3%' },
        { minInclusive: 1, score: 13.5, label: 'من 1% إلى أقل من 2%' },
        { minInclusive: 0.5, score: 5, label: 'من 0.5% إلى أقل من 1%' }
      ],
      large: [
        { minInclusive: 4, score: 30, label: '4% فأكثر' },
        { minInclusive: 3, score: 27.5, label: 'من 3% إلى أقل من 4%' },
        { minInclusive: 2, score: 18, label: 'من 2% إلى أقل من 3%' },
        { minInclusive: 1, score: 13.5, label: 'من 1% إلى أقل من 2%' },
        { minInclusive: 0.5, score: 5, label: 'من 0.5% إلى أقل من 1%' }
      ]
    },
    recommendationTemplate: 'رفع نسبة الفنيين إلى {nextMin}{unit} على الأقل لتحسين نقاط الجاهزية الفنية.'
  },
  {
    id: 'TECH-CON-003',
    version: '2025.11',
    domain: 'technical',
    title: 'معدل خبرات المهندسين',
    description: 'معيار أساسي يقيس متوسط سنوات الخبرة للمهندسين ضمن التقييم الفني.',
    inputKey: 'engineersExperience',
    unit: 'year',
    maxScore: 10,
    weightGroup: 'basic',
    source: { title: GUIDE_TITLE, page: 5, table: 'جدول رقم (3)' },
    tables: {
      micro: [
        { minInclusive: 12, score: 10, label: '12 سنة فأكثر' },
        { minInclusive: 7, score: 8.8, label: 'من 7 إلى أقل من 12 سنة' },
        { minInclusive: 4, score: 6.3, label: 'من 4 إلى أقل من 7 سنوات' },
        { minInclusive: 1, score: 4.5, label: 'من 1 إلى أقل من 4 سنوات' },
        { minInclusive: 0.5, score: 2.5, label: 'من 0.5 إلى أقل من سنة' }
      ],
      small: [
        { minInclusive: 14, score: 10, label: '14 سنة فأكثر' },
        { minInclusive: 12, score: 8.8, label: 'من 12 إلى أقل من 14 سنة' },
        { minInclusive: 6, score: 6.3, label: 'من 6 إلى أقل من 12 سنة' },
        { minInclusive: 1, score: 4.5, label: 'من 1 إلى أقل من 6 سنوات' },
        { minInclusive: 0.5, score: 2.5, label: 'من 0.5 إلى أقل من سنة' }
      ],
      medium: [
        { minInclusive: 13, score: 10, label: '13 سنة فأكثر' },
        { minInclusive: 12, score: 8.8, label: 'من 12 إلى أقل من 13 سنة' },
        { minInclusive: 7, score: 6.3, label: 'من 7 إلى أقل من 12 سنة' },
        { minInclusive: 4, score: 4.5, label: 'من 4 إلى أقل من 7 سنوات' },
        { minInclusive: 0.5, score: 2.5, label: 'من 0.5 إلى أقل من 4 سنوات' }
      ],
      large: [
        { minInclusive: 14, score: 10, label: '14 سنة فأكثر' },
        { minInclusive: 12, score: 8.8, label: 'من 12 إلى أقل من 14 سنة' },
        { minInclusive: 11, score: 6.3, label: 'من 11 إلى أقل من 12 سنة' },
        { minInclusive: 6, score: 4.5, label: 'من 6 إلى أقل من 11 سنة' },
        { minInclusive: 0.5, score: 2.5, label: 'من 0.5 إلى أقل من 6 سنوات' }
      ]
    },
    recommendationTemplate: 'رفع متوسط خبرات المهندسين إلى {nextMin} سنة على الأقل لتحسين نتيجة الخبرات.'
  },
  {
    id: 'TECH-CON-004',
    version: '2025.11',
    domain: 'technical',
    title: 'معدل خبرات الفنيين',
    description: 'معيار أساسي يقيس متوسط سنوات الخبرة للفنيين ضمن التقييم الفني.',
    inputKey: 'techniciansExperience',
    unit: 'year',
    maxScore: 10,
    weightGroup: 'basic',
    source: { title: GUIDE_TITLE, page: 5, table: 'جدول رقم (4)' },
    tables: {
      micro: [
        { minInclusive: 17, score: 10, label: '17 سنة فأكثر' },
        { minInclusive: 7, score: 8.8, label: 'من 7 إلى أقل من 17 سنة' },
        { minInclusive: 4, score: 6.3, label: 'من 4 إلى أقل من 7 سنوات' },
        { minInclusive: 1, score: 4.5, label: 'من 1 إلى أقل من 4 سنوات' },
        { minInclusive: 0.5, score: 2.5, label: 'من 0.5 إلى أقل من سنة' }
      ],
      small: [
        { minInclusive: 15, score: 10, label: '15 سنة فأكثر' },
        { minInclusive: 12, score: 8.8, label: 'من 12 إلى أقل من 15 سنة' },
        { minInclusive: 7, score: 6.3, label: 'من 7 إلى أقل من 12 سنة' },
        { minInclusive: 1, score: 4.5, label: 'من 1 إلى أقل من 7 سنوات' },
        { minInclusive: 0.5, score: 2.5, label: 'من 0.5 إلى أقل من سنة' }
      ],
      medium: [
        { minInclusive: 16, score: 10, label: '16 سنة فأكثر' },
        { minInclusive: 12, score: 8.8, label: 'من 12 إلى أقل من 16 سنة' },
        { minInclusive: 7, score: 6.3, label: 'من 7 إلى أقل من 12 سنة' },
        { minInclusive: 2, score: 4.5, label: 'من 2 إلى أقل من 7 سنوات' },
        { minInclusive: 0.5, score: 2.5, label: 'من 0.5 إلى أقل من سنتين' }
      ],
      large: [
        { minInclusive: 17, score: 10, label: '17 سنة فأكثر' },
        { minInclusive: 15, score: 8.8, label: 'من 15 إلى أقل من 17 سنة' },
        { minInclusive: 12, score: 6.3, label: 'من 12 إلى أقل من 15 سنة' },
        { minInclusive: 4, score: 4.5, label: 'من 4 إلى أقل من 12 سنة' },
        { minInclusive: 0.5, score: 2.5, label: 'من 0.5 إلى أقل من 4 سنوات' }
      ]
    },
    recommendationTemplate: 'تعزيز خبرات الفنيين إلى {nextMin} سنة على الأقل للانتقال إلى شريحة أعلى.'
  },
  {
    id: 'TECH-CON-005',
    version: '2025.11',
    domain: 'technical',
    title: 'نسبة السعوديين من إجمالي العاملين',
    description: 'معيار إضافي يرفع الدرجة الفنية عبر تحسين توطين القوى العاملة.',
    inputKey: 'saudizationPercent',
    unit: '%',
    maxScore: 5,
    weightGroup: 'additional',
    source: { title: GUIDE_TITLE, page: 6, table: 'جدول رقم (5)' },
    tables: {
      micro: [
        { minInclusive: 74, score: 5, label: '74% فأكثر' },
        { minInclusive: 47, score: 4.125, label: 'من 47% إلى أقل من 74%' },
        { minInclusive: 33, score: 2.25, label: 'من 33% إلى أقل من 47%' },
        { minInclusive: 16, score: 1.125, label: 'من 16% إلى أقل من 33%' },
        { minInclusive: 0, score: 1, label: 'أقل من 16%' }
      ],
      small: [
        { minInclusive: 33, score: 5, label: '33% فأكثر' },
        { minInclusive: 25, score: 4.125, label: 'من 25% إلى أقل من 33%' },
        { minInclusive: 12, score: 2.25, label: 'من 12% إلى أقل من 25%' },
        { minInclusive: 6, score: 1.125, label: 'من 6% إلى أقل من 12%' },
        { minInclusive: 0.5, score: 1, label: 'من 0.5% إلى أقل من 6%' }
      ],
      medium: [
        { minInclusive: 22, score: 5, label: '22% فأكثر' },
        { minInclusive: 17, score: 4.125, label: 'من 17% إلى أقل من 22%' },
        { minInclusive: 12, score: 2.25, label: 'من 12% إلى أقل من 17%' },
        { minInclusive: 7, score: 1.125, label: 'من 7% إلى أقل من 12%' },
        { minInclusive: 0.5, score: 1, label: 'من 0.5% إلى أقل من 7%' }
      ],
      large: [
        { minInclusive: 17, score: 5, label: '17% فأكثر' },
        { minInclusive: 14, score: 4.125, label: 'من 14% إلى أقل من 17%' },
        { minInclusive: 12, score: 2.25, label: 'من 12% إلى أقل من 14%' },
        { minInclusive: 7, score: 1.125, label: 'من 7% إلى أقل من 12%' },
        { minInclusive: 0.5, score: 1, label: 'من 0.5% إلى أقل من 7%' }
      ]
    },
    recommendationTemplate: 'رفع نسبة السعودة إلى {nextMin}{unit} على الأقل للحصول على نقاط إضافية أعلى.'
  },
  {
    id: 'TECH-CON-006',
    version: '2025.11',
    domain: 'technical',
    title: 'نسبة المهندسين السعوديين من إجمالي العاملين',
    description: 'معيار إضافي يقيس نسبة المهندسين السعوديين داخل المنشأة.',
    inputKey: 'saudiEngineersPercent',
    unit: '%',
    maxScore: 5,
    weightGroup: 'additional',
    source: { title: GUIDE_TITLE, page: 6, table: 'جدول رقم (6)' },
    tables: {
      micro: [
        { minInclusive: 44, score: 5, label: '44% فأكثر' },
        { minInclusive: 32, score: 4.125, label: 'من 32% إلى أقل من 44%' },
        { minInclusive: 22, score: 2.25, label: 'من 22% إلى أقل من 32%' },
        { minInclusive: 16, score: 1.125, label: 'من 16% إلى أقل من 22%' },
        { minInclusive: 0, score: 1, label: 'أقل من 16%' }
      ],
      small: [
        { minInclusive: 11, score: 5, label: '11% فأكثر' },
        { minInclusive: 8, score: 4.125, label: 'من 8% إلى أقل من 11%' },
        { minInclusive: 3, score: 2.25, label: 'من 3% إلى أقل من 8%' },
        { minInclusive: 2, score: 1.125, label: 'من 2% إلى أقل من 3%' },
        { minInclusive: 0.5, score: 1, label: 'من 0.5% إلى أقل من 2%' }
      ],
      medium: [
        { minInclusive: 4, score: 5, label: '4% فأكثر' },
        { minInclusive: 3, score: 4.125, label: 'من 3% إلى أقل من 4%' },
        { minInclusive: 2, score: 2.25, label: 'من 2% إلى أقل من 3%' },
        { minInclusive: 1, score: 1.125, label: 'من 1% إلى أقل من 2%' },
        { minInclusive: 0.5, score: 1, label: 'من 0.5% إلى أقل من 1%' }
      ],
      large: [
        { minInclusive: 4, score: 5, label: '4% فأكثر' },
        { minInclusive: 3, score: 4.125, label: 'من 3% إلى أقل من 4%' },
        { minInclusive: 2, score: 2.25, label: 'من 2% إلى أقل من 3%' },
        { minInclusive: 1, score: 1.125, label: 'من 1% إلى أقل من 2%' },
        { minInclusive: 0.5, score: 1, label: 'من 0.5% إلى أقل من 1%' }
      ]
    },
    recommendationTemplate: 'رفع نسبة المهندسين السعوديين إلى {nextMin}{unit} على الأقل لتحسين معيار الكوادر السعودية المتخصصة.'
  }
];
