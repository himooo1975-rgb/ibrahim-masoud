import type { CompanySize, ReadinessStatus } from '../types';

export type RuleDomain = 'technical' | 'financial' | 'document' | 'governance' | 'classification';

export type NumericRuleBand = {
  minInclusive: number;
  score: number;
  label: string;
};

export type NumericThresholdRule<TInput extends object = Record<string, unknown>> = {
  id: string;
  version: string;
  domain: RuleDomain;
  title: string;
  description: string;
  inputKey: keyof TInput & string;
  unit: '%' | 'year' | 'number' | 'ratio';
  maxScore: number;
  weightGroup: 'basic' | 'additional' | 'supporting';
  source: {
    title: string;
    page: number;
    table?: string;
    effectiveFrom?: string;
  };
  tables: Record<CompanySize, NumericRuleBand[]>;
  recommendationTemplate: string;
};

export type RuleExecutionResult = {
  ruleId: string;
  ruleVersion: string;
  title: string;
  score: number;
  maxScore: number;
  value: number | null;
  unit: string;
  status: ReadinessStatus;
  explanation: string;
  recommendation?: string;
  expectedImpact: number;
  reference: string;
  sourcePage: number;
  nextBand?: NumericRuleBand;
  valid: boolean;
};
