# RAWASI Recommendation Engine

Commit 6 introduces the first enterprise recommendation layer in RAWASI.

## Responsibilities

- Read the output of `ClassificationEngine`.
- Convert missing requirements into actionable recommendations.
- Rank actions by priority, impact, effort, and confidence.
- Build a phased improvement roadmap.
- Surface quick wins and strategic actions.
- Provide alerts for stale financials, missing documents, and low confidence.

## Output

Each recommendation includes:

- Domain: financial, technical, documents, governance, performance.
- Reason.
- Action.
- Expected impact in points.
- Effort.
- Priority.
- Timeframe.
- Simulated score and grade after execution.

## Design Principle

The engine does not merely say: "the company failed this criterion".
It answers: "what should the consultant do next, and what is the expected classification impact?"
