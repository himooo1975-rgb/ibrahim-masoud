# Commit 5 - RAWASI Classification Engine V1

## الهدف
ربط نتائج Financial Engine وTechnical Rules Engine وDocument Engine داخل محرك تصنيف واحد ينتج الدرجة والثقة والفجوة نحو الدرجة المستهدفة.

## Added
- إضافة `ClassificationResult` و`ClassificationComponent` و`MissingRequirement` إلى نموذج المجال.
- إضافة `evaluateClassification(company)` داخل `classification-engine.ts`.
- إضافة حساب نسبة الثقة `confidence` بناءً على اكتمال البيانات والأدلة.
- إضافة تحليل المتطلبات الناقصة المؤثرة على التصنيف.
- إضافة تاريخ تقييم أولي `classification.history`.
- إضافة شاشة Classification Engine داخل الواجهة.
- إضافة جدول مكونات التصنيف: مالي، فني، مستندات.
- إضافة قائمة متطلبات ناقصة مرتبة حسب الأثر.

## Changed
- أصبح `Decision Engine` يعتمد على `Classification Engine` بدل حساب الدرجة داخليًا.
- تحديث KPIs لإظهار الفجوة ونسبة الثقة.
- تحديث عنوان المنصة إلى Commit 5.

## Verified
- `npm run check`
- `npm run build`

## Next
Commit 6 سيركز على Recommendation Engine V2 وخطة رفع التصنيف ذات مراحل وأولويات.
