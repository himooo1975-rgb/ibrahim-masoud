import type { ScoredFactor } from '@rawasi/core';

export function FactorList({ title, items, empty }: { title: string; items: ScoredFactor[]; empty: string }) {
  return (
    <article className="card">
      <h3>{title}</h3>
      {items.length === 0 ? <p className="muted">{empty}</p> : (
        <div className="factor-list">
          {items.map(item => (
            <div className={`factor status-${item.status}`} key={item.key}>
              <div>
                <b>{item.label}</b>
                <p>{item.explanation}</p>
                {item.reference ? <em className="rule-reference">المرجع: {item.reference}</em> : null}
                {item.recommendation ? <small>{item.recommendation}</small> : null}
              </div>
              <span>{item.expectedImpact ? `+${item.expectedImpact}` : item.valueLabel}</span>
            </div>
          ))}
        </div>
      )}
    </article>
  );
}
