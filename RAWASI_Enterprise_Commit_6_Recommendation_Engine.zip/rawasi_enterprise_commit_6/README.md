# منصة الرواسي - RAWASI Platform

منصة متخصصة في تصنيف شركات المقاولات، هدفها ليس عرض الدرجة فقط، بل تشخيص الوضع الحالي وبناء خطة للوصول إلى الدرجة المستهدفة.

## التشغيل محليًا
```bash
npm install
npm run dev
```

## Commit 2
تمت إضافة نواة محركات الرواسي:
- Financial Engine
- Technical Engine
- Document Engine
- Decision Engine
- Simulator Engine

## مبدأ البناء
Engine-first: كل شاشة تعتمد على محركات مستقلة وقابلة للاختبار، وليس على منطق مبعثر داخل الواجهة.


## Commit 4
تمت إضافة Company Workspace:
- Workspace Engine
- مراكز ملف الشركة
- Timeline
- بيانات شركة موسعة
- ربط كل مركز بالإجراء التالي


## Commit 4 - RAWASI Rules Engine

هذا الإصدار يضيف أول نسخة من محرك القواعد داخل الرواسي. قواعد التقييم الفني أصبحت موجودة في مستودع مستقل داخل `packages/core/src/rules`، ويتم تنفيذها عبر `Rules Engine` مع تفسير ومرجع لكل معيار.

### تشغيل المشروع

```bash
npm install
npm run dev
```

### التحقق

```bash
npm run check
npm run build
```


## Commit 6 - Classification Engine V1
تمت إضافة محرك التصنيف الذي يجمع المكونات المالية والفنية والمستندية، ويحسب الدرجة والثقة والفجوة نحو الدرجة المستهدفة.

### التحقق
```bash
npm run check
npm run build
```


## Commit 6 — Recommendation Engine

This commit adds the first advisory layer of RAWASI:

- Prioritized recommendation plan.
- Expected point impact for each action.
- Simulated grade after action execution.
- Phased improvement roadmap.
- Quick wins and strategic actions.
- Smart alerts.

Run:

```bash
npm install
npm run check
npm run build
```
