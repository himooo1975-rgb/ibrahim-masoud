# منصة الرواسي - RAWASI Platform

منصة متخصصة في تصنيف شركات المقاولات، هدفها ليس عرض الدرجة فقط، بل تشخيص الوضع الحالي وبناء خطة للوصول إلى الدرجة المستهدفة.

## التشغيل محليًا
```bash
npm install
npm run dev
```

## Commit 2
تمت إضافة نواة محركات الرواسي:
- Financial Engine
- Technical Engine
- Document Engine
- Decision Engine
- Simulator Engine

## مبدأ البناء
Engine-first: كل شاشة تعتمد على محركات مستقلة وقابلة للاختبار، وليس على منطق مبعثر داخل الواجهة.
