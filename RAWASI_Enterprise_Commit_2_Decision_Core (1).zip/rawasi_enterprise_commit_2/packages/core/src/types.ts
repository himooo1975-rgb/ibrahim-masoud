export type ClassificationGrade = 1 | 2 | 3 | 4 | 5;
export type CompanySize = 'micro' | 'small' | 'medium' | 'large';
export type ReadinessStatus = 'good' | 'warning' | 'critical';

export type FinancialInput = {
  revenue: number;
  netProfit: number;
  assets: number;
  liabilities: number;
  equity: number;
  cash: number;
  currentAssets: number;
  currentLiabilities: number;
  operatingCashFlow: number;
};

export type TechnicalInput = {
  companySize: CompanySize;
  engineersPercent: number;
  techniciansPercent: number;
  engineersExperience: number;
  techniciansExperience: number;
  saudizationPercent: number;
  saudiEngineersPercent: number;
};

export type DocumentItem = {
  id: string;
  name: string;
  required: boolean;
  present: boolean;
  expiresAt?: string;
};

export type Company = {
  id: string;
  name: string;
  crNumber: string;
  activity: 'construction' | 'operation-maintenance' | 'ict';
  targetGrade: ClassificationGrade;
  financial: FinancialInput;
  technical: TechnicalInput;
  documents: DocumentItem[];
};

export type ScoredFactor = {
  key: string;
  label: string;
  score: number;
  maxScore: number;
  status: ReadinessStatus;
  valueLabel: string;
  explanation: string;
  recommendation?: string;
  expectedImpact?: number;
};

export type DecisionResult = {
  financialScore: number;
  technicalScore: number;
  documentScore: number;
  totalScore: number;
  grade: ClassificationGrade;
  targetGrade: ClassificationGrade;
  targetAchieved: boolean;
  readiness: number;
  blockers: ScoredFactor[];
  strengths: ScoredFactor[];
  recommendations: ScoredFactor[];
  executiveSummary: string;
};
