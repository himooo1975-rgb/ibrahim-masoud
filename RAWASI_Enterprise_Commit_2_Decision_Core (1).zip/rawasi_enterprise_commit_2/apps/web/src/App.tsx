import { useEffect, useMemo, useState } from 'react';
import type { Company, ClassificationGrade, FinancialInput, TechnicalInput } from '@rawasi/core';
import { buildDecision, gradeLabel, simulateCompany } from '@rawasi/core';
import { demoCompany } from './data/demoCompany';
import { loadCompany, resetCompany, saveCompany } from './services/storage';
import { FactorList } from './components/FactorList';
import { KpiCard } from './components/KpiCard';

const financialLabels: Record<keyof FinancialInput, string> = {
  revenue: 'الإيرادات',
  netProfit: 'صافي الربح',
  assets: 'إجمالي الأصول',
  liabilities: 'إجمالي الالتزامات',
  equity: 'حقوق الملكية',
  cash: 'النقد وما في حكمه',
  currentAssets: 'الأصول المتداولة',
  currentLiabilities: 'الالتزامات المتداولة',
  operatingCashFlow: 'التدفق النقدي التشغيلي'
};

const technicalLabels: Record<keyof TechnicalInput, string> = {
  companySize: 'حجم المنشأة',
  engineersPercent: 'نسبة المهندسين %',
  techniciansPercent: 'نسبة الفنيين %',
  engineersExperience: 'متوسط خبرات المهندسين',
  techniciansExperience: 'متوسط خبرات الفنيين',
  saudizationPercent: 'نسبة السعودة %',
  saudiEngineersPercent: 'نسبة المهندسين السعوديين %'
};

export function App() {
  const [company, setCompany] = useState<Company>(() => loadCompany(demoCompany));
  const [simPatch, setSimPatch] = useState({ equityDelta: 0, liabilitiesDelta: 0, currentAssetsDelta: 0, engineersPercentDelta: 0 });
  const decision = useMemo(() => buildDecision(company), [company]);
  const simulation = useMemo(() => simulateCompany(company, simPatch), [company, simPatch]);

  useEffect(() => saveCompany(company), [company]);

  const updateCompany = <K extends keyof Company>(key: K, value: Company[K]) => {
    setCompany(prev => ({ ...prev, [key]: value }));
  };

  const updateFinancial = (key: keyof FinancialInput, value: number) => {
    setCompany(prev => ({ ...prev, financial: { ...prev.financial, [key]: Number.isFinite(value) ? value : 0 } }));
  };

  const updateTechnical = (key: keyof TechnicalInput, value: number | TechnicalInput['companySize']) => {
    setCompany(prev => ({ ...prev, technical: { ...prev.technical, [key]: value } }));
  };

  const toggleDocument = (id: string) => {
    setCompany(prev => ({
      ...prev,
      documents: prev.documents.map(doc => doc.id === id ? { ...doc, present: !doc.present } : doc)
    }));
  };

  return (
    <main className="app-shell">
      <aside className="sidebar">
        <div className="brand-mark">ر</div>
        <h1>منصة الرواسي</h1>
        <p>من البيانات إلى القرار، ومن القرار إلى التصنيف.</p>
        <nav>
          <a href="#operations">غرفة العمليات</a>
          <a href="#company">ملف الشركة</a>
          <a href="#finance">التقييم المالي</a>
          <a href="#technical">التقييم الفني</a>
          <a href="#decision">محرك القرار</a>
          <a href="#simulator">المحاكي</a>
        </nav>
      </aside>

      <section className="content">
        <header className="hero" id="operations">
          <div>
            <span className="eyebrow">RAWASI Enterprise • Commit 2</span>
            <h2>غرفة عمليات التصنيف</h2>
            <p>{decision.executiveSummary}</p>
            <div className="hero-actions">
              <button onClick={() => { resetCompany(); setCompany(demoCompany); }}>إعادة بيانات العرض</button>
              <button className="primary" onClick={() => window.print()}>طباعة ملخص تنفيذي</button>
            </div>
          </div>
          <div className="score-card">
            <span>الدرجة المتوقعة</span>
            <strong>{gradeLabel(decision.grade)}</strong>
            <small>الجاهزية للهدف: {decision.readiness}%</small>
          </div>
        </header>

        <section className="kpi-grid">
          <KpiCard title="النقاط الإجمالية" value={`${decision.totalScore}/100`} hint="مالية + فنية + مستندات" tone="blue" />
          <KpiCard title="الدرجة المستهدفة" value={gradeLabel(decision.targetGrade)} hint={decision.targetAchieved ? 'محققة حاليًا' : 'تحتاج تحسين'} tone={decision.targetAchieved ? 'green' : 'gold'} />
          <KpiCard title="التقييم المالي" value={`${decision.financialScore}/100`} hint="Financial Engine" tone="green" />
          <KpiCard title="اكتمال المستندات" value={`${decision.documentScore}%`} hint="Document Readiness" tone={decision.documentScore >= 80 ? 'green' : 'red'} />
        </section>

        <section className="grid two" id="company">
          <article className="card">
            <h3>ملف الشركة</h3>
            <label>اسم الشركة<input value={company.name} onChange={event => updateCompany('name', event.target.value)} /></label>
            <label>السجل التجاري<input value={company.crNumber} onChange={event => updateCompany('crNumber', event.target.value)} /></label>
            <label>الدرجة المستهدفة
              <select value={company.targetGrade} onChange={event => updateCompany('targetGrade', Number(event.target.value) as ClassificationGrade)}>
                {[1,2,3,4,5].map(grade => <option value={grade} key={grade}>الدرجة {grade}</option>)}
              </select>
            </label>
          </article>

          <article className="card">
            <h3>جاهزية المستندات</h3>
            {company.documents.map(doc => (
              <label className="check-row" key={doc.id}>
                <input type="checkbox" checked={doc.present} onChange={() => toggleDocument(doc.id)} />
                <span>{doc.name}</span>
              </label>
            ))}
          </article>
        </section>

        <section className="grid two">
          <article className="card" id="finance">
            <h3>التقييم المالي</h3>
            <div className="form-grid">
              {(Object.keys(company.financial) as Array<keyof FinancialInput>).map(key => (
                <label key={key}><span>{financialLabels[key]}</span><input type="number" value={company.financial[key]} onChange={event => updateFinancial(key, Number(event.target.value))} /></label>
              ))}
            </div>
          </article>

          <article className="card" id="technical">
            <h3>التقييم الفني</h3>
            <label>حجم المنشأة
              <select value={company.technical.companySize} onChange={event => updateTechnical('companySize', event.target.value as TechnicalInput['companySize'])}>
                <option value="micro">متناهية الصغر</option>
                <option value="small">صغيرة</option>
                <option value="medium">متوسطة</option>
                <option value="large">كبيرة</option>
              </select>
            </label>
            <div className="form-grid">
              {(Object.keys(company.technical) as Array<keyof TechnicalInput>).filter(key => key !== 'companySize').map(key => (
                <label key={key}><span>{technicalLabels[key]}</span><input type="number" value={company.technical[key] as number} onChange={event => updateTechnical(key, Number(event.target.value))} /></label>
              ))}
            </div>
          </article>
        </section>

        <section className="grid three" id="decision">
          <FactorList title="العوائق الحرجة" items={decision.blockers} empty="لا توجد عوائق حرجة في البيانات الحالية." />
          <FactorList title="نقاط القوة" items={decision.strengths} empty="أدخل بيانات أكثر لاستخراج نقاط القوة." />
          <FactorList title="خطة رفع التصنيف" items={decision.recommendations} empty="لا توجد توصيات مطلوبة حاليًا." />
        </section>

        <section className="card" id="simulator">
          <h3>محاكي ماذا لو؟</h3>
          <p className="muted">عدّل السيناريو دون تغيير بيانات الشركة الأصلية، وشاهد أثره على الدرجة.</p>
          <div className="simulator-grid">
            <label>زيادة حقوق الملكية<input type="number" value={simPatch.equityDelta} onChange={event => setSimPatch(prev => ({ ...prev, equityDelta: Number(event.target.value) }))} /></label>
            <label>تخفيض الالتزامات<input type="number" value={Math.abs(simPatch.liabilitiesDelta)} onChange={event => setSimPatch(prev => ({ ...prev, liabilitiesDelta: -Math.abs(Number(event.target.value)) }))} /></label>
            <label>زيادة الأصول المتداولة<input type="number" value={simPatch.currentAssetsDelta} onChange={event => setSimPatch(prev => ({ ...prev, currentAssetsDelta: Number(event.target.value) }))} /></label>
            <label>زيادة نسبة المهندسين<input type="number" value={simPatch.engineersPercentDelta} onChange={event => setSimPatch(prev => ({ ...prev, engineersPercentDelta: Number(event.target.value) }))} /></label>
            <div className="simulation-result">
              <span>النتيجة بعد السيناريو</span>
              <strong>{gradeLabel(simulation.decision.grade)}</strong>
              <small>{simulation.decision.totalScore}/100 نقطة</small>
            </div>
          </div>
        </section>
      </section>
    </main>
  );
}
