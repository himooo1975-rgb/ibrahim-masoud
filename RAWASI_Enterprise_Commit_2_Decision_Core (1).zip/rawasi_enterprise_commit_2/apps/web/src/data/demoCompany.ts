import type { Company } from '@rawasi/core';

export const defaultDocuments = [
  { id: 'cr', name: 'السجل التجاري', required: true, present: true },
  { id: 'financials', name: 'القوائم المالية المعتمدة', required: true, present: true },
  { id: 'zakat', name: 'شهادة الزكاة والضريبة', required: true, present: false },
  { id: 'gosi', name: 'شهادة التأمينات الاجتماعية', required: true, present: false },
  { id: 'board', name: 'قرار تشكيل مجلس الإدارة / التفويض', required: true, present: false }
];

export const demoCompany: Company = {
  id: 'rawasi-demo',
  name: 'شركة نموذجية للمقاولات',
  crNumber: '1010000000',
  activity: 'construction',
  targetGrade: 1,
  financial: {
    revenue: 24_000_000,
    netProfit: 2_200_000,
    assets: 38_000_000,
    liabilities: 17_000_000,
    equity: 21_000_000,
    cash: 4_200_000,
    currentAssets: 11_500_000,
    currentLiabilities: 10_800_000,
    operatingCashFlow: 1_400_000
  },
  technical: {
    companySize: 'small',
    engineersPercent: 11,
    techniciansPercent: 9,
    engineersExperience: 7,
    techniciansExperience: 8,
    saudizationPercent: 18,
    saudiEngineersPercent: 4
  },
  documents: defaultDocuments
};
