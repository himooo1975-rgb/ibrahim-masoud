# RAWASI Platform - Real Development Sprint A

مشروع التأسيس الحقيقي لمنصة الرواسي.

## التشغيل

```bash
npm install
npm run dev
```

## الفحص

```bash
npm run check
npm run build
```

## ما تم إنشاؤه
- React + TypeScript + Vite.
- Tailwind Design Tokens لهوية الرواسي.
- Financial Engine أولي.
- Classification Engine أولي.
- Decision Engine أولي.
- Recommendation Engine أولي.
- Dashboard تشغيلية لعينة شركة.
