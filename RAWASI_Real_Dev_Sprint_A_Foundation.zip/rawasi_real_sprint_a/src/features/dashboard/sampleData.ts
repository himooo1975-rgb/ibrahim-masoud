import type { Company } from '../../lib/types';

export const sampleCompany: Company = {
  id: 'rawasi-demo-001',
  name: 'شركة الرواسي للمقاولات',
  commercialRegistration: '1010000000',
  city: 'الرياض',
  targetGrade: 'الأولى',
  financial: {
    year: 2025,
    assets: 10000000,
    liabilities: 4200000,
    equity: 5800000,
    revenue: 9000000,
    netProfit: 850000,
    operatingCashFlow: 720000,
  },
  technical: {
    employees: 120,
    engineers: 12,
    technicians: 28,
    saudiEmployees: 34,
    avgEngineerExperience: 8,
    avgTechnicianExperience: 7,
  },
  documents: [
    { key: 'cr', title: 'السجل التجاري', status: 'مكتمل' },
    { key: 'financials', title: 'القوائم المالية', status: 'مكتمل' },
    { key: 'zakat', title: 'شهادة الزكاة', status: 'مكتمل' },
    { key: 'gosi', title: 'التأمينات الاجتماعية', status: 'ناقص' },
  ],
};
