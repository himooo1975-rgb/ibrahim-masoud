export type ClassificationGrade = 'الأولى' | 'الثانية' | 'الثالثة' | 'الرابعة' | 'الخامسة' | 'غير مصنف';

export interface Company {
  id: string;
  name: string;
  commercialRegistration: string;
  city: string;
  targetGrade: ClassificationGrade;
  financial: FinancialStatement;
  technical: TechnicalProfile;
  documents: DocumentStatus[];
}

export interface FinancialStatement {
  year: number;
  assets: number;
  liabilities: number;
  equity: number;
  revenue: number;
  netProfit: number;
  operatingCashFlow: number;
}

export interface TechnicalProfile {
  employees: number;
  engineers: number;
  technicians: number;
  saudiEmployees: number;
  avgEngineerExperience: number;
  avgTechnicianExperience: number;
}

export interface DocumentStatus {
  key: string;
  title: string;
  status: 'مكتمل' | 'ناقص' | 'يحتاج تحديث';
}

export interface EngineResult {
  score: number;
  grade: ClassificationGrade;
  confidence: number;
  reasons: string[];
  recommendations: string[];
}
