import { Building2, FileText, LineChart, Target } from 'lucide-react';
import { Card } from '../components/Card';
import { classifyCompany } from '../engines/classification/classificationEngine';
import { buildDecision } from '../engines/decision/decisionEngine';
import { prioritizeRecommendations } from '../engines/recommendation/recommendationEngine';
import { sampleCompany } from '../features/dashboard/sampleData';

export function App() {
  const result = classifyCompany(sampleCompany);
  const decision = buildDecision(sampleCompany, result);
  const recommendations = prioritizeRecommendations(result);

  return (
    <main className="min-h-screen bg-rawasi-sand">
      <header className="bg-gradient-to-l from-rawasi-navy to-rawasi-blue px-8 py-8 text-white">
        <div className="mx-auto max-w-7xl">
          <p className="text-sm text-white/75">RAWASI Platform</p>
          <h1 className="mt-2 text-4xl font-black">منصة الرواسي</h1>
          <p className="mt-3 max-w-2xl text-white/80">منصة ذكاء التصنيف لشركات المقاولات: من البيانات إلى القرار، ومن القرار إلى التصنيف.</p>
        </div>
      </header>

      <div className="mx-auto grid max-w-7xl gap-5 px-8 py-8 lg:grid-cols-4">
        <Card title="ملف الشركة">
          <div className="flex items-start gap-3">
            <Building2 className="text-rawasi-green" />
            <div>
              <p className="font-bold">{sampleCompany.name}</p>
              <p className="text-sm text-slate-500">{sampleCompany.city} · سجل {sampleCompany.commercialRegistration}</p>
            </div>
          </div>
        </Card>

        <Card title="التصنيف المتوقع">
          <div className="flex items-center gap-3">
            <Target className="text-rawasi-lime" />
            <div>
              <p className="text-3xl font-black text-rawasi-navy">{result.grade}</p>
              <p className="text-sm text-slate-500">{result.score}/100 · ثقة {result.confidence}%</p>
            </div>
          </div>
        </Card>

        <Card title="المستندات">
          <div className="flex items-center gap-3">
            <FileText className="text-rawasi-green" />
            <p className="font-bold">{sampleCompany.documents.filter((d) => d.status === 'مكتمل').length}/{sampleCompany.documents.length} مكتمل</p>
          </div>
        </Card>

        <Card title="المؤشرات">
          <div className="flex items-center gap-3">
            <LineChart className="text-rawasi-blue" />
            <p className="font-bold">رحلة التصنيف مفعلة</p>
          </div>
        </Card>
      </div>

      <div className="mx-auto grid max-w-7xl gap-5 px-8 pb-10 lg:grid-cols-2">
        <Card title="قرار الرواسي">
          <p className="leading-8 text-slate-700">{decision}</p>
          <ul className="mt-4 space-y-2">
            {result.reasons.map((reason) => (
              <li key={reason} className="rounded-xl bg-slate-50 p-3 text-sm text-slate-700">{reason}</li>
            ))}
          </ul>
        </Card>

        <Card title="خطة التحسين">
          <ol className="space-y-3">
            {recommendations.map((item, index) => (
              <li key={item} className="rounded-xl border border-slate-200 p-3">
                <span className="ml-2 inline-flex h-7 w-7 items-center justify-center rounded-full bg-rawasi-green text-sm font-bold text-white">{index + 1}</span>
                {item}
              </li>
            ))}
          </ol>
        </Card>
      </div>
    </main>
  );
}
