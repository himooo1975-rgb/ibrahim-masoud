import { useMemo, useState } from 'react';
import { Database, Download, RefreshCcw, Upload } from 'lucide-react';
import { Card } from '../components/Card';
import { classifyCompany } from '../engines/classification/classificationEngine';
import { buildDecision } from '../engines/decision/decisionEngine';
import { prioritizeRecommendations } from '../engines/recommendation/recommendationEngine';
import { createCompanyDraft } from '../data/defaults';
import { RawasiRepository } from '../data/rawasiRepository';
import { CompanyForm } from '../features/companies/CompanyForm';
import { CompanyList } from '../features/companies/CompanyList';
import { AuditTimeline } from '../features/companies/AuditTimeline';
import { CompanyWorkspace } from '../features/workspace/CompanyWorkspace';
import { FinancialIntelligence } from '../features/financial/FinancialIntelligence';
import { ClassificationIntelligence } from '../features/classification/ClassificationIntelligence';
import { ExecutiveReports } from '../features/reports/ExecutiveReports';
import { SmartDocuments } from '../features/documents/SmartDocuments';
import type { Company, RawasiSnapshot } from '../lib/types';

const repository = new RawasiRepository();

type ViewMode = 'workspace' | 'edit' | 'financial' | 'documents' | 'classification' | 'decision' | 'reports' | 'audit';

function downloadTextFile(filename: string, content: string) {
  const blob = new Blob([content], { type: 'application/json;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(url);
}

export function App() {
  const [snapshot, setSnapshot] = useState<RawasiSnapshot>(() => repository.load());
  const [selectedCompanyId, setSelectedCompanyId] = useState(() => snapshot.companies[0]?.id ?? '');
  const selectedCompany = snapshot.companies.find((company) => company.id === selectedCompanyId) ?? snapshot.companies[0] ?? createCompanyDraft();
  const [draft, setDraft] = useState<Company>(selectedCompany);
  const [message, setMessage] = useState('Sprint G: Smart Documents يربط نص القوائم المالية بمحرك التحليل والتصنيف.');
  const [viewMode, setViewMode] = useState<ViewMode>('workspace');

  const result = useMemo(() => classifyCompany(draft), [draft]);
  const decision = useMemo(() => buildDecision(draft, result), [draft, result]);
  const recommendations = useMemo(() => prioritizeRecommendations(result), [result]);

  function selectCompany(company: Company) {
    setSelectedCompanyId(company.id);
    setDraft(company);
    setViewMode('workspace');
    setMessage(`تم فتح Workspace شركة ${company.name}.`);
  }

  function saveCompany() {
    try {
      const next = repository.saveCompany(draft);
      setSnapshot(next);
      setSelectedCompanyId(draft.id);
      setMessage('تم حفظ Workspace الشركة بنجاح داخل RawasiRepository.');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'تعذر حفظ الشركة.');
    }
  }

  function createNewCompany() {
    const company = createCompanyDraft();
    setDraft(company);
    setSelectedCompanyId(company.id);
    setViewMode('edit');
    setMessage('تم تجهيز Workspace شركة جديد. أدخل البيانات ثم اضغط حفظ.');
  }

  function deleteCompany() {
    if (!draft.id) return;
    const next = repository.deleteCompany(draft.id);
    setSnapshot(next);
    const first = next.companies[0] ?? createCompanyDraft();
    setSelectedCompanyId(first.id);
    setDraft(first);
    setMessage('تم حذف ملف الشركة من المستودع المحلي.');
  }

  function exportBackup() {
    downloadTextFile(`rawasi-backup-${new Date().toISOString().slice(0, 10)}.json`, repository.exportBackup());
    setMessage('تم تجهيز نسخة احتياطية قابلة للاستعادة.');
  }

  async function importBackup(file: File | undefined) {
    if (!file) return;
    try {
      const text = await file.text();
      const next = repository.importBackup(text);
      setSnapshot(next);
      const first = next.companies[0] ?? createCompanyDraft();
      setSelectedCompanyId(first.id);
      setDraft(first);
      setViewMode('workspace');
      setMessage('تمت استعادة النسخة الاحتياطية وترقية البيانات إلى Sprint G.');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'تعذر استعادة النسخة الاحتياطية.');
    }
  }

  const navItems: { key: ViewMode; label: string }[] = [
    { key: 'workspace', label: 'Workspace' },
    { key: 'edit', label: 'إدخال وتعديل' },
    { key: 'financial', label: 'الذكاء المالي' },
    { key: 'documents', label: 'المستندات الذكية' },
    { key: 'classification', label: 'ذكاء التصنيف' },
    { key: 'decision', label: 'قرار وتوصيات' },
    { key: 'reports', label: 'التقرير التنفيذي' },
    { key: 'audit', label: 'سجل العمليات' },
  ];

  return (
    <main className="min-h-screen bg-rawasi-sand">
      <header className="bg-gradient-to-l from-rawasi-navy to-rawasi-blue px-8 py-8 text-white">
        <div className="mx-auto max-w-7xl">
          <p className="text-sm text-white/75">RAWASI Platform · Real Development Sprint G</p>
          <h1 className="mt-2 text-4xl font-black">منصة الرواسي</h1>
          <p className="mt-3 max-w-3xl text-white/80">Smart Documents: استيراد نص القوائم المالية، استخراج البنود، التحقق منها، ثم ربطها مباشرة بالتقييم الائتماني والتصنيف.</p>
        </div>
      </header>

      <div className="mx-auto grid max-w-7xl gap-5 px-8 py-6 lg:grid-cols-[300px_1fr]">
        <CompanyList companies={snapshot.companies} selectedId={draft.id} onSelect={selectCompany} />

        <section className="grid gap-5">
          <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-sm font-bold text-emerald-900">{message}</div>

          <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white p-3 shadow-sm">
            <div className="flex flex-wrap gap-2">
              {navItems.map((item) => (
                <button
                  key={item.key}
                  className={`rounded-xl px-4 py-3 text-sm font-black ${viewMode === item.key ? 'bg-rawasi-navy text-white' : 'bg-slate-100 text-slate-700'}`}
                  type="button"
                  onClick={() => setViewMode(item.key)}
                >
                  {item.label}
                </button>
              ))}
            </div>
            <div className="flex flex-wrap gap-2">
              <button className="rounded-xl bg-rawasi-green px-4 py-3 font-bold text-white" type="button" onClick={saveCompany}>حفظ Workspace</button>
              <button className="rounded-xl border border-slate-200 px-4 py-3 font-bold" type="button" onClick={createNewCompany}>شركة جديدة</button>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <button className="inline-flex items-center gap-2 rounded-xl bg-rawasi-navy px-4 py-3 font-bold text-white" type="button" onClick={exportBackup}>
              <Download size={18} /> تصدير نسخة احتياطية
            </button>
            <label className="inline-flex cursor-pointer items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-3 font-bold text-slate-700">
              <Upload size={18} /> استيراد نسخة
              <input className="hidden" type="file" accept="application/json" onChange={(event) => void importBackup(event.target.files?.[0])} />
            </label>
            <button className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-3 font-bold text-slate-700" type="button" onClick={() => setSnapshot(repository.load())}>
              <RefreshCcw size={18} /> تحديث من المستودع
            </button>
            <span className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-3 font-bold text-slate-700"><Database size={18} /> {snapshot.companies.length} شركة</span>
          </div>

          {viewMode === 'workspace' && <CompanyWorkspace company={draft} result={result} onChange={setDraft} />}

          {viewMode === 'edit' && <CompanyForm company={draft} onChange={setDraft} onSave={saveCompany} onNew={createNewCompany} onDelete={deleteCompany} />}

          {viewMode === 'financial' && <FinancialIntelligence company={draft} onChange={setDraft} />}

          {viewMode === 'documents' && <SmartDocuments company={draft} onChange={setDraft} />}

          {viewMode === 'classification' && <ClassificationIntelligence company={draft} result={result} />}

          {viewMode === 'reports' && <ExecutiveReports company={draft} result={result} />}

          {viewMode === 'decision' && (
            <div className="grid gap-5 lg:grid-cols-2">
              <Card title="قرار الرواسي">
                <p className="leading-8 text-slate-700">{decision}</p>
                <ul className="mt-4 space-y-2">
                  {result.reasons.map((reason) => (
                    <li key={reason} className="rounded-xl bg-slate-50 p-3 text-sm text-slate-700">{reason}</li>
                  ))}
                </ul>
              </Card>

              <Card title="خطة التحسين">
                <ol className="space-y-3">
                  {recommendations.map((item, index) => (
                    <li key={item} className="rounded-xl border border-slate-200 p-3">
                      <span className="ml-2 inline-flex h-7 w-7 items-center justify-center rounded-full bg-rawasi-green text-sm font-bold text-white">{index + 1}</span>
                      {item}
                    </li>
                  ))}
                </ol>
              </Card>
            </div>
          )}

          {viewMode === 'audit' && <AuditTimeline entries={snapshot.auditLog} />}
        </section>
      </div>
    </main>
  );
}
