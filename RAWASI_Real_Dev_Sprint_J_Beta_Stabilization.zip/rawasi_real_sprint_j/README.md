# RAWASI Enterprise 0.9 Beta - Sprint J

حزمة Source Only لبناء مرحلة **Beta Stabilization**.

## الجديد
- Beta Mission Control.
- Beta Readiness Engine.
- Domain Smoke Test.
- Prisma schema مبدئي.
- Repository محلي مستقر.
- شاشة جاهزية النسخة التجريبية.

## التشغيل
```bash
npm install
npm run dev
```

## الفحص
```bash
npm run check
npm run build
npm run test:domain
```

## ملاحظة
هذه الحزمة لا تحتوي على `node_modules` أو ملفات البناء الثقيلة.
