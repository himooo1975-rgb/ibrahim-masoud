import type { Company, UserSession } from '../domain/models';
import { defaultSession, seedCompany } from '../domain/seed';
export interface RawasiSnapshot { version: string; companies: Company[]; session: UserSession; updatedAt: string; }
const KEY = 'rawasi.enterprise.beta.snapshot';
export class LocalRawasiRepository {
  load(): RawasiSnapshot {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { version:'0.9.0-beta', companies:[seedCompany], session:defaultSession, updatedAt:new Date().toISOString() };
    try { return JSON.parse(raw) as RawasiSnapshot; } catch { return { version:'0.9.0-beta', companies:[seedCompany], session:defaultSession, updatedAt:new Date().toISOString() }; }
  }
  save(snapshot: RawasiSnapshot) { localStorage.setItem(KEY, JSON.stringify({ ...snapshot, updatedAt:new Date().toISOString() })); }
  saveCompany(company: Company) {
    const snap = this.load();
    const duplicate = snap.companies.some(c => c.commercialRegistration === company.commercialRegistration && c.id !== company.id);
    if (duplicate) throw new Error('السجل التجاري مسجل مسبقًا.');
    const exists = snap.companies.some(c => c.id === company.id);
    const companies = exists ? snap.companies.map(c => c.id === company.id ? company : c) : [...snap.companies, company];
    this.save({ ...snap, companies });
  }
}
