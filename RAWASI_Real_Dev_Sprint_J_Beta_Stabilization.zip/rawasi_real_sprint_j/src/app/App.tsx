import { useMemo, useState } from 'react';
import { LocalRawasiRepository } from '../repository/localRawasiRepository';
import { CompanyEditor } from '../features/company/CompanyEditor';
import { BetaMissionControl } from '../features/beta/BetaMissionControl';
import './app.css';
const repo = new LocalRawasiRepository();
export default function App() {
  const initial = useMemo(()=>repo.load(), []);
  const [snapshot, setSnapshot] = useState(initial);
  const [company, setCompany] = useState(initial.companies[0]);
  const [message, setMessage] = useState('');
  const saveCompany = () => { try { repo.saveCompany(company); const next = repo.load(); setSnapshot(next); setMessage('تم حفظ ملف الشركة وتحديث Snapshot.'); } catch (error) { setMessage(error instanceof Error ? error.message : 'تعذر الحفظ'); } };
  return <main className="app-shell">
    <aside><div className="brand"><div className="mark">ر</div><div><b>منصة الرواسي</b><small>Enterprise Beta</small></div></div><nav><button>Mission Control</button><button>Company Workspace</button><button>Financial</button><button>Classification</button><button>Reports</button></nav><div className="side-note">الإصدار: {snapshot.version}<br/>آخر تحديث: {new Date(snapshot.updatedAt).toLocaleString('ar-SA')}</div></aside>
    <section className="content"><header><div><p className="eyebrow">RAWASI Mission Control</p><h1>جاهزية المنصة التجريبية</h1><p>إغلاق رحلة العمل الأساسية قبل الانتقال إلى الإنتاج.</p></div><div className="session">{snapshot.session.name}</div></header>{message && <div className="toast">{message}</div>}<CompanyEditor company={company} onChange={setCompany} onSave={saveCompany}/><BetaMissionControl company={company}/></section>
  </main>
}
