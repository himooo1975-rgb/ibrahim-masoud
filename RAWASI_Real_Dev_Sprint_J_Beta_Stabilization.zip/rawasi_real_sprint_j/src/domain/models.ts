export type Grade = 1 | 2 | 3 | 4 | 5 | 0;
export type Permission = 'Company.Read' | 'Company.Edit' | 'Financial.Edit' | 'Classification.Run' | 'Reports.Export' | 'Users.Manage';

export interface UserSession { userId: string; name: string; role: 'admin' | 'classification_consultant' | 'financial_reviewer' | 'readonly'; permissions: Permission[]; }
export interface FinancialStatement { year: number; totalAssets: number; totalLiabilities: number; equity: number; revenue: number; netProfit: number; operatingCashFlow: number; currentAssets: number; currentLiabilities: number; }
export interface TechnicalProfile { engineers: number; technicians: number; saudiRatio: number; projectsCompleted: number; }
export interface CompanyDocument { id: string; type: string; title: string; status: 'valid' | 'missing' | 'expired' | 'review'; expiryDate?: string; }
export interface Company { id: string; name: string; commercialRegistration: string; city: string; activity: string; targetGrade: Grade; financialStatements: FinancialStatement[]; technical: TechnicalProfile; documents: CompanyDocument[]; timeline: TimelineEvent[]; }
export interface TimelineEvent { id: string; at: string; title: string; description: string; severity?: 'info' | 'success' | 'warning' | 'danger'; }
export interface FinancialRatios { currentRatio: number; debtRatio: number; debtToEquity: number; netMargin: number; roa: number; roe: number; operatingCashFlowRatio: number; qualityScore: number; }
export interface CreditRating { grade: 'A' | 'B' | 'C' | 'D' | 'E'; score: number; risk: 'منخفض' | 'متوسط' | 'مرتفع'; reasons: string[]; }
export interface ClassificationResult { grade: Grade; score: number; readiness: number; confidence: number; reasons: string[]; gaps: string[]; }
export interface Recommendation { id: string; title: string; impact: number; priority: 'عاجل' | 'مرتفع' | 'متوسط' | 'منخفض'; effort: 'منخفض' | 'متوسط' | 'مرتفع'; owner: string; }
export interface BetaCheck { id: string; area: string; title: string; status: 'passed' | 'warning' | 'failed'; details: string; }
