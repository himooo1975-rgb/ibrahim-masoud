import { useMemo } from 'react';
import type { Company } from '../../domain/models';
import { calculateCreditRating, calculateFinancialRatios } from '../../engines/financialEngine';
import { runClassification } from '../../engines/classificationEngine';
import { buildRecommendations } from '../../engines/recommendationEngine';
import { betaScore, runBetaReadiness } from '../../engines/betaReadinessEngine';
import { KpiCard } from '../../components/KpiCard';
import { Section } from '../../components/Section';
export function BetaMissionControl({ company }: { company: Company }) {
  const state = useMemo(() => {
    const statement = company.financialStatements[0];
    const ratios = calculateFinancialRatios(statement);
    const credit = calculateCreditRating(ratios);
    const classification = runClassification(company, ratios, credit);
    const recommendations = buildRecommendations(company, ratios, classification);
    const checks = runBetaReadiness(company, classification, recommendations);
    return { ratios, credit, classification, recommendations, checks, beta: betaScore(checks) };
  }, [company]);
  return <div className="grid">
    <div className="hero-panel">
      <div><p className="eyebrow">RAWASI Enterprise 0.9 Beta</p><h1>غرفة جاهزية النسخة التجريبية</h1><p>فحص متكامل لرحلة الشركة من البيانات إلى التقرير التنفيذي.</p></div>
      <div className="hero-score"><span>جاهزية Beta</span><strong>{state.beta}%</strong></div>
    </div>
    <div className="kpi-grid">
      <KpiCard title="درجة التصنيف" value={state.classification.grade ? `الدرجة ${state.classification.grade}` : 'غير مصنف'} hint={`${state.classification.score}/100`} />
      <KpiCard title="ثقة القرار" value={`${state.classification.confidence}%`} hint="اكتمال البيانات" />
      <KpiCard title="التقييم الائتماني" value={state.credit.grade} hint={`${state.credit.score}/100 - ${state.credit.risk}`} />
      <KpiCard title="التوصيات" value={state.recommendations.length} hint="إجراءات مقترحة" />
    </div>
    <Section title="قائمة إغلاق Beta">
      <div className="checklist">{state.checks.map(c => <div key={c.id} className={`check ${c.status}`}><b>{c.title}</b><span>{c.area}</span><p>{c.details}</p></div>)}</div>
    </Section>
    <Section title="أهم إجراءات التحسين">
      <div className="recommendations">{state.recommendations.map(r => <div key={r.id} className="recommendation"><b>{r.title}</b><span>الأثر المتوقع: +{r.impact} نقاط</span><small>{r.priority} • الجهد {r.effort} • المسؤول: {r.owner}</small></div>)}</div>
    </Section>
  </div>
}
