import type { FinancialRatios, FinancialStatement, CreditRating } from '../domain/models';
const safeDiv = (a: number, b: number) => b === 0 ? 0 : a / b;
export function calculateFinancialRatios(s: FinancialStatement): FinancialRatios {
  const currentRatio = safeDiv(s.currentAssets, s.currentLiabilities);
  const debtRatio = safeDiv(s.totalLiabilities, s.totalAssets);
  const debtToEquity = safeDiv(s.totalLiabilities, s.equity);
  const netMargin = safeDiv(s.netProfit, s.revenue);
  const roa = safeDiv(s.netProfit, s.totalAssets);
  const roe = safeDiv(s.netProfit, s.equity);
  const operatingCashFlowRatio = safeDiv(s.operatingCashFlow, s.currentLiabilities);
  const qualityScore = Math.round(Math.min(100, (currentRatio >= 1.5 ? 20 : 10) + (debtRatio <= .55 ? 20 : 8) + (netMargin >= .08 ? 20 : 10) + (operatingCashFlowRatio >= .7 ? 20 : 8) + (s.totalAssets > 0 && s.equity > 0 ? 20 : 0)));
  return { currentRatio, debtRatio, debtToEquity, netMargin, roa, roe, operatingCashFlowRatio, qualityScore };
}
export function calculateCreditRating(r: FinancialRatios): CreditRating {
  const score = Math.round((r.qualityScore * .55) + (Math.min(100, r.currentRatio * 35) * .15) + ((1 - Math.min(1, r.debtRatio)) * 100 * .2) + (Math.min(100, r.netMargin * 500) * .1));
  if (score >= 85) return { grade:'A', score, risk:'منخفض', reasons:['سيولة قوية','مديونية تحت السيطرة','ربحية جيدة'] };
  if (score >= 70) return { grade:'B', score, risk:'منخفض', reasons:['مركز مالي جيد مع فرص تحسين'] };
  if (score >= 55) return { grade:'C', score, risk:'متوسط', reasons:['تحتاج الشركة إلى تحسين بعض المؤشرات المالية'] };
  if (score >= 40) return { grade:'D', score, risk:'مرتفع', reasons:['مخاطر مالية مؤثرة على التصنيف'] };
  return { grade:'E', score, risk:'مرتفع', reasons:['نقص جوهري في القوة المالية أو جودة البيانات'] };
}
