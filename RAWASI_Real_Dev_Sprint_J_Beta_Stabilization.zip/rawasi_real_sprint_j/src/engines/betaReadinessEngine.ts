import type { BetaCheck, Company, ClassificationResult, Recommendation } from '../domain/models';
export function runBetaReadiness(company: Company, classification: ClassificationResult, recommendations: Recommendation[]): BetaCheck[] {
  return [
    { id:'beta-company', area:'Company', title:'ملف الشركة الأساسي', status: company.name && company.commercialRegistration ? 'passed' : 'failed', details: company.name && company.commercialRegistration ? 'بيانات الشركة الأساسية موجودة.' : 'يلزم استكمال اسم الشركة والسجل التجاري.' },
    { id:'beta-financial', area:'Financial', title:'القوائم المالية', status: company.financialStatements.length ? 'passed' : 'failed', details: company.financialStatements.length ? 'توجد سنة مالية قابلة للتحليل.' : 'لا توجد قوائم مالية.' },
    { id:'beta-technical', area:'Technical', title:'البيانات الفنية', status: company.technical.engineers > 0 ? 'passed' : 'warning', details: company.technical.engineers > 0 ? 'تم إدخال الكوادر الفنية.' : 'البيانات الفنية ناقصة.' },
    { id:'beta-docs', area:'Documents', title:'المستندات', status: company.documents.some(d=>d.status !== 'valid') ? 'warning' : 'passed', details: company.documents.some(d=>d.status !== 'valid') ? 'توجد مستندات تحتاج مراجعة.' : 'جميع المستندات الحالية صالحة.' },
    { id:'beta-classification', area:'Classification', title:'نتيجة التصنيف', status: classification.confidence >= 80 ? 'passed' : 'warning', details: `الثقة الحالية ${classification.confidence}% والدرجة المتوقعة ${classification.grade || 'غير مصنف'}.` },
    { id:'beta-recommendations', area:'Recommendations', title:'التوصيات', status: recommendations.length ? 'passed' : 'warning', details: recommendations.length ? `تم توليد ${recommendations.length} توصيات.` : 'لا توجد توصيات، راجع جودة البيانات.' },
    { id:'beta-report', area:'Reports', title:'جاهزية التقرير التنفيذي', status: classification.score > 0 ? 'passed' : 'failed', details: classification.score > 0 ? 'يمكن إنشاء تقرير تنفيذي من البيانات الحالية.' : 'لا يمكن إصدار تقرير قبل تشغيل التصنيف.' }
  ];
}
export function betaScore(checks: BetaCheck[]) { return Math.round(checks.filter(c => c.status === 'passed').length / checks.length * 100); }
