import type { ClassificationResult, Company, FinancialRatios, Recommendation } from '../domain/models';
export function buildRecommendations(company: Company, ratios: FinancialRatios, result: ClassificationResult): Recommendation[] {
  const recs: Recommendation[] = [];
  if (ratios.currentRatio < 1.5) recs.push({ id:'rec-liquidity', title:'تحسين السيولة وخفض الالتزامات قصيرة الأجل', impact:8, priority:'عاجل', effort:'متوسط', owner:'المراجع المالي' });
  if (ratios.debtRatio > .6) recs.push({ id:'rec-debt', title:'خفض نسبة المديونية أو زيادة حقوق الملكية', impact:10, priority:'مرتفع', effort:'مرتفع', owner:'الإدارة المالية' });
  if (company.technical.engineers < 20) recs.push({ id:'rec-engineers', title:'زيادة عدد المهندسين المؤهلين وربطهم بالمشاريع', impact:6, priority:'مرتفع', effort:'متوسط', owner:'المراجع الفني' });
  if (company.documents.some(d => d.status !== 'valid')) recs.push({ id:'rec-docs', title:'استكمال ومراجعة المستندات غير المعتمدة', impact:5, priority:'عاجل', effort:'منخفض', owner:'مسؤول المستندات' });
  if (result.confidence < 90) recs.push({ id:'rec-data', title:'رفع جودة البيانات قبل اعتماد القرار النهائي', impact:4, priority:'متوسط', effort:'منخفض', owner:'مستشار التصنيف' });
  return recs.sort((a,b)=>b.impact-a.impact);
}
