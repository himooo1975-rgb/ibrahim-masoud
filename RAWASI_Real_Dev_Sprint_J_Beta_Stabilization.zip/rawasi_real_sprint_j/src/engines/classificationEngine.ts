import type { ClassificationResult, Company, CreditRating, FinancialRatios } from '../domain/models';
export function runClassification(company: Company, ratios: FinancialRatios, credit: CreditRating): ClassificationResult {
  const docsScore = Math.round(company.documents.filter(d => d.status === 'valid').length / Math.max(1, company.documents.length) * 100);
  const technicalScore = Math.min(100, company.technical.engineers * 2.2 + company.technical.technicians * .8 + company.technical.saudiRatio + company.technical.projectsCompleted * 2);
  const financialScore = ratios.qualityScore;
  const creditScore = credit.score;
  const score = Math.round(financialScore * .35 + technicalScore * .3 + docsScore * .2 + creditScore * .15);
  const readiness = Math.round(score * .7 + docsScore * .3);
  const confidence = Math.round((company.financialStatements.length ? 35 : 0) + (company.technical.engineers ? 25 : 0) + (company.documents.length ? 25 : 0) + (company.commercialRegistration ? 15 : 0));
  const grade = score >= 85 ? 1 : score >= 70 ? 2 : score >= 55 ? 3 : score >= 40 ? 4 : score >= 25 ? 5 : 0;
  const reasons = [`النقاط المالية ${financialScore}/100`, `النقاط الفنية ${Math.round(technicalScore)}/100`, `اكتمال المستندات ${docsScore}%`, `التقييم الائتماني ${credit.grade}`];
  const gaps = [] as string[];
  if (company.targetGrade && grade > company.targetGrade) gaps.push(`يلزم رفع النتيجة الإجمالية للوصول إلى الدرجة ${company.targetGrade}`);
  if (docsScore < 90) gaps.push('استكمال/تحديث المستندات الناقصة يرفع جاهزية التصنيف');
  if (financialScore < 75) gaps.push('تحسين المؤشرات المالية مؤثر على التصنيف');
  if (technicalScore < 75) gaps.push('تعزيز الكوادر والخبرات الفنية مطلوب');
  return { grade, score, readiness, confidence, reasons, gaps };
}
