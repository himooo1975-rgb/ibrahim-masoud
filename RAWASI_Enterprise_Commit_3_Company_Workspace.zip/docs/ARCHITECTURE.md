# RAWASI Platform Architecture

## Vision
RAWASI is a contractor classification intelligence platform focused on assessment, diagnosis, improvement, simulation, and submission readiness.

## Layers
1. Web Application
2. Core Engines
3. Rules and Knowledge Base
4. Future API and Database

## Engines
- Financial Engine
- Credit Engine
- Classification Engine
- Decision Engine
- Recommendation Engine
- Document Engine
