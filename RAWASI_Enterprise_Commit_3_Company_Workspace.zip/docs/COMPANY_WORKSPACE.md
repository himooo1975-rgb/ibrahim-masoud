# Company Workspace

ملف الشركة في الرواسي هو مساحة عمل موحدة للمستشار. الهدف ليس تخزين البيانات فقط، بل الإجابة على خمسة أسئلة:

1. هل بيانات الشركة الأساسية مكتملة؟
2. ماذا تقول القوائم المالية؟
3. هل الجاهزية الفنية كافية؟
4. هل ملف المستندات قابل للتقديم؟
5. ما أقرب إجراء للوصول إلى الدرجة المستهدفة؟

## Centers
- Company Profile Center
- Financial Center
- Technical Center
- Documents Center
- Classification Center
- Timeline

## Next
في Commit 4 سيتم البدء في تحويل الدليل الاسترشادي إلى Rule Book أكثر وضوحًا داخل Rules Engine.
