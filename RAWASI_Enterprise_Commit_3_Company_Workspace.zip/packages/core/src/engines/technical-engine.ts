import type { CompanySize, ScoredFactor, TechnicalInput } from '../types';

type RuleRow = { min: number; score: number };
type RuleTable = Record<CompanySize, RuleRow[]>;

const engineersRules: RuleTable = {
  micro: [{ min: 48, score: 30 }, { min: 32, score: 27.5 }, { min: 22, score: 18 }, { min: 16, score: 13.5 }, { min: 0.5, score: 5 }],
  small: [{ min: 18, score: 30 }, { min: 7, score: 27.5 }, { min: 5, score: 18 }, { min: 2, score: 13.5 }, { min: 0.5, score: 5 }],
  medium: [{ min: 6, score: 30 }, { min: 4, score: 27.5 }, { min: 2, score: 18 }, { min: 1, score: 13.5 }, { min: 0.5, score: 5 }],
  large: [{ min: 6, score: 30 }, { min: 4, score: 27.5 }, { min: 2, score: 18 }, { min: 1, score: 13.5 }, { min: 0.5, score: 5 }]
};

const techniciansRules: RuleTable = {
  micro: [{ min: 49, score: 30 }, { min: 32, score: 27.5 }, { min: 19, score: 18 }, { min: 16, score: 13.5 }, { min: 0.5, score: 5 }],
  small: [{ min: 12, score: 30 }, { min: 7, score: 27.5 }, { min: 4, score: 18 }, { min: 2, score: 13.5 }, { min: 0.5, score: 5 }],
  medium: [{ min: 4, score: 30 }, { min: 3, score: 27.5 }, { min: 2, score: 18 }, { min: 1, score: 13.5 }, { min: 0.5, score: 5 }],
  large: [{ min: 4, score: 30 }, { min: 3, score: 27.5 }, { min: 2, score: 18 }, { min: 1, score: 13.5 }, { min: 0.5, score: 5 }]
};

function scoreByRule(value: number, table: RuleTable, size: CompanySize) {
  return table[size].find(row => value >= row.min)?.score ?? 0;
}

function nearestNext(value: number, table: RuleTable, size: CompanySize) {
  const rows = [...table[size]].sort((a, b) => a.min - b.min);
  return rows.find(row => value < row.min);
}

export function analyzeTechnical(input: TechnicalInput) {
  const engineersScore = scoreByRule(input.engineersPercent, engineersRules, input.companySize);
  const techniciansScore = scoreByRule(input.techniciansPercent, techniciansRules, input.companySize);
  const experienceScore = Math.min(20, input.engineersExperience + input.techniciansExperience);
  const saudizationScore = Math.min(10, input.saudizationPercent / 5 + input.saudiEngineersPercent / 3);

  const factors: ScoredFactor[] = [
    {
      key: 'engineersPercent',
      label: 'نسبة المهندسين',
      score: engineersScore,
      maxScore: 30,
      status: engineersScore >= 27.5 ? 'good' : engineersScore >= 18 ? 'warning' : 'critical',
      valueLabel: `${input.engineersPercent}%`,
      explanation: 'معيار فني أساسي من معايير مجال التشييد والبناء.',
      recommendation: nearestNext(input.engineersPercent, engineersRules, input.companySize) ? `رفع النسبة إلى ${nearestNext(input.engineersPercent, engineersRules, input.companySize)?.min}% على الأقل لتحسين النقاط.` : undefined,
      expectedImpact: Math.max(0, 30 - engineersScore)
    },
    {
      key: 'techniciansPercent',
      label: 'نسبة الفنيين',
      score: techniciansScore,
      maxScore: 30,
      status: techniciansScore >= 27.5 ? 'good' : techniciansScore >= 18 ? 'warning' : 'critical',
      valueLabel: `${input.techniciansPercent}%`,
      explanation: 'معيار فني أساسي يقيس جاهزية الكوادر الفنية للتنفيذ.',
      recommendation: nearestNext(input.techniciansPercent, techniciansRules, input.companySize) ? `رفع نسبة الفنيين إلى ${nearestNext(input.techniciansPercent, techniciansRules, input.companySize)?.min}% على الأقل.` : undefined,
      expectedImpact: Math.max(0, 30 - techniciansScore)
    },
    {
      key: 'experience',
      label: 'خبرات الكوادر',
      score: experienceScore,
      maxScore: 20,
      status: experienceScore >= 16 ? 'good' : experienceScore >= 10 ? 'warning' : 'critical',
      valueLabel: `${input.engineersExperience + input.techniciansExperience} سنة مركبة`,
      explanation: 'يجمع بين خبرات المهندسين والفنيين كمؤشر جاهزية تنفيذية.',
      recommendation: experienceScore < 16 ? 'تعزيز الفريق بخبرات تنفيذية أعلى أو توثيق الخبرات القائمة.' : undefined,
      expectedImpact: experienceScore < 16 ? 4 : 0
    },
    {
      key: 'saudization',
      label: 'السعودة والكوادر السعودية',
      score: saudizationScore,
      maxScore: 10,
      status: saudizationScore >= 8 ? 'good' : saudizationScore >= 5 ? 'warning' : 'critical',
      valueLabel: `${input.saudizationPercent}% سعودة`,
      explanation: 'مؤشر إضافي يمكن أن يرفع الدرجة الفنية ويعزز جاهزية الملف.',
      recommendation: saudizationScore < 8 ? 'رفع السعودة أو نسبة المهندسين السعوديين لتحسين الجاهزية الفنية.' : undefined,
      expectedImpact: saudizationScore < 8 ? 3 : 0
    }
  ];

  const score = Math.round(factors.reduce((sum, factor) => sum + factor.score, 0));
  return { score, factors };
}
