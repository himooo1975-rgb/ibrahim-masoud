export function buildRecommendations(metrics: { liquidity: number; leverage: number; profitability: number }) {
  const recommendations: string[] = [];
  if (metrics.liquidity < 0.8) recommendations.push('تحسين السيولة ورفع النقد المتاح مقارنة بالالتزامات.');
  if (metrics.leverage > 0.45) recommendations.push('خفض المديونية أو زيادة حقوق الملكية.');
  if (metrics.profitability < 0.08) recommendations.push('تحسين هامش الربحية قبل التقديم.');
  return recommendations.length ? recommendations : ['الوضع المالي جيد، ركز على اكتمال المستندات والجاهزية الفنية.'];
}
