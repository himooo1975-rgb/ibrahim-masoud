import type { Company } from '../types';
import { buildDecision } from './decision-engine';

export type SimulationPatch = {
  currentAssetsDelta?: number;
  currentLiabilitiesDelta?: number;
  liabilitiesDelta?: number;
  equityDelta?: number;
  netProfitDelta?: number;
  engineersPercentDelta?: number;
  techniciansPercentDelta?: number;
};

export function simulateCompany(company: Company, patch: SimulationPatch) {
  const simulated: Company = {
    ...company,
    financial: {
      ...company.financial,
      currentAssets: Math.max(0, company.financial.currentAssets + (patch.currentAssetsDelta ?? 0)),
      currentLiabilities: Math.max(0, company.financial.currentLiabilities + (patch.currentLiabilitiesDelta ?? 0)),
      liabilities: Math.max(0, company.financial.liabilities + (patch.liabilitiesDelta ?? 0)),
      equity: Math.max(0, company.financial.equity + (patch.equityDelta ?? 0)),
      netProfit: Math.max(0, company.financial.netProfit + (patch.netProfitDelta ?? 0))
    },
    technical: {
      ...company.technical,
      engineersPercent: Math.max(0, company.technical.engineersPercent + (patch.engineersPercentDelta ?? 0)),
      techniciansPercent: Math.max(0, company.technical.techniciansPercent + (patch.techniciansPercentDelta ?? 0))
    }
  };
  return { simulated, decision: buildDecision(simulated) };
}
