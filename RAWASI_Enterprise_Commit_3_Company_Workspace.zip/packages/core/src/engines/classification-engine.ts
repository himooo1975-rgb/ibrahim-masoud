import type { ClassificationGrade } from '../types';

export function gradeFromScore(score: number): ClassificationGrade {
  if (score >= 85) return 1;
  if (score >= 70) return 2;
  if (score >= 55) return 3;
  if (score >= 40) return 4;
  return 5;
}

export function gradeLabel(grade: ClassificationGrade): string {
  return `الدرجة ${grade}`;
}

export function targetScoreThreshold(grade: ClassificationGrade): number {
  const thresholds: Record<ClassificationGrade, number> = { 1: 85, 2: 70, 3: 55, 4: 40, 5: 20 };
  return thresholds[grade];
}
