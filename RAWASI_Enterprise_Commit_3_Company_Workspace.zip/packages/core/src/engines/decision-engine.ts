import type { Company, DecisionResult, ScoredFactor } from '../types';
import { gradeFromScore, targetScoreThreshold } from './classification-engine';
import { analyzeDocuments } from './document-engine';
import { analyzeFinancial } from './financial-engine';
import { analyzeTechnical } from './technical-engine';

function byImpact(a: ScoredFactor, b: ScoredFactor) {
  return (b.expectedImpact ?? 0) - (a.expectedImpact ?? 0);
}

export function buildDecision(company: Company): DecisionResult {
  const financial = analyzeFinancial(company.financial);
  const technical = analyzeTechnical(company.technical);
  const documents = analyzeDocuments(company.documents);

  const financialWeighted = financial.score * 0.45;
  const technicalWeighted = technical.score * 0.4;
  const documentWeighted = documents.score * 0.15;
  const totalScore = Math.round(financialWeighted + technicalWeighted + documentWeighted);
  const grade = gradeFromScore(totalScore);
  const targetThreshold = targetScoreThreshold(company.targetGrade);
  const readiness = Math.min(100, Math.round((totalScore / targetThreshold) * 100));

  const allFactors = [...financial.factors, ...technical.factors, ...documents.missingFactors];
  const blockers = allFactors.filter(item => item.status === 'critical').sort(byImpact);
  const recommendations = allFactors.filter(item => item.recommendation).sort(byImpact).slice(0, 6);
  const strengths = allFactors.filter(item => item.status === 'good').slice(0, 5);
  const targetAchieved = grade <= company.targetGrade;

  const executiveSummary = targetAchieved
    ? `الشركة تحقق الدرجة المستهدفة ${company.targetGrade} وفق البيانات الحالية، مع ضرورة الحفاظ على اكتمال المستندات قبل التقديم.`
    : `الشركة لا تحقق الدرجة المستهدفة ${company.targetGrade} حاليًا. أقرب مسار للتحسين هو معالجة ${recommendations[0]?.label ?? 'العوامل الحرجة'} ثم إعادة التقييم.`;

  return {
    financialScore: financial.score,
    technicalScore: technical.score,
    documentScore: documents.score,
    totalScore,
    grade,
    targetGrade: company.targetGrade,
    targetAchieved,
    readiness,
    blockers,
    strengths,
    recommendations,
    executiveSummary
  };
}
