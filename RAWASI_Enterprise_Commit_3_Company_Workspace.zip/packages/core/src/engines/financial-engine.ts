import type { FinancialInput, ScoredFactor } from '../types';

function safeRatio(numerator: number, denominator: number, fallback = 0) {
  return denominator > 0 ? numerator / denominator : fallback;
}

export function analyzeFinancial(input: FinancialInput) {
  const currentRatio = safeRatio(input.currentAssets || input.cash, input.currentLiabilities || input.liabilities);
  const cashCoverage = safeRatio(input.cash, input.currentLiabilities || input.liabilities);
  const leverage = safeRatio(input.liabilities, input.assets, 1);
  const profitability = safeRatio(input.netProfit, input.revenue);
  const equityStrength = safeRatio(input.equity, input.assets);
  const cashFlowMargin = safeRatio(input.operatingCashFlow, input.revenue);

  const factors: ScoredFactor[] = [
    {
      key: 'currentRatio',
      label: 'السيولة الجارية',
      score: Math.min(20, currentRatio * 12),
      maxScore: 20,
      status: currentRatio >= 1.2 ? 'good' : currentRatio >= 0.8 ? 'warning' : 'critical',
      valueLabel: currentRatio.toFixed(2),
      explanation: 'تقيس قدرة الشركة على الوفاء بالالتزامات قصيرة الأجل.',
      recommendation: currentRatio < 1.2 ? 'رفع الأصول المتداولة أو تخفيض الالتزامات المتداولة قبل التقديم.' : undefined,
      expectedImpact: currentRatio < 1.2 ? 5 : 0
    },
    {
      key: 'leverage',
      label: 'المديونية',
      score: Math.min(25, Math.max(0, (1 - leverage) * 35)),
      maxScore: 25,
      status: leverage <= 0.45 ? 'good' : leverage <= 0.65 ? 'warning' : 'critical',
      valueLabel: `${(leverage * 100).toFixed(1)}%`,
      explanation: 'ارتفاع المديونية يقلل مرونة الشركة المالية وقدرتها على تحمل الالتزامات.',
      recommendation: leverage > 0.45 ? 'خفض الالتزامات أو دعم حقوق الملكية لرفع درجة الجدارة.' : undefined,
      expectedImpact: leverage > 0.45 ? 7 : 0
    },
    {
      key: 'profitability',
      label: 'الربحية',
      score: Math.min(25, Math.max(0, profitability * 220)),
      maxScore: 25,
      status: profitability >= 0.1 ? 'good' : profitability >= 0.05 ? 'warning' : 'critical',
      valueLabel: `${(profitability * 100).toFixed(1)}%`,
      explanation: 'توضح قدرة الشركة على تحقيق أرباح من إيراداتها.',
      recommendation: profitability < 0.1 ? 'تحسين هامش الربح ومراجعة تكلفة التنفيذ قبل طلب درجة أعلى.' : undefined,
      expectedImpact: profitability < 0.1 ? 6 : 0
    },
    {
      key: 'equityStrength',
      label: 'قوة حقوق الملكية',
      score: Math.min(20, Math.max(0, equityStrength * 34)),
      maxScore: 20,
      status: equityStrength >= 0.45 ? 'good' : equityStrength >= 0.3 ? 'warning' : 'critical',
      valueLabel: `${(equityStrength * 100).toFixed(1)}%`,
      explanation: 'كلما ارتفعت حقوق الملكية مقارنة بالأصول زادت قوة المركز المالي.',
      recommendation: equityStrength < 0.45 ? 'دعم رأس المال أو الأرباح المبقاة لتحسين قوة المركز المالي.' : undefined,
      expectedImpact: equityStrength < 0.45 ? 8 : 0
    },
    {
      key: 'cashFlowMargin',
      label: 'التدفق النقدي التشغيلي',
      score: Math.min(10, Math.max(0, cashFlowMargin * 120)),
      maxScore: 10,
      status: cashFlowMargin >= 0.08 ? 'good' : cashFlowMargin >= 0.03 ? 'warning' : 'critical',
      valueLabel: `${(cashFlowMargin * 100).toFixed(1)}%`,
      explanation: 'يعكس جودة الأرباح وقدرة النشاط على توليد نقد.',
      recommendation: cashFlowMargin < 0.08 ? 'تحسين التحصيل وجدولة المدفوعات لرفع النقد التشغيلي.' : undefined,
      expectedImpact: cashFlowMargin < 0.08 ? 4 : 0
    }
  ];

  const score = Math.round(factors.reduce((sum, factor) => sum + factor.score, 0));
  return { currentRatio, cashCoverage, leverage, profitability, equityStrength, cashFlowMargin, score, factors };
}
