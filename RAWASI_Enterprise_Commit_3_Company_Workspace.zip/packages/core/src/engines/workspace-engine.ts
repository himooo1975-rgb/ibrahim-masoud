import type { Company, TimelineEvent, WorkspaceCenter, WorkspaceSummary } from '../types';
import { buildDecision } from './decision-engine';
import { analyzeDocuments } from './document-engine';
import { analyzeFinancial } from './financial-engine';
import { analyzeTechnical } from './technical-engine';

function statusFromScore(score: number): WorkspaceCenter['status'] {
  if (score >= 80) return 'good';
  if (score >= 55) return 'warning';
  return 'critical';
}

function seedTimeline(company: Company): TimelineEvent[] {
  const now = new Date().toISOString();
  const base: TimelineEvent[] = [
    {
      id: 'created',
      at: now,
      title: 'تم إنشاء ملف الشركة',
      description: `تم فتح مساحة عمل التصنيف للشركة ${company.name}.`,
      type: 'company'
    },
    {
      id: 'decision',
      at: now,
      title: 'تم تشغيل محرك القرار',
      description: 'تم احتساب الدرجة المتوقعة وخطة التحسين من البيانات الحالية.',
      type: 'classification'
    }
  ];
  return company.timeline?.length ? company.timeline : base;
}

export function buildWorkspace(company: Company): WorkspaceSummary {
  const decision = buildDecision(company);
  const financial = analyzeFinancial(company.financial);
  const technical = analyzeTechnical(company.technical);
  const documents = analyzeDocuments(company.documents);

  const centers: WorkspaceCenter[] = [
    {
      key: 'profile',
      title: 'بيانات الشركة',
      score: company.name && company.crNumber ? 90 : 45,
      status: company.name && company.crNumber ? 'good' : 'critical',
      summary: company.name && company.crNumber ? 'البيانات الأساسية متاحة وقابلة للاستخدام في ملف التصنيف.' : 'ينقص استكمال بيانات الشركة الأساسية.',
      nextAction: company.name && company.crNumber ? 'مراجعة الأنشطة والدرجة المستهدفة.' : 'استكمال اسم الشركة والسجل التجاري.'
    },
    {
      key: 'financial',
      title: 'المركز المالي',
      score: financial.score,
      status: statusFromScore(financial.score),
      summary: `التقييم المالي الحالي ${financial.score}/100 بناءً على السيولة والمديونية والربحية وحقوق الملكية.`,
      nextAction: financial.factors.find(item => item.recommendation)?.recommendation ?? 'الحفاظ على جودة القوائم والمؤشرات الحالية.'
    },
    {
      key: 'technical',
      title: 'المركز الفني',
      score: technical.score,
      status: statusFromScore(technical.score),
      summary: `التقييم الفني الحالي ${technical.score}/100 بناءً على الكوادر والخبرات والسعودة.`,
      nextAction: technical.factors.find(item => item.recommendation)?.recommendation ?? 'توثيق الخبرات والكوادر الداعمة للتصنيف.'
    },
    {
      key: 'documents',
      title: 'مركز المستندات',
      score: documents.score,
      status: statusFromScore(documents.score),
      summary: `اكتمال المستندات ${documents.completed} من ${documents.required} مستندات مطلوبة.`,
      nextAction: documents.missingFactors[0]?.recommendation ?? 'الملف المستندي مكتمل مبدئيًا.'
    },
    {
      key: 'classification',
      title: 'مركز التصنيف',
      score: decision.readiness,
      status: decision.targetAchieved ? 'good' : statusFromScore(decision.readiness),
      summary: `الدرجة المتوقعة ${decision.grade} والجاهزية للهدف ${decision.readiness}%.`,
      nextAction: decision.recommendations[0]?.recommendation ?? 'إصدار تقرير تنفيذي ومراجعة قبل التقديم.'
    }
  ];

  const completion = Math.round(centers.reduce((sum, item) => sum + item.score, 0) / centers.length);
  return {
    centers,
    completion,
    nextBestAction: decision.recommendations[0]?.recommendation ?? 'ابدأ بمراجعة التقرير التنفيذي وتجهيز ملف التقديم.',
    timeline: seedTimeline(company)
  };
}
