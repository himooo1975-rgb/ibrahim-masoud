import type { DocumentItem, ScoredFactor } from '../types';

export function analyzeDocuments(documents: DocumentItem[]) {
  const required = documents.filter(doc => doc.required);
  const present = required.filter(doc => doc.present);
  const score = required.length ? Math.round((present.length / required.length) * 100) : 100;
  const missingFactors: ScoredFactor[] = required
    .filter(doc => !doc.present)
    .map(doc => ({
      key: `doc-${doc.id}`,
      label: doc.name,
      score: 0,
      maxScore: 1,
      status: 'critical',
      valueLabel: 'غير مكتمل',
      explanation: 'مستند مطلوب ضمن جاهزية ملف التصنيف.',
      recommendation: `استكمال ${doc.name} قبل التقديم.`,
      expectedImpact: 3
    }));
  return { score, missingFactors, completed: present.length, required: required.length };
}
