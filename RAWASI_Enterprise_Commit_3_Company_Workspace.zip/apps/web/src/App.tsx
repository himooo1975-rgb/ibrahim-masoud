import { useEffect, useMemo, useState } from 'react';
import type { Company, ClassificationGrade, FinancialInput, TechnicalInput, TimelineEvent } from '@rawasi/core';
import { buildDecision, buildWorkspace, gradeLabel, simulateCompany } from '@rawasi/core';
import { demoCompany } from './data/demoCompany';
import { loadCompany, resetCompany, saveCompany } from './services/storage';
import { FactorList } from './components/FactorList';
import { KpiCard } from './components/KpiCard';

const financialLabels: Record<keyof FinancialInput, string> = {
  revenue: 'الإيرادات',
  netProfit: 'صافي الربح',
  assets: 'إجمالي الأصول',
  liabilities: 'إجمالي الالتزامات',
  equity: 'حقوق الملكية',
  cash: 'النقد وما في حكمه',
  currentAssets: 'الأصول المتداولة',
  currentLiabilities: 'الالتزامات المتداولة',
  operatingCashFlow: 'التدفق النقدي التشغيلي'
};

const technicalLabels: Record<keyof TechnicalInput, string> = {
  companySize: 'حجم المنشأة',
  engineersPercent: 'نسبة المهندسين %',
  techniciansPercent: 'نسبة الفنيين %',
  engineersExperience: 'متوسط خبرات المهندسين',
  techniciansExperience: 'متوسط خبرات الفنيين',
  saudizationPercent: 'نسبة السعودة %',
  saudiEngineersPercent: 'نسبة المهندسين السعوديين %'
};

const statusLabel = { good: 'جاهز', warning: 'يحتاج تحسين', critical: 'حرج' } as const;

function timelineTypeLabel(type: TimelineEvent['type']) {
  const labels: Record<TimelineEvent['type'], string> = {
    company: 'شركة',
    financial: 'مالي',
    technical: 'فني',
    document: 'مستند',
    classification: 'تصنيف',
    system: 'نظام'
  };
  return labels[type];
}

export function App() {
  const [company, setCompany] = useState<Company>(() => loadCompany(demoCompany));
  const [simPatch, setSimPatch] = useState({ equityDelta: 0, liabilitiesDelta: 0, currentAssetsDelta: 0, engineersPercentDelta: 0 });
  const decision = useMemo(() => buildDecision(company), [company]);
  const workspace = useMemo(() => buildWorkspace(company), [company]);
  const simulation = useMemo(() => simulateCompany(company, simPatch), [company, simPatch]);

  useEffect(() => saveCompany(company), [company]);

  const updateCompany = <K extends keyof Company>(key: K, value: Company[K]) => {
    setCompany(prev => ({ ...prev, [key]: value }));
  };

  const updateFinancial = (key: keyof FinancialInput, value: number) => {
    setCompany(prev => ({ ...prev, financial: { ...prev.financial, [key]: Number.isFinite(value) ? value : 0 } }));
  };

  const updateTechnical = (key: keyof TechnicalInput, value: number | TechnicalInput['companySize']) => {
    setCompany(prev => ({ ...prev, technical: { ...prev.technical, [key]: value } }));
  };

  const toggleDocument = (id: string) => {
    setCompany(prev => ({
      ...prev,
      documents: prev.documents.map(doc => doc.id === id ? { ...doc, present: !doc.present } : doc),
      timeline: [
        ...(prev.timeline ?? []),
        {
          id: `doc-${Date.now()}`,
          at: new Date().toISOString(),
          title: 'تحديث حالة مستند',
          description: `تم تغيير حالة المستند: ${prev.documents.find(doc => doc.id === id)?.name ?? id}.`,
          type: 'document'
        }
      ]
    }));
  };

  return (
    <main className="app-shell">
      <aside className="sidebar">
        <div className="brand-mark">ر</div>
        <h1>منصة الرواسي</h1>
        <p>مساحة عمل متخصصة لتجهيز ورفع تصنيف شركات المقاولات.</p>
        <nav>
          <a href="#operations">غرفة العمليات</a>
          <a href="#workspace">Workspace</a>
          <a href="#company">ملف الشركة</a>
          <a href="#finance">المركز المالي</a>
          <a href="#technical">المركز الفني</a>
          <a href="#documents">المستندات</a>
          <a href="#classification">التصنيف</a>
          <a href="#timeline">السجل الزمني</a>
          <a href="#simulator">المحاكي</a>
        </nav>
      </aside>

      <section className="content">
        <header className="hero" id="operations">
          <div>
            <span className="eyebrow">RAWASI Enterprise • Commit 3</span>
            <h2>Company Workspace</h2>
            <p>{decision.executiveSummary}</p>
            <div className="hero-actions">
              <button onClick={() => { resetCompany(); setCompany(demoCompany); }}>إعادة بيانات العرض</button>
              <button className="primary" onClick={() => window.print()}>طباعة ملخص تنفيذي</button>
            </div>
          </div>
          <div className="score-card">
            <span>الدرجة المتوقعة</span>
            <strong>{gradeLabel(decision.grade)}</strong>
            <small>اكتمال مساحة العمل: {workspace.completion}%</small>
            <small>الجاهزية للهدف: {decision.readiness}%</small>
          </div>
        </header>

        <section className="kpi-grid">
          <KpiCard title="النقاط الإجمالية" value={`${decision.totalScore}/100`} hint="مالية + فنية + مستندات" tone="blue" />
          <KpiCard title="الدرجة المستهدفة" value={gradeLabel(decision.targetGrade)} hint={decision.targetAchieved ? 'محققة حاليًا' : 'تحتاج خطة تحسين'} tone={decision.targetAchieved ? 'green' : 'gold'} />
          <KpiCard title="اكتمال Workspace" value={`${workspace.completion}%`} hint="ملف الشركة + المراكز" tone={workspace.completion >= 80 ? 'green' : 'gold'} />
          <KpiCard title="الإجراء التالي" value="Next" hint={workspace.nextBestAction} tone="blue" />
        </section>

        <section className="card" id="workspace">
          <h3>مراكز ملف الشركة</h3>
          <p className="muted">هذه المراكز تمنح المستشار صورة واحدة عن وضع الشركة بدل التنقل بين شاشات متفرقة.</p>
          <div className="center-grid">
            {workspace.centers.map(center => (
              <article className={`center-card status-${center.status}`} key={center.key}>
                <div>
                  <span>{statusLabel[center.status]}</span>
                  <h4>{center.title}</h4>
                  <p>{center.summary}</p>
                </div>
                <strong>{center.score}%</strong>
                <small>{center.nextAction}</small>
              </article>
            ))}
          </div>
        </section>

        <section className="grid two" id="company">
          <article className="card">
            <h3>بيانات الشركة</h3>
            <div className="form-grid">
              <label>اسم الشركة<input value={company.name} onChange={event => updateCompany('name', event.target.value)} /></label>
              <label>السجل التجاري<input value={company.crNumber} onChange={event => updateCompany('crNumber', event.target.value)} /></label>
              <label>رقم المنشأة<input value={company.entityNumber ?? ''} onChange={event => updateCompany('entityNumber', event.target.value)} /></label>
              <label>المدينة<input value={company.city ?? ''} onChange={event => updateCompany('city', event.target.value)} /></label>
              <label>عدد الفروع<input type="number" value={company.branches ?? 0} onChange={event => updateCompany('branches', Number(event.target.value))} /></label>
              <label>النشاط الرئيسي<input value={company.mainActivity ?? ''} onChange={event => updateCompany('mainActivity', event.target.value)} /></label>
              <label>سنة القوائم المالية<input type="number" value={company.financialYear ?? new Date().getFullYear()} onChange={event => updateCompany('financialYear', Number(event.target.value))} /></label>
              <label>الدرجة المستهدفة
                <select value={company.targetGrade} onChange={event => updateCompany('targetGrade', Number(event.target.value) as ClassificationGrade)}>
                  {[1,2,3,4,5].map(grade => <option value={grade} key={grade}>الدرجة {grade}</option>)}
                </select>
              </label>
            </div>
          </article>

          <article className="card" id="classification">
            <h3>مركز التصنيف</h3>
            <div className="classification-path">
              <div><span>الدرجة الحالية</span><strong>{gradeLabel(decision.grade)}</strong></div>
              <div className="path-line"><i style={{ width: `${Math.min(100, decision.readiness)}%` }} /></div>
              <div><span>الدرجة المستهدفة</span><strong>{gradeLabel(decision.targetGrade)}</strong></div>
            </div>
            <p className="muted">{workspace.nextBestAction}</p>
          </article>
        </section>

        <section className="grid two">
          <article className="card" id="finance">
            <h3>المركز المالي</h3>
            <div className="form-grid">
              {(Object.keys(company.financial) as Array<keyof FinancialInput>).map(key => (
                <label key={key}><span>{financialLabels[key]}</span><input type="number" value={company.financial[key]} onChange={event => updateFinancial(key, Number(event.target.value))} /></label>
              ))}
            </div>
          </article>

          <article className="card" id="technical">
            <h3>المركز الفني</h3>
            <label>حجم المنشأة
              <select value={company.technical.companySize} onChange={event => updateTechnical('companySize', event.target.value as TechnicalInput['companySize'])}>
                <option value="micro">متناهية الصغر</option>
                <option value="small">صغيرة</option>
                <option value="medium">متوسطة</option>
                <option value="large">كبيرة</option>
              </select>
            </label>
            <div className="form-grid">
              {(Object.keys(company.technical) as Array<keyof TechnicalInput>).filter(key => key !== 'companySize').map(key => (
                <label key={key}><span>{technicalLabels[key]}</span><input type="number" value={company.technical[key] as number} onChange={event => updateTechnical(key, Number(event.target.value))} /></label>
              ))}
            </div>
          </article>
        </section>

        <section className="grid two" id="documents">
          <article className="card">
            <h3>مركز المستندات</h3>
            {company.documents.map(doc => (
              <label className="check-row" key={doc.id}>
                <input type="checkbox" checked={doc.present} onChange={() => toggleDocument(doc.id)} />
                <span>{doc.name}</span>
                <small>{doc.category ?? 'classification'}</small>
              </label>
            ))}
          </article>
          <article className="card">
            <h3>جاهزية ملف التقديم</h3>
            <FactorList title="العوائق الحرجة" items={decision.blockers} empty="لا توجد عوائق حرجة في البيانات الحالية." />
          </article>
        </section>

        <section className="grid three" id="decision">
          <FactorList title="العوائق الحرجة" items={decision.blockers} empty="لا توجد عوائق حرجة في البيانات الحالية." />
          <FactorList title="نقاط القوة" items={decision.strengths} empty="أدخل بيانات أكثر لاستخراج نقاط القوة." />
          <FactorList title="خطة رفع التصنيف" items={decision.recommendations} empty="لا توجد توصيات مطلوبة حاليًا." />
        </section>

        <section className="card" id="timeline">
          <h3>السجل الزمني لملف الشركة</h3>
          <div className="timeline">
            {workspace.timeline.map(event => (
              <article key={event.id}>
                <span>{timelineTypeLabel(event.type)}</span>
                <div>
                  <strong>{event.title}</strong>
                  <p>{event.description}</p>
                  <small>{new Date(event.at).toLocaleString('ar-SA')}</small>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="card" id="simulator">
          <h3>محاكي ماذا لو؟</h3>
          <p className="muted">عدّل السيناريو دون تغيير بيانات الشركة الأصلية، وشاهد أثره على الدرجة.</p>
          <div className="simulator-grid">
            <label>زيادة حقوق الملكية<input type="number" value={simPatch.equityDelta} onChange={event => setSimPatch(prev => ({ ...prev, equityDelta: Number(event.target.value) }))} /></label>
            <label>تخفيض الالتزامات<input type="number" value={Math.abs(simPatch.liabilitiesDelta)} onChange={event => setSimPatch(prev => ({ ...prev, liabilitiesDelta: -Math.abs(Number(event.target.value)) }))} /></label>
            <label>زيادة الأصول المتداولة<input type="number" value={simPatch.currentAssetsDelta} onChange={event => setSimPatch(prev => ({ ...prev, currentAssetsDelta: Number(event.target.value) }))} /></label>
            <label>زيادة نسبة المهندسين<input type="number" value={simPatch.engineersPercentDelta} onChange={event => setSimPatch(prev => ({ ...prev, engineersPercentDelta: Number(event.target.value) }))} /></label>
            <div className="simulation-result">
              <span>النتيجة بعد السيناريو</span>
              <strong>{gradeLabel(simulation.decision.grade)}</strong>
              <small>{simulation.decision.totalScore}/100 نقطة</small>
            </div>
          </div>
        </section>
      </section>
    </main>
  );
}
