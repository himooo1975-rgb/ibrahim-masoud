type KpiCardProps = {
  title: string;
  value: string | number;
  hint?: string;
  tone?: 'blue' | 'green' | 'gold' | 'red';
};

export function KpiCard({ title, value, hint, tone = 'blue' }: KpiCardProps) {
  return (
    <article className={`kpi-card tone-${tone}`}>
      <span>{title}</span>
      <strong>{value}</strong>
      {hint ? <small>{hint}</small> : null}
    </article>
  );
}
