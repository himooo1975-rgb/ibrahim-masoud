import type { Company } from '@rawasi/core';

const STORAGE_KEY = 'rawasi.enterprise.company.v1';

export function loadCompany(fallback: Company): Company {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return fallback;
    return { ...fallback, ...JSON.parse(raw) } as Company;
  } catch {
    return fallback;
  }
}

export function saveCompany(company: Company) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(company));
}

export function resetCompany() {
  localStorage.removeItem(STORAGE_KEY);
}
