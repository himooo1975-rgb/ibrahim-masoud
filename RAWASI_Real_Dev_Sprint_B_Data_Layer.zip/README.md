# RAWASI Platform - Real Development Sprint B

Sprint B يضيف طبقة بيانات مؤسسية حقيقية فوق Sprint A.

## التشغيل

```bash
npm install
npm run dev
```

## الفحص

```bash
npm run check
npm run build
```

## الجديد
- RawasiRepository.
- حفظ متعدد الشركات.
- منع تكرار السجل التجاري.
- تصدير واستيراد نسخة احتياطية.
- سجل عمليات Audit Log.
- شاشة Company Workspace قابلة للتعديل والحفظ.

## ملاحظة
هذه النسخة لا تحتوي على `node_modules` ويجب تشغيل `npm install` بعد الرفع أو التحميل.
