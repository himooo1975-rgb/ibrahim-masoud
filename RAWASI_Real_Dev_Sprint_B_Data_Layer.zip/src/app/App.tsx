import { useMemo, useState } from 'react';
import { Building2, Database, Download, FileText, LineChart, RefreshCcw, Target, Upload } from 'lucide-react';
import { Card } from '../components/Card';
import { classifyCompany } from '../engines/classification/classificationEngine';
import { buildDecision } from '../engines/decision/decisionEngine';
import { prioritizeRecommendations } from '../engines/recommendation/recommendationEngine';
import { createCompanyDraft } from '../data/defaults';
import { RawasiRepository } from '../data/rawasiRepository';
import { CompanyForm } from '../features/companies/CompanyForm';
import { CompanyList } from '../features/companies/CompanyList';
import { AuditTimeline } from '../features/companies/AuditTimeline';
import type { Company, RawasiSnapshot } from '../lib/types';

const repository = new RawasiRepository();

function downloadTextFile(filename: string, content: string) {
  const blob = new Blob([content], { type: 'application/json;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(url);
}

export function App() {
  const [snapshot, setSnapshot] = useState<RawasiSnapshot>(() => repository.load());
  const [selectedCompanyId, setSelectedCompanyId] = useState(() => snapshot.companies[0]?.id ?? '');
  const selectedCompany = snapshot.companies.find((company) => company.id === selectedCompanyId) ?? snapshot.companies[0] ?? createCompanyDraft();
  const [draft, setDraft] = useState<Company>(selectedCompany);
  const [message, setMessage] = useState('Sprint B: طبقة البيانات المؤسسية تعمل الآن بالتخزين المحلي القابل للترقية إلى API.');

  const result = useMemo(() => classifyCompany(draft), [draft]);
  const decision = useMemo(() => buildDecision(draft, result), [draft, result]);
  const recommendations = useMemo(() => prioritizeRecommendations(result), [result]);
  const completedDocs = draft.documents.filter((doc) => doc.status === 'مكتمل').length;

  function selectCompany(company: Company) {
    setSelectedCompanyId(company.id);
    setDraft(company);
    setMessage(`تم فتح ملف ${company.name}.`);
  }

  function saveCompany() {
    try {
      const next = repository.saveCompany(draft);
      setSnapshot(next);
      setSelectedCompanyId(draft.id);
      setMessage('تم حفظ ملف الشركة بنجاح داخل RawasiRepository.');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'تعذر حفظ الشركة.');
    }
  }

  function createNewCompany() {
    const company = createCompanyDraft();
    setDraft(company);
    setSelectedCompanyId(company.id);
    setMessage('تم تجهيز ملف شركة جديد. أدخل البيانات ثم اضغط حفظ.');
  }

  function deleteCompany() {
    if (!draft.id) return;
    const next = repository.deleteCompany(draft.id);
    setSnapshot(next);
    const first = next.companies[0] ?? createCompanyDraft();
    setSelectedCompanyId(first.id);
    setDraft(first);
    setMessage('تم حذف ملف الشركة من المستودع المحلي.');
  }

  function exportBackup() {
    downloadTextFile(`rawasi-backup-${new Date().toISOString().slice(0, 10)}.json`, repository.exportBackup());
    setMessage('تم تجهيز نسخة احتياطية قابلة للاستعادة.');
  }

  async function importBackup(file: File | undefined) {
    if (!file) return;
    try {
      const text = await file.text();
      const next = repository.importBackup(text);
      setSnapshot(next);
      const first = next.companies[0] ?? createCompanyDraft();
      setSelectedCompanyId(first.id);
      setDraft(first);
      setMessage('تمت استعادة النسخة الاحتياطية.');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'تعذر استعادة النسخة الاحتياطية.');
    }
  }

  return (
    <main className="min-h-screen bg-rawasi-sand">
      <header className="bg-gradient-to-l from-rawasi-navy to-rawasi-blue px-8 py-8 text-white">
        <div className="mx-auto max-w-7xl">
          <p className="text-sm text-white/75">RAWASI Platform · Real Development Sprint B</p>
          <h1 className="mt-2 text-4xl font-black">منصة الرواسي</h1>
          <p className="mt-3 max-w-3xl text-white/80">طبقة بيانات مؤسسية: ملفات شركات متعددة، حفظ واسترجاع، منع التكرار، نسخ احتياطي، وسجل عمليات.</p>
        </div>
      </header>

      <div className="mx-auto grid max-w-7xl gap-5 px-8 py-6 lg:grid-cols-[300px_1fr]">
        <CompanyList companies={snapshot.companies} selectedId={draft.id} onSelect={selectCompany} />

        <section className="grid gap-5">
          <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-sm font-bold text-emerald-900">{message}</div>

          <div className="grid gap-5 lg:grid-cols-4">
            <Card title="ملف الشركة">
              <div className="flex items-start gap-3">
                <Building2 className="text-rawasi-green" />
                <div>
                  <p className="font-bold">{draft.name || 'شركة جديدة'}</p>
                  <p className="text-sm text-slate-500">{draft.city} · {draft.activity}</p>
                </div>
              </div>
            </Card>

            <Card title="التصنيف المتوقع">
              <div className="flex items-center gap-3">
                <Target className="text-rawasi-lime" />
                <div>
                  <p className="text-3xl font-black text-rawasi-navy">{result.grade}</p>
                  <p className="text-sm text-slate-500">{result.score}/100 · ثقة {result.confidence}%</p>
                </div>
              </div>
            </Card>

            <Card title="المستندات">
              <div className="flex items-center gap-3">
                <FileText className="text-rawasi-green" />
                <p className="font-bold">{completedDocs}/{draft.documents.length} مكتمل</p>
              </div>
            </Card>

            <Card title="المستودع">
              <div className="flex items-center gap-3">
                <Database className="text-rawasi-blue" />
                <p className="font-bold">{snapshot.companies.length} شركة</p>
              </div>
            </Card>
          </div>

          <div className="flex flex-wrap gap-2">
            <button className="inline-flex items-center gap-2 rounded-xl bg-rawasi-navy px-4 py-3 font-bold text-white" type="button" onClick={exportBackup}>
              <Download size={18} /> تصدير نسخة احتياطية
            </button>
            <label className="inline-flex cursor-pointer items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-3 font-bold text-slate-700">
              <Upload size={18} /> استيراد نسخة
              <input className="hidden" type="file" accept="application/json" onChange={(event) => void importBackup(event.target.files?.[0])} />
            </label>
            <button className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-3 font-bold text-slate-700" type="button" onClick={() => setSnapshot(repository.load())}>
              <RefreshCcw size={18} /> تحديث من المستودع
            </button>
          </div>

          <CompanyForm company={draft} onChange={setDraft} onSave={saveCompany} onNew={createNewCompany} onDelete={deleteCompany} />

          <div className="grid gap-5 lg:grid-cols-2">
            <Card title="قرار الرواسي">
              <p className="leading-8 text-slate-700">{decision}</p>
              <ul className="mt-4 space-y-2">
                {result.reasons.map((reason) => (
                  <li key={reason} className="rounded-xl bg-slate-50 p-3 text-sm text-slate-700">{reason}</li>
                ))}
              </ul>
            </Card>

            <Card title="خطة التحسين">
              <ol className="space-y-3">
                {recommendations.map((item, index) => (
                  <li key={item} className="rounded-xl border border-slate-200 p-3">
                    <span className="ml-2 inline-flex h-7 w-7 items-center justify-center rounded-full bg-rawasi-green text-sm font-bold text-white">{index + 1}</span>
                    {item}
                  </li>
                ))}
              </ol>
            </Card>
          </div>

          <div className="grid gap-5 lg:grid-cols-2">
            <Card title="المؤشرات المالية">
              <div className="grid gap-3 text-sm text-slate-700">
                <p className="flex justify-between"><span>الأصول</span><b>{draft.financial.assets.toLocaleString('ar-SA')}</b></p>
                <p className="flex justify-between"><span>الخصوم</span><b>{draft.financial.liabilities.toLocaleString('ar-SA')}</b></p>
                <p className="flex justify-between"><span>حقوق الملكية</span><b>{draft.financial.equity.toLocaleString('ar-SA')}</b></p>
                <p className="flex justify-between"><span>الإيرادات</span><b>{draft.financial.revenue.toLocaleString('ar-SA')}</b></p>
              </div>
            </Card>
            <AuditTimeline entries={snapshot.auditLog} />
          </div>
        </section>
      </div>
    </main>
  );
}
