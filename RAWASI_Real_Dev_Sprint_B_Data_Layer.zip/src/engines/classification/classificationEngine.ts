import type { ClassificationGrade, Company, EngineResult } from '../../lib/types';
import { calculateFinancialRatios } from '../financial/financialEngine';

function gradeFromScore(score: number): ClassificationGrade {
  if (score >= 85) return 'الأولى';
  if (score >= 70) return 'الثانية';
  if (score >= 55) return 'الثالثة';
  if (score >= 40) return 'الرابعة';
  if (score >= 25) return 'الخامسة';
  return 'غير مصنف';
}

export function classifyCompany(company: Company): EngineResult {
  const financial = calculateFinancialRatios(company.financial);
  const engineerRatio = company.technical.employees > 0 ? company.technical.engineers / company.technical.employees : 0;
  const technicianRatio = company.technical.employees > 0 ? company.technical.technicians / company.technical.employees : 0;
  const saudiRatio = company.technical.employees > 0 ? company.technical.saudiEmployees / company.technical.employees : 0;

  const technicalScore = Math.round(
    Math.min(100, engineerRatio * 200) * 0.35 +
      Math.min(100, technicianRatio * 160) * 0.25 +
      Math.min(100, saudiRatio * 140) * 0.2 +
      Math.min(100, company.technical.avgEngineerExperience * 8) * 0.1 +
      Math.min(100, company.technical.avgTechnicianExperience * 7) * 0.1,
  );

  const documentScore = Math.round(
    (company.documents.filter((doc) => doc.status === 'مكتمل').length / Math.max(1, company.documents.length)) * 100,
  );

  const score = Math.round(financial.score * 0.45 + technicalScore * 0.35 + documentScore * 0.2);
  const grade = gradeFromScore(score);
  const confidence = Math.round((documentScore * 0.35 + 65) * 10) / 10;

  const reasons = [
    `النتيجة المالية ${financial.score}/100.`,
    `النتيجة الفنية ${technicalScore}/100.`,
    `اكتمال المستندات ${documentScore}%.`,
  ];

  const recommendations = [];
  if (financial.score < 70) recommendations.push('تحسين حقوق الملكية وخفض الالتزامات لرفع القوة المالية.');
  if (technicalScore < 70) recommendations.push('رفع نسبة المهندسين والفنيين وتحديث بيانات الخبرات.');
  if (documentScore < 100) recommendations.push('استكمال المستندات الناقصة قبل التقديم.');

  return { score, grade, confidence, reasons, recommendations };
}
