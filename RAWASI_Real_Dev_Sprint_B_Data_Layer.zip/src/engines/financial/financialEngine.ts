import type { FinancialStatement } from '../../lib/types';

export interface FinancialRatios {
  currentStrength: number;
  leverageRisk: number;
  profitability: number;
  cashFlowStrength: number;
  score: number;
}

export function calculateFinancialRatios(statement: FinancialStatement): FinancialRatios {
  const equityRatio = statement.assets > 0 ? statement.equity / statement.assets : 0;
  const liabilityRatio = statement.assets > 0 ? statement.liabilities / statement.assets : 1;
  const profitMargin = statement.revenue > 0 ? statement.netProfit / statement.revenue : 0;
  const cashFlowRatio = statement.revenue > 0 ? statement.operatingCashFlow / statement.revenue : 0;

  const currentStrength = Math.min(100, Math.max(0, equityRatio * 160));
  const leverageRisk = Math.min(100, Math.max(0, (1 - liabilityRatio) * 140));
  const profitability = Math.min(100, Math.max(0, profitMargin * 500));
  const cashFlowStrength = Math.min(100, Math.max(0, cashFlowRatio * 450));

  const score = Math.round(
    currentStrength * 0.25 + leverageRisk * 0.25 + profitability * 0.25 + cashFlowStrength * 0.25,
  );

  return { currentStrength, leverageRisk, profitability, cashFlowStrength, score };
}
