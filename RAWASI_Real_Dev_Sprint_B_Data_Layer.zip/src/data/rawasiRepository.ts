import { seedCompany } from './defaults';
import type { AuditLogEntry, Company, RawasiSnapshot } from '../lib/types';

const STORAGE_KEY = 'rawasi.enterprise.snapshot.v1';

function now() {
  return new Date().toISOString();
}

function createAudit(entityId: string, action: AuditLogEntry['action'], description: string): AuditLogEntry {
  return {
    id: crypto.randomUUID(),
    entityType: 'company',
    entityId,
    action,
    description,
    createdAt: now(),
  };
}

function initialSnapshot(): RawasiSnapshot {
  return {
    version: 2,
    companies: [seedCompany],
    auditLog: [createAudit(seedCompany.id, 'create', 'إنشاء بيانات عينة البداية لمنصة الرواسي.')],
    updatedAt: now(),
  };
}

export class RawasiRepository {
  load(): RawasiSnapshot {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      const snapshot = initialSnapshot();
      this.saveSnapshot(snapshot);
      return snapshot;
    }

    try {
      const parsed = JSON.parse(raw) as RawasiSnapshot;
      if (!Array.isArray(parsed.companies)) throw new Error('Invalid companies store');
      return parsed;
    } catch {
      const snapshot = initialSnapshot();
      this.saveSnapshot(snapshot);
      return snapshot;
    }
  }

  saveCompany(company: Company): RawasiSnapshot {
    const snapshot = this.load();
    const commercialRegistration = company.commercialRegistration.trim();
    if (!company.name.trim()) throw new Error('اسم الشركة مطلوب.');
    if (!commercialRegistration) throw new Error('رقم السجل التجاري مطلوب.');

    const duplicate = snapshot.companies.find(
      (item) => item.commercialRegistration === commercialRegistration && item.id !== company.id,
    );
    if (duplicate) throw new Error('يوجد ملف شركة بنفس رقم السجل التجاري.');

    const companyToSave: Company = {
      ...company,
      commercialRegistration,
      updatedAt: now(),
      documents: company.documents.map((doc) => ({ ...doc, updatedAt: doc.updatedAt ?? now() })),
    };

    const exists = snapshot.companies.some((item) => item.id === company.id);
    const companies = exists
      ? snapshot.companies.map((item) => (item.id === company.id ? companyToSave : item))
      : [companyToSave, ...snapshot.companies];

    const next: RawasiSnapshot = {
      ...snapshot,
      companies,
      auditLog: [
        createAudit(company.id, exists ? 'update' : 'create', exists ? 'تحديث ملف الشركة.' : 'إنشاء ملف شركة جديد.'),
        ...snapshot.auditLog,
      ].slice(0, 200),
      updatedAt: now(),
    };
    this.saveSnapshot(next);
    return next;
  }

  deleteCompany(companyId: string): RawasiSnapshot {
    const snapshot = this.load();
    const next: RawasiSnapshot = {
      ...snapshot,
      companies: snapshot.companies.filter((company) => company.id !== companyId),
      auditLog: [createAudit(companyId, 'delete', 'حذف ملف شركة.'), ...snapshot.auditLog].slice(0, 200),
      updatedAt: now(),
    };
    this.saveSnapshot(next);
    return next;
  }

  exportBackup(): string {
    return JSON.stringify(this.load(), null, 2);
  }

  importBackup(json: string): RawasiSnapshot {
    const parsed = JSON.parse(json) as RawasiSnapshot;
    if (!Array.isArray(parsed.companies)) throw new Error('ملف النسخة الاحتياطية غير صالح.');
    const next: RawasiSnapshot = {
      ...parsed,
      auditLog: [createAudit('system', 'restore', 'استعادة نسخة احتياطية.'), ...(parsed.auditLog ?? [])].slice(0, 200),
      updatedAt: now(),
    };
    this.saveSnapshot(next);
    return next;
  }

  private saveSnapshot(snapshot: RawasiSnapshot) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(snapshot));
  }
}
