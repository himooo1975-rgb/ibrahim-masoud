import type { Company, DocumentStatus, FinancialStatement, TechnicalProfile } from '../lib/types';

export const defaultFinancialStatement: FinancialStatement = {
  year: new Date().getFullYear() - 1,
  assets: 0,
  liabilities: 0,
  equity: 0,
  revenue: 0,
  netProfit: 0,
  operatingCashFlow: 0,
};

export const defaultTechnicalProfile: TechnicalProfile = {
  employees: 0,
  engineers: 0,
  technicians: 0,
  saudiEmployees: 0,
  avgEngineerExperience: 0,
  avgTechnicianExperience: 0,
};

export const defaultDocuments: DocumentStatus[] = [
  { key: 'commercial_registration', title: 'السجل التجاري', status: 'ناقص' },
  { key: 'financial_statement', title: 'القوائم المالية', status: 'ناقص' },
  { key: 'zakat_certificate', title: 'شهادة الزكاة', status: 'ناقص' },
  { key: 'gosi_certificate', title: 'شهادة التأمينات', status: 'ناقص' },
  { key: 'authorization_letter', title: 'خطاب التفويض', status: 'ناقص' },
];

export function createCompanyDraft(): Company {
  const now = new Date().toISOString();
  return {
    id: crypto.randomUUID(),
    name: '',
    commercialRegistration: '',
    establishmentNumber: '',
    city: 'الرياض',
    activity: 'التشييد والبناء',
    targetGrade: 'الثانية',
    financial: { ...defaultFinancialStatement },
    technical: { ...defaultTechnicalProfile },
    documents: defaultDocuments.map((doc) => ({ ...doc })),
    createdAt: now,
    updatedAt: now,
  };
}

export const seedCompany: Company = {
  ...createCompanyDraft(),
  id: 'seed-rawasi-001',
  name: 'شركة تلال الرواسي للمقاولات',
  commercialRegistration: '1010000000',
  establishmentNumber: '7000000000',
  city: 'الرياض',
  activity: 'التشييد والبناء',
  targetGrade: 'الأولى',
  financial: {
    year: 2025,
    assets: 24000000,
    liabilities: 9800000,
    equity: 14200000,
    revenue: 36000000,
    netProfit: 4100000,
    operatingCashFlow: 3600000,
  },
  technical: {
    employees: 82,
    engineers: 9,
    technicians: 18,
    saudiEmployees: 23,
    avgEngineerExperience: 8,
    avgTechnicianExperience: 7,
  },
  documents: defaultDocuments.map((doc, index) => ({ ...doc, status: index < 3 ? 'مكتمل' : 'ناقص' })),
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
};
