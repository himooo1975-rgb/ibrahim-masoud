export type ClassificationGrade = 'الأولى' | 'الثانية' | 'الثالثة' | 'الرابعة' | 'الخامسة' | 'غير مصنف';

export interface Company {
  id: string;
  name: string;
  commercialRegistration: string;
  establishmentNumber?: string;
  city: string;
  activity: string;
  targetGrade: ClassificationGrade;
  financial: FinancialStatement;
  technical: TechnicalProfile;
  documents: DocumentStatus[];
  createdAt: string;
  updatedAt: string;
}

export interface FinancialStatement {
  year: number;
  assets: number;
  liabilities: number;
  equity: number;
  revenue: number;
  netProfit: number;
  operatingCashFlow: number;
}

export interface TechnicalProfile {
  employees: number;
  engineers: number;
  technicians: number;
  saudiEmployees: number;
  avgEngineerExperience: number;
  avgTechnicianExperience: number;
}

export interface DocumentStatus {
  key: string;
  title: string;
  status: 'مكتمل' | 'ناقص' | 'يحتاج تحديث';
  updatedAt?: string;
}

export interface EngineResult {
  score: number;
  grade: ClassificationGrade;
  confidence: number;
  reasons: string[];
  recommendations: string[];
}

export interface AuditLogEntry {
  id: string;
  entityType: 'company' | 'financial' | 'technical' | 'document' | 'classification';
  entityId: string;
  action: 'create' | 'update' | 'delete' | 'evaluate' | 'restore' | 'backup';
  description: string;
  createdAt: string;
}

export interface RawasiSnapshot {
  version: 2;
  companies: Company[];
  auditLog: AuditLogEntry[];
  updatedAt: string;
}
